# Changelog

## 1.0.2

Release polish and documentation pass.

- Exposes only `Avatar Action Builder` and `Poiyomi Lighting Menu Builder` in the normal `Tools > Puddles` menu.
- Keeps Action Builder focused on creating and editing new controls from saved profile assets.
- Keeps Poiyomi radial generation connected to Action Builder profiles and Action Builder naming.
- Adds release-facing usage docs for Action Builder and Poiyomi Lighting Menu Builder.
- Refreshes the main README around install, safe setup, normal workflows, and troubleshooting entry points.
- Adds a repeatable drag-and-drop `.unitypackage` release build script.
- Adds VPM release scaffolding for VRChat Creator Companion distribution.
- Switches release metadata to the PolyForm Noncommercial license.

## 1.0.1

Action Builder preview and Poiyomi profile sync release.

- Adds Live Preview inside Action Builder for toggles, radials, and selectors.
- Adds Master Record for toggle controls so scene changes can become Action Builder rows.
- Adds Poiyomi-to-Action-Builder sync so scanned shader dials become editable Action Builder radial controls.
- Improves generated naming for parameters, FX layers, clips, and menus.

## 1.0.0

Initial release-facing package.

- Adds Avatar Action Builder for toggles, radials, selectors, action rows, managed menus, and generated VRC avatar assets.
- Adds Poiyomi Lighting Menu Builder for scanning Poiyomi shader float/range properties and creating radial controls.
- Adds package metadata for Unity Package Manager install-from-disk usage.
