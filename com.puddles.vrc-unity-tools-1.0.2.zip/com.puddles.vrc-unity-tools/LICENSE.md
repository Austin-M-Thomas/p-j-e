# License

Puddles VRC Unity Tools is licensed under the PolyForm Noncommercial License 1.0.0.

License URL:

https://polyformproject.org/licenses/noncommercial/1.0.0

SPDX identifier:

`PolyForm-Noncommercial-1.0.0`

Required Notice:

Copyright 2026 Puddles.

## Plain-Language Summary

You may use, copy, modify, and share this package for noncommercial purposes.

You may not sell this package, include it in a paid product, or otherwise use it for commercial purposes without separate permission from Puddles.

This summary is only a convenience. The PolyForm Noncommercial License 1.0.0 controls the actual license terms.
