#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PuddlesVrcTools.Editor
{
    public sealed class AvatarActionBuilderWindow : EditorWindow
    {
        private const string DefaultProfileFolder = "Assets/PuddlesVrcTools/Profiles";
        private const string DefaultOutputFolder = "Assets/PuddlesVrcTools/Generated/AvatarActions";
        private const string DefaultParameterPrefix = "Puddles/Action";
        private const int MaxControlsPerMenu = 8;
        private const int ControlsPerPagedMenu = 8;
        private const double MasterRecordPollIntervalSeconds = 0.35d;
        private const double MasterRecordSettleSeconds = 0.65d;

        private PuddlesAvatarActionProfile profile;
        private string profileRenameName = string.Empty;
        private string profileRenamePath = string.Empty;
        private string selectedControlId;
        private bool showControlsByMenu;
        private bool profileSetupFoldout = true;
        private bool livePreviewFoldout = true;
        private bool isActionPreviewActive;
        private bool livePreviewAutoFocus = true;
        private float livePreviewFocusDistance = 1.35f;
        private float livePreviewRadialValue;
        private int livePreviewSelectorIndex;
        private string livePreviewControlId;
        private string livePreviewStatus = string.Empty;
        private bool masterRecordFoldout = true;
        private bool masterRecordArmed;
        private string masterRecordControlId;
        private AvatarRecordSnapshot masterRecordBaseline;
        private AvatarRecordSnapshot masterRecordStartSnapshot;
        private readonly List<AvatarRecordedChange> masterRecordChanges = new List<AvatarRecordedChange>();
        private readonly HashSet<string> masterRecordAddedToggleOnRowSignatures = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> masterRecordBlendshapeRowKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> masterRecordMaterialRowKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> masterRecordShaderFloatRowKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private int masterRecordSelectedIndex;
        private string masterRecordStatus = string.Empty;
        private Vector2 masterRecordScroll;
        private double masterRecordNextPollTime;
        private double masterRecordPendingSince;
        private string masterRecordPendingSignature = string.Empty;
        private bool suppressProfileDirty;
        private Vector2 leftScroll;
        private Vector2 rightScroll;
        private Vector2 existingScroll;
        private readonly List<string> existingControlLines = new List<string>();
        private readonly HashSet<string> expandedControlMenuPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static GUIStyle modeSegmentLabelStyle;

        [MenuItem("Tools/Puddles/Avatar Action Builder")]
        public static void Open()
        {
            GetWindow<AvatarActionBuilderWindow>("Avatar Actions");
        }

        private void OnEnable()
        {
            AssemblyReloadEvents.beforeAssemblyReload += StopActionPreview;
            EditorApplication.update += TickMasterRecorder;
        }

        private void OnDisable()
        {
            AssemblyReloadEvents.beforeAssemblyReload -= StopActionPreview;
            EditorApplication.update -= TickMasterRecorder;
            StopActionPreview();
            StopMasterRecording(true);
        }

        internal static void OpenWithProfile(PuddlesAvatarActionProfile actionProfile, string controlId = null)
        {
            AvatarActionBuilderWindow window = GetWindow<AvatarActionBuilderWindow>("Avatar Actions");
            window.StopActionPreview();
            window.profile = actionProfile;
            window.selectedControlId = controlId;
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Avatar Action Builder", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Build editable VRChat avatar controls from saved profile data. Supports toggles, radials, selector wheels, object states, blendshapes, material swaps, and shader float actions.",
                MessageType.Info);

            PuddlesAvatarActionProfile profileBefore = profile;
            GameObject avatarRootBefore = profile != null ? profile.avatarRoot : null;
            string selectedControlBefore = selectedControlId;

            DrawProfileHeader();
            if (profile == null)
            {
                StopActionPreview();
                return;
            }

            EditorGUI.BeginChangeCheck();
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawControlList();
                DrawSelectedControlEditor();
            }

            if (EditorGUI.EndChangeCheck())
            {
                MarkProfileDirty();
            }

            DrawBottomActions();

            if (profileBefore != profile
                || avatarRootBefore != profile.avatarRoot
                || !string.Equals(selectedControlBefore, selectedControlId, StringComparison.Ordinal))
            {
                StopActionPreview();
                StopMasterRecording(true);
            }
        }

        private void DrawProfileHeader()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    profile = (PuddlesAvatarActionProfile)EditorGUILayout.ObjectField("Profile", profile, typeof(PuddlesAvatarActionProfile), false);
                    if (GUILayout.Button("New", GUILayout.Width(70)))
                    {
                        CreateProfileAsset();
                    }
                }

                if (profile == null)
                {
                    EditorGUILayout.HelpBox("Create or assign an Action Builder profile to begin.", MessageType.Info);
                    return;
                }

                if (profile.controls == null)
                {
                    profile.controls = new List<PuddlesAvatarActionControl>();
                    MarkProfileDirty();
                }

                if (profile.managedSubmenus == null)
                {
                    profile.managedSubmenus = new List<PuddlesAvatarManagedSubmenu>();
                    MarkProfileDirty();
                }

                profileSetupFoldout = EditorGUILayout.Foldout(profileSetupFoldout, "Avatar / Output Setup", true);
                if (!profileSetupFoldout)
                {
                    return;
                }

                DrawProfileAssetTools();

                EditorGUI.BeginChangeCheck();
                profile.avatarRoot = (GameObject)EditorGUILayout.ObjectField("Avatar Root", profile.avatarRoot, typeof(GameObject), true);
                using (new EditorGUI.DisabledScope(profile.avatarRoot == null))
                {
                    if (GUILayout.Button("Use Assets From Avatar Descriptor"))
                    {
                        AutoFillFromAvatarDescriptor();
                    }
                }

                profile.fxController = (AnimatorController)EditorGUILayout.ObjectField("FX Controller", profile.fxController, typeof(AnimatorController), false);
                profile.expressionParameters = (VRCExpressionParameters)EditorGUILayout.ObjectField("Expression Parameters", profile.expressionParameters, typeof(VRCExpressionParameters), false);
                profile.rootMenu = (VRCExpressionsMenu)EditorGUILayout.ObjectField("Root Menu", profile.rootMenu, typeof(VRCExpressionsMenu), false);
                using (new EditorGUI.DisabledScope(profile.rootMenu == null))
                {
                    if (GUILayout.Button("Menu Manager (add or remove submenus)"))
                    {
                        AvatarActionMenuManagerWindow.Open(profile);
                    }
                }

#if PUDDLES_EXPERIMENTAL_TOOLS
                using (new EditorGUI.DisabledScope(profile.rootMenu == null))
                {
                    if (GUILayout.Button("Control Inspector (experimental import tools)"))
                    {
                        AvatarActionControlInspectorWindow.Open(profile);
                    }
                }
#endif

                profile.outputFolder = EditorGUILayout.TextField("Output Folder", string.IsNullOrWhiteSpace(profile.outputFolder) ? DefaultOutputFolder : profile.outputFolder);
                profile.parameterPrefix = EditorGUILayout.TextField("Parameter Prefix", string.IsNullOrWhiteSpace(profile.parameterPrefix) ? DefaultParameterPrefix : profile.parameterPrefix);

                if (EditorGUI.EndChangeCheck())
                {
                    MarkProfileDirty();
                }
            }
        }

        private void DrawProfileAssetTools()
        {
            string profilePath = AssetDatabase.GetAssetPath(profile);
            if (profilePath != profileRenamePath)
            {
                profileRenamePath = profilePath;
                profileRenameName = string.IsNullOrWhiteSpace(profilePath)
                    ? profile.name
                    : Path.GetFileNameWithoutExtension(profilePath);
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                profileRenameName = EditorGUILayout.TextField("Profile Name", profileRenameName);
                using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(profilePath)))
                {
                    if (GUILayout.Button("Rename", GUILayout.Width(80)))
                    {
                        RenameCurrentProfile(profileRenameName);
                    }

                    if (GUILayout.Button("Show In Project", GUILayout.Width(120)))
                    {
                        ShowProfilesFolder(profilePath);
                    }
                }
            }
        }

        private void DrawControlList()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(300)))
            {
                EditorGUILayout.LabelField("Action Builder Controls", EditorStyles.boldLabel);
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Add Toggle"))
                    {
                        AddControl(PuddlesAvatarControlType.Toggle);
                    }

                    if (GUILayout.Button("Add Radial"))
                    {
                        AddControl(PuddlesAvatarControlType.Radial);
                    }

                    if (GUILayout.Button("Add Selector"))
                    {
                        AddControl(PuddlesAvatarControlType.Selector);
                    }
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    using (new EditorGUI.DisabledScope(GetSelectedControl() == null))
                    {
                        if (GUILayout.Button("Duplicate"))
                        {
                            DuplicateSelectedControl();
                        }

                        if (GUILayout.Button("Delete"))
                        {
                            ConfirmAndRemoveSelectedControl();
                        }
                    }
                }

                DrawControlListModeSwitch();
                leftScroll = EditorGUILayout.BeginScrollView(leftScroll, EditorStyles.helpBox, GUILayout.MinHeight(260));
                if (showControlsByMenu)
                {
                    DrawControlMenuTree();
                }
                else
                {
                    DrawFlatControlList();
                }

                EditorGUILayout.EndScrollView();

                EditorGUILayout.Space();
                PuddlesAvatarActionControl selectedControl = GetSelectedControl();
                if (selectedControl == null)
                {
                    using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox, GUILayout.MinHeight(150)))
                    {
                        EditorGUILayout.LabelField("Live Preview", EditorStyles.boldLabel);
                        EditorGUILayout.LabelField("Select a control to preview it on the scene avatar.", EditorStyles.wordWrappedMiniLabel);
                    }
                }
                else
                {
                    DrawLivePreview(selectedControl);
                    DrawMasterRecorder(selectedControl);
                }
            }
        }

        private void DrawControlListModeSwitch()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (DrawModeSegment("All Controls", !showControlsByMenu))
                {
                    showControlsByMenu = false;
                }

                if (DrawModeSegment("Menu Tree", showControlsByMenu))
                {
                    showControlsByMenu = true;
                    expandedControlMenuPaths.Add("Root");
                }
            }
        }

        private static bool DrawModeSegment(string label, bool selected)
        {
            Rect rect = GUILayoutUtility.GetRect(new GUIContent(label), EditorStyles.toolbarButton, GUILayout.Height(EditorGUIUtility.singleLineHeight + 2f));
            if (Event.current.type == EventType.Repaint)
            {
                Color fill = selected
                    ? new Color(0.20f, 0.20f, 0.20f, 1f)
                    : new Color(0.38f, 0.38f, 0.38f, 1f);
                Color border = new Color(0.10f, 0.10f, 0.10f, 1f);
                EditorGUI.DrawRect(rect, border);
                Rect inner = new Rect(rect.x + 1f, rect.y + 1f, rect.width - 2f, rect.height - 2f);
                EditorGUI.DrawRect(inner, fill);
                GetModeSegmentLabelStyle().Draw(inner, label, false, false, false, false);
            }

            return GUI.Button(rect, GUIContent.none, GUIStyle.none);
        }

        private static GUIStyle GetModeSegmentLabelStyle()
        {
            if (modeSegmentLabelStyle == null)
            {
                modeSegmentLabelStyle = new GUIStyle(EditorStyles.label)
                {
                    alignment = TextAnchor.MiddleCenter,
                    clipping = TextClipping.Clip,
                    padding = new RectOffset(4, 4, 0, 0)
                };
                modeSegmentLabelStyle.normal.textColor = Color.white;
            }

            return modeSegmentLabelStyle;
        }

        private void DrawFlatControlList()
        {
            foreach (PuddlesAvatarActionControl control in profile.controls)
            {
                DrawControlSelectionRow(control, 0);
            }
        }

        private void DrawControlMenuTree()
        {
            if (profile.controls == null || profile.controls.Count == 0)
            {
                EditorGUILayout.LabelField("No Action Builder controls in this profile yet.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            expandedControlMenuPaths.Add("Root");
            HashSet<string> renderedControlIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (profile.rootMenu != null)
            {
                DrawControlMenuTreeNode(profile.rootMenu, "Root", 0, new HashSet<VRCExpressionsMenu>(), renderedControlIds);
            }
            else
            {
                DrawSyntheticControlMenuNode("Root", 0, renderedControlIds);
            }

            List<PuddlesAvatarActionControl> missingDestinationControls = profile.controls
                .Where(control => control != null && !renderedControlIds.Contains(control.id))
                .OrderBy(control => GetControlDestinationPath(control), StringComparer.OrdinalIgnoreCase)
                .ThenBy(control => control.displayName, StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (missingDestinationControls.Count > 0)
            {
                DrawSyntheticControlGroup("Missing / Unlisted Destination", missingDestinationControls, renderedControlIds);
            }
        }

        private void DrawControlMenuTreeNode(VRCExpressionsMenu menu, string path, int depth, HashSet<VRCExpressionsMenu> visited, HashSet<string> renderedControlIds)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            List<PuddlesAvatarActionControl> controlsHere = GetControlsForMenu(menu, path, renderedControlIds);
            EnsureMenuControlList(menu);
            List<VRCExpressionsMenu.Control> submenus = menu.controls
                .Where(control => control != null && control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                .ToList();
            bool hasChildren = controlsHere.Count > 0 || submenus.Count > 0;
            DrawControlMenuHeader(path, depth, hasChildren, controlsHere.Count, false);
            if (!expandedControlMenuPaths.Contains(path))
            {
                return;
            }

            foreach (PuddlesAvatarActionControl control in controlsHere)
            {
                DrawControlSelectionRow(control, depth + 1);
                if (!string.IsNullOrWhiteSpace(control.id))
                {
                    renderedControlIds.Add(control.id);
                }
            }

            foreach (VRCExpressionsMenu.Control submenu in submenus)
            {
                string childPath = $"{path}/{submenu.name}";
                DrawControlMenuTreeNode(submenu.subMenu, childPath, depth + 1, visited, renderedControlIds);
            }
        }

        private void DrawSyntheticControlMenuNode(string path, int depth, HashSet<string> renderedControlIds)
        {
            List<PuddlesAvatarActionControl> controlsHere = profile.controls
                .Where(control => control != null && string.Equals(GetControlDestinationPath(control), path, StringComparison.OrdinalIgnoreCase))
                .OrderBy(control => control.displayName, StringComparer.OrdinalIgnoreCase)
                .ToList();
            DrawControlMenuHeader(path, depth, controlsHere.Count > 0, controlsHere.Count, true);
            if (!expandedControlMenuPaths.Contains(path))
            {
                return;
            }

            foreach (PuddlesAvatarActionControl control in controlsHere)
            {
                DrawControlSelectionRow(control, depth + 1);
                if (!string.IsNullOrWhiteSpace(control.id))
                {
                    renderedControlIds.Add(control.id);
                }
            }
        }

        private void DrawSyntheticControlGroup(string label, List<PuddlesAvatarActionControl> controls, HashSet<string> renderedControlIds)
        {
            string path = $"__synthetic/{label}";
            DrawControlMenuHeader(path, 0, controls.Count > 0, controls.Count, true, label);
            if (!expandedControlMenuPaths.Contains(path))
            {
                return;
            }

            foreach (PuddlesAvatarActionControl control in controls)
            {
                DrawControlSelectionRow(control, 1);
                if (!string.IsNullOrWhiteSpace(control.id))
                {
                    renderedControlIds.Add(control.id);
                }
            }
        }

        private void DrawControlMenuHeader(string path, int depth, bool hasChildren, int controlCount, bool synthetic, string overrideLabel = null)
        {
            bool expanded = expandedControlMenuPaths.Contains(path);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(depth * 14);
                using (new EditorGUI.DisabledScope(!hasChildren))
                {
                    string foldoutLabel = !hasChildren ? "-" : expanded ? "v" : ">";
                    if (GUILayout.Button(foldoutLabel, EditorStyles.miniButton, GUILayout.Width(22)))
                    {
                        if (expanded)
                        {
                            expandedControlMenuPaths.Remove(path);
                        }
                        else
                        {
                            expandedControlMenuPaths.Add(path);
                        }
                    }
                }

                string displayName = overrideLabel ?? GetMenuPathDisplayName(path);
                string suffix = synthetic ? " [Profile]" : string.Empty;
                string count = controlCount > 0 ? $" ({controlCount})" : string.Empty;
                GUIStyle style = new GUIStyle(EditorStyles.miniBoldLabel)
                {
                    alignment = TextAnchor.MiddleLeft,
                    wordWrap = false
                };
                EditorGUILayout.LabelField($"{displayName}{suffix}{count}", style);
            }
        }

        private List<PuddlesAvatarActionControl> GetControlsForMenu(VRCExpressionsMenu menu, string path, HashSet<string> renderedControlIds)
        {
            return profile.controls
                .Where(control => control != null && !renderedControlIds.Contains(control.id))
                .Where(control =>
                    (control.destinationMenu != null && control.destinationMenu == menu)
                    || (control.destinationMenu == null && string.Equals(GetControlDestinationPath(control), path, StringComparison.OrdinalIgnoreCase)))
                .OrderBy(control => control.displayName, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private void DrawControlSelectionRow(PuddlesAvatarActionControl control, int depth)
        {
            if (control == null)
            {
                return;
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(depth * 14 + (showControlsByMenu ? 24 : 0));
                bool selected = control.id == selectedControlId;
                GUIStyle style = selected ? EditorStyles.toolbarButton : GUI.skin.button;
                string label = string.IsNullOrWhiteSpace(control.displayName) ? $"(Unnamed {control.controlType})" : control.displayName;
                if (showControlsByMenu)
                {
                    label = $"{GetControlTypeGlyph(control.controlType)} {label}";
                }

                if (GUILayout.Button(label, style))
                {
                    selectedControlId = control.id;
                }
            }
        }

        private static string GetMenuPathDisplayName(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || string.Equals(path, "Root", StringComparison.OrdinalIgnoreCase))
            {
                return "Root";
            }

            int slash = path.LastIndexOf('/');
            return slash >= 0 && slash < path.Length - 1 ? path.Substring(slash + 1) : path;
        }

        private static string GetControlTypeGlyph(PuddlesAvatarControlType controlType)
        {
            switch (controlType)
            {
                case PuddlesAvatarControlType.Radial:
                    return "Radial";
                case PuddlesAvatarControlType.Selector:
                    return "Selector";
                default:
                    return "Toggle";
            }
        }

        private void DrawSelectedControlEditor()
        {
            using (new EditorGUILayout.VerticalScope())
            {
                PuddlesAvatarActionControl control = GetSelectedControl();
                if (control == null)
                {
                    EditorGUILayout.HelpBox("Select or add a control to edit it.", MessageType.Info);
                    return;
                }

                EnsureControlDefaults(control);
                rightScroll = EditorGUILayout.BeginScrollView(rightScroll);
                EditorGUILayout.LabelField($"Selected {control.controlType}", EditorStyles.boldLabel);
                control.displayName = EditorGUILayout.TextField("Menu Label", control.displayName);
                control.controlType = (PuddlesAvatarControlType)EditorGUILayout.EnumPopup("Control Type", control.controlType);
                DrawMenuPathField(control);
                using (new EditorGUILayout.HorizontalScope())
                {
                    control.saved = EditorGUILayout.Toggle("Saved Parameter", control.saved);
                    EditorGUILayout.LabelField("Checked because you want your outfit/accessory state remembered.", EditorStyles.miniLabel);
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    control.synced = EditorGUILayout.Toggle("Synced Parameter", control.synced);
                    EditorGUILayout.LabelField("Leave ON. Synced off means the toggle only shows for you locally, not others.", EditorStyles.miniLabel);
                }

                DrawControlDefaultFields(control);

                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.TextField("Stable ID", control.id);
                    EditorGUILayout.TextField("Parameter", BuildParameterName(control));
                }

                if (control.controlType == PuddlesAvatarControlType.Selector)
                {
                    DrawSelectorOptions(control);
                }

                EditorGUILayout.Space();
                DrawActionRows(control);
                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawLivePreview(PuddlesAvatarActionControl control)
        {
            bool changedBeforePreview = GUI.changed;

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                livePreviewFoldout = EditorGUILayout.Foldout(livePreviewFoldout, "Live Preview", true);
                if (!livePreviewFoldout)
                {
                    GUI.changed = changedBeforePreview;
                    return;
                }

                EditorGUILayout.LabelField("Preview the current control on the scene avatar without generating assets.", EditorStyles.wordWrappedMiniLabel);

                if (profile.avatarRoot == null)
                {
                    EditorGUILayout.HelpBox("Assign an Avatar Root before previewing.", MessageType.Info);
                    GUI.changed = changedBeforePreview;
                    return;
                }

                if (!isActionPreviewActive && AnimationMode.InAnimationMode())
                {
                    EditorGUILayout.HelpBox("Unity is already in animation preview mode. Stop the other preview before starting Action Builder preview.", MessageType.Warning);
                }

                if (isActionPreviewActive)
                {
                    EditorGUILayout.HelpBox("Preview Active: sampled values are temporary until Revert Preview, the selected control changes, or this window closes.", MessageType.Info);
                }

                if (!string.IsNullOrWhiteSpace(livePreviewStatus))
                {
                    EditorGUILayout.LabelField(livePreviewStatus, EditorStyles.wordWrappedMiniLabel);
                }

                switch (control.controlType)
                {
                    case PuddlesAvatarControlType.Radial:
                        DrawRadialLivePreview(control);
                        break;
                    case PuddlesAvatarControlType.Selector:
                        DrawSelectorLivePreview(control);
                        break;
                    default:
                        DrawToggleLivePreview(control);
                        break;
                }

                DrawLivePreviewFocusControls();

                using (new EditorGUI.DisabledScope(!isActionPreviewActive))
                {
                    if (GUILayout.Button("Revert Preview"))
                    {
                        StopActionPreview();
                    }
                }
            }

            GUI.changed = changedBeforePreview;
        }

        private void DrawLivePreviewFocusControls()
        {
            EditorGUILayout.Space(2f);
            EditorGUI.BeginChangeCheck();
            livePreviewAutoFocus = EditorGUILayout.Toggle("Auto Focus", livePreviewAutoFocus);
            using (new EditorGUI.DisabledScope(!livePreviewAutoFocus))
            {
                livePreviewFocusDistance = EditorGUILayout.Slider("Focus Distance", livePreviewFocusDistance, 0.6f, 4f);
            }

            if (EditorGUI.EndChangeCheck() && isActionPreviewActive && livePreviewAutoFocus)
            {
                FocusAvatarInSceneViewSoon();
            }
        }

        private void DrawToggleLivePreview(PuddlesAvatarActionControl control)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Preview Toggle Off"))
                {
                    AnimationClip clip = CreatePreviewToggleClip(control, false);
                    SamplePreviewClip(control, clip, 0f, "Previewing Toggle Off.");
                }

                if (GUILayout.Button("Preview Toggle On"))
                {
                    AnimationClip clip = CreatePreviewToggleClip(control, true);
                    SamplePreviewClip(control, clip, 0f, "Previewing Toggle On.");
                }
            }
        }

        private void DrawRadialLivePreview(PuddlesAvatarActionControl control)
        {
            EditorGUI.BeginChangeCheck();
            livePreviewRadialValue = EditorGUILayout.Slider("Preview Value", livePreviewRadialValue, 0f, 1f);
            bool sliderChanged = EditorGUI.EndChangeCheck();

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Preview Radial"))
                {
                    sliderChanged = true;
                }
            }

            if (sliderChanged)
            {
                AnimationClip clip = CreatePreviewRadialClip(control);
                SamplePreviewClip(control, clip, livePreviewRadialValue, $"Previewing Radial {livePreviewRadialValue:0.###}.");
            }
        }

        private void DrawSelectorLivePreview(PuddlesAvatarActionControl control)
        {
            EnsureSelectorOptions(control);
            string[] labels = control.selectorOptions
                .Select(option => string.IsNullOrWhiteSpace(option.displayName) ? "(Unnamed)" : option.displayName)
                .ToArray();
            livePreviewSelectorIndex = Mathf.Clamp(livePreviewSelectorIndex, 0, Mathf.Max(0, labels.Length - 1));
            livePreviewSelectorIndex = EditorGUILayout.Popup("Preview Option", livePreviewSelectorIndex, labels);

            using (new EditorGUI.DisabledScope(control.selectorOptions.Count == 0))
            {
                if (GUILayout.Button("Preview Selected Option"))
                {
                    PuddlesAvatarSelectorOption option = control.selectorOptions[livePreviewSelectorIndex];
                    AnimationClip clip = CreatePreviewSelectorClip(control, option.id);
                    string optionLabel = string.IsNullOrWhiteSpace(option.displayName) ? $"Option {livePreviewSelectorIndex + 1}" : option.displayName;
                    SamplePreviewClip(control, clip, 0f, $"Previewing {optionLabel}.");
                }
            }
        }

        private void DrawMasterRecorder(PuddlesAvatarActionControl control)
        {
            bool changedBeforeRecorder = GUI.changed;

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                masterRecordFoldout = EditorGUILayout.Foldout(masterRecordFoldout, "Master Record", true);
                if (!masterRecordFoldout)
                {
                    GUI.changed = changedBeforeRecorder;
                    return;
                }

                if (control.controlType != PuddlesAvatarControlType.Toggle)
                {
                    EditorGUILayout.LabelField("Toggle recorder only for now.", EditorStyles.wordWrappedMiniLabel);
                    GUI.changed = changedBeforeRecorder;
                    return;
                }

                EditorGUILayout.LabelField("Arm a snapshot, make one avatar change in Unity, and the recorder will add it to Toggle On after it settles.", EditorStyles.wordWrappedMiniLabel);

                if (profile.avatarRoot == null)
                {
                    EditorGUILayout.HelpBox("Assign an Avatar Root before recording.", MessageType.Info);
                    GUI.changed = changedBeforeRecorder;
                    return;
                }

                if (!string.IsNullOrWhiteSpace(masterRecordStatus))
                {
                    EditorGUILayout.LabelField(masterRecordStatus, EditorStyles.wordWrappedMiniLabel);
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(masterRecordArmed ? "Restart Recording" : "Start Recording"))
                    {
                        ArmMasterRecorder(control);
                    }
                }

                if (masterRecordArmed)
                {
                    EditorGUILayout.LabelField($"Armed For: {control.displayName}", EditorStyles.miniLabel);
                }

                DrawMasterRecordChanges(control);

                using (new EditorGUI.DisabledScope(!masterRecordArmed && masterRecordChanges.Count == 0))
                {
                    if (GUILayout.Button("Stop Recording"))
                    {
                        StopMasterRecording(true);
                    }
                }
            }

            GUI.changed = changedBeforeRecorder;
        }

        private void DrawMasterRecordChanges(PuddlesAvatarActionControl control)
        {
            if (masterRecordChanges.Count == 0)
            {
                EditorGUILayout.LabelField("No detected changes yet.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            masterRecordSelectedIndex = Mathf.Clamp(masterRecordSelectedIndex, 0, masterRecordChanges.Count - 1);
            EditorGUILayout.LabelField($"Detected Changes ({masterRecordChanges.Count})", EditorStyles.boldLabel);
            masterRecordScroll = EditorGUILayout.BeginScrollView(masterRecordScroll, GUILayout.MinHeight(70), GUILayout.MaxHeight(140));
            for (int i = 0; i < masterRecordChanges.Count; i++)
            {
                AvatarRecordedChange change = masterRecordChanges[i];
                GUIStyle style = i == masterRecordSelectedIndex ? EditorStyles.toolbarButton : GUI.skin.button;
                if (GUILayout.Button(change.Summary, style))
                {
                    masterRecordSelectedIndex = i;
                }
            }

            EditorGUILayout.EndScrollView();

            AvatarRecordedChange selected = masterRecordChanges[masterRecordSelectedIndex];
            EditorGUILayout.LabelField(selected.Detail, EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Apply Selected To Toggle On"))
                {
                    ApplyRecordedChange(control, selected, true);
                }
            }
        }

        private void ArmMasterRecorder(PuddlesAvatarActionControl control)
        {
            if (control == null || control.controlType != PuddlesAvatarControlType.Toggle || profile == null || profile.avatarRoot == null)
            {
                return;
            }

            if (masterRecordArmed)
            {
                StopMasterRecording(true);
            }

            StopActionPreview();
            masterRecordBaseline = CaptureAvatarRecordSnapshot();
            masterRecordStartSnapshot = masterRecordBaseline;
            masterRecordChanges.Clear();
            masterRecordSelectedIndex = 0;
            masterRecordArmed = masterRecordBaseline != null;
            masterRecordControlId = control.id;
            masterRecordNextPollTime = EditorApplication.timeSinceStartup + MasterRecordPollIntervalSeconds;
            masterRecordPendingSince = 0d;
            masterRecordPendingSignature = string.Empty;
            masterRecordStatus = masterRecordArmed
                ? $"Recorder armed with {masterRecordBaseline.Values.Count} watchable value(s). Make one change; it will auto-add to Toggle On."
                : "Recorder could not snapshot the avatar.";
            Repaint();
        }

        private void DetectMasterRecordChanges(PuddlesAvatarActionControl control)
        {
            if (control == null || !masterRecordArmed || masterRecordBaseline == null)
            {
                return;
            }

            if (!string.Equals(masterRecordControlId, control.id, StringComparison.Ordinal))
            {
                StopMasterRecording(true);
                masterRecordStatus = "Recorder was cleared because the selected control changed.";
                return;
            }

            StopActionPreview();
            AvatarRecordSnapshot current = CaptureAvatarRecordSnapshot();
            if (current == null)
            {
                masterRecordStatus = "Recorder could not read the current avatar state.";
                return;
            }

            SetMasterRecordChanges(BuildRecordedChanges(current));
            masterRecordSelectedIndex = 0;
            masterRecordStatus = masterRecordChanges.Count == 0
                ? "No supported value changes found."
                : $"Found {masterRecordChanges.Count} supported change(s). Select one and apply it to Toggle On.";
            Repaint();
        }

        private void TickMasterRecorder()
        {
            if (!masterRecordArmed || masterRecordBaseline == null || profile == null)
            {
                return;
            }

            double now = EditorApplication.timeSinceStartup;
            if (now < masterRecordNextPollTime)
            {
                return;
            }

            masterRecordNextPollTime = now + MasterRecordPollIntervalSeconds;
            PuddlesAvatarActionControl control = GetSelectedControl();
            if (control == null
                || control.controlType != PuddlesAvatarControlType.Toggle
                || !string.Equals(control.id, masterRecordControlId, StringComparison.Ordinal)
                || profile.avatarRoot == null)
            {
                StopMasterRecording(true);
                return;
            }

            if (isActionPreviewActive)
            {
                StopActionPreview();
            }

            AvatarRecordSnapshot current = CaptureAvatarRecordSnapshot();
            if (current == null)
            {
                masterRecordStatus = "Recorder could not read the current avatar state.";
                Repaint();
                return;
            }

            List<AvatarRecordedChange> changes = BuildRecordedChanges(current);
            SetMasterRecordChanges(changes);
            if (changes.Count == 0)
            {
                masterRecordPendingSince = 0d;
                masterRecordPendingSignature = string.Empty;
                Repaint();
                return;
            }

            if (TryApplyShaderFloatFanout(control, changes, current))
            {
                return;
            }

            if (changes.Count > 1)
            {
                masterRecordPendingSince = 0d;
                masterRecordPendingSignature = string.Empty;
                masterRecordStatus = $"Found {changes.Count} changes. Select one below, or re-arm and change one thing at a time.";
                Repaint();
                return;
            }

            AvatarRecordedChange change = changes[0];
            string signature = change.Signature;
            if (!string.Equals(masterRecordPendingSignature, signature, StringComparison.Ordinal))
            {
                masterRecordPendingSignature = signature;
                masterRecordPendingSince = now;
                masterRecordStatus = $"Detected {change.After.Label}. Waiting for it to settle...";
                Repaint();
                return;
            }

            if (now - masterRecordPendingSince < MasterRecordSettleSeconds)
            {
                return;
            }

            ApplyRecordedChange(control, change, true, false);
            masterRecordBaseline = current;
            masterRecordChanges.Clear();
            masterRecordSelectedIndex = 0;
            masterRecordPendingSince = 0d;
            masterRecordPendingSignature = string.Empty;
            masterRecordStatus += " Recorder re-armed from the current avatar state.";
            Repaint();
        }

        private List<AvatarRecordedChange> BuildRecordedChanges(AvatarRecordSnapshot current)
        {
            List<AvatarRecordedChange> changes = new List<AvatarRecordedChange>();
            if (masterRecordBaseline == null || current == null)
            {
                return changes;
            }

            HashSet<string> changedMaterialSlots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (KeyValuePair<string, AvatarRecordedValue> pair in current.Values)
            {
                if (!masterRecordBaseline.Values.TryGetValue(pair.Key, out AvatarRecordedValue before))
                {
                    continue;
                }

                AvatarRecordedValue after = pair.Value;
                if (after.Kind == PuddlesAvatarActionKind.MaterialSwap && !RecordedValuesMatch(before, after))
                {
                    changedMaterialSlots.Add(BuildMaterialSlotChangeKey(after.Path, after.MaterialSlot));
                }
            }

            foreach (KeyValuePair<string, AvatarRecordedValue> pair in current.Values)
            {
                if (!masterRecordBaseline.Values.TryGetValue(pair.Key, out AvatarRecordedValue before))
                {
                    continue;
                }

                AvatarRecordedValue after = pair.Value;
                if (after.Kind == PuddlesAvatarActionKind.ShaderFloat
                    && changedMaterialSlots.Contains(BuildMaterialSlotChangeKey(after.Path, after.MaterialSlot)))
                {
                    continue;
                }

                if (!RecordedValuesMatch(before, after))
                {
                    changes.Add(new AvatarRecordedChange(before, after));
                }
            }

            changes.Sort((left, right) => string.Compare(left.Summary, right.Summary, StringComparison.OrdinalIgnoreCase));
            return changes;
        }

        private void SetMasterRecordChanges(List<AvatarRecordedChange> changes)
        {
            masterRecordChanges.Clear();
            if (changes != null)
            {
                masterRecordChanges.AddRange(changes);
            }

            masterRecordSelectedIndex = Mathf.Clamp(masterRecordSelectedIndex, 0, Mathf.Max(0, masterRecordChanges.Count - 1));
        }

        private AvatarRecordSnapshot CaptureAvatarRecordSnapshot()
        {
            if (profile == null || profile.avatarRoot == null)
            {
                return null;
            }

            AvatarRecordSnapshot snapshot = new AvatarRecordSnapshot();
            Transform root = profile.avatarRoot.transform;
            foreach (Transform transform in profile.avatarRoot.GetComponentsInChildren<Transform>(true))
            {
                string path = AnimationUtility.CalculateTransformPath(transform, root);
                string displayPath = GetRecorderDisplayPath(path);
                snapshot.Add(AvatarRecordedValue.ForObjectState(path, displayPath, transform.gameObject, transform.gameObject.activeSelf));

                foreach (Component component in transform.GetComponents<Component>())
                {
                    if (component == null || component is Transform)
                    {
                        continue;
                    }

                    if (TryReadComponentEnabled(component, out bool enabled))
                    {
                        snapshot.Add(AvatarRecordedValue.ForComponentEnabled(path, displayPath, component, enabled));
                    }
                }
            }

            foreach (SkinnedMeshRenderer skinnedRenderer in profile.avatarRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (skinnedRenderer == null || skinnedRenderer.sharedMesh == null)
                {
                    continue;
                }

                string path = AnimationUtility.CalculateTransformPath(skinnedRenderer.transform, root);
                string displayPath = GetRecorderDisplayPath(path);
                Mesh mesh = skinnedRenderer.sharedMesh;
                for (int i = 0; i < mesh.blendShapeCount; i++)
                {
                    string blendshapeName = mesh.GetBlendShapeName(i);
                    snapshot.Add(AvatarRecordedValue.ForBlendshape(path, displayPath, skinnedRenderer, blendshapeName, skinnedRenderer.GetBlendShapeWeight(i)));
                }
            }

            foreach (Renderer renderer in profile.avatarRoot.GetComponentsInChildren<Renderer>(true))
            {
                if (renderer == null)
                {
                    continue;
                }

                string path = AnimationUtility.CalculateTransformPath(renderer.transform, root);
                string displayPath = GetRecorderDisplayPath(path);
                Material[] materials = renderer.sharedMaterials;
                for (int slot = 0; slot < materials.Length; slot++)
                {
                    Material material = materials[slot];
                    snapshot.Add(AvatarRecordedValue.ForMaterialSwap(path, displayPath, renderer, slot, material));
                    CaptureShaderFloatValues(snapshot, path, displayPath, renderer, slot, material);
                }
            }

            return snapshot;
        }

        private static void CaptureShaderFloatValues(AvatarRecordSnapshot snapshot, string path, string displayPath, Renderer renderer, int materialSlot, Material material)
        {
            if (snapshot == null || renderer == null || material == null || material.shader == null)
            {
                return;
            }

            int propertyCount = ShaderUtil.GetPropertyCount(material.shader);
            for (int i = 0; i < propertyCount; i++)
            {
                ShaderUtil.ShaderPropertyType type = ShaderUtil.GetPropertyType(material.shader, i);
                if (type != ShaderUtil.ShaderPropertyType.Float && type != ShaderUtil.ShaderPropertyType.Range)
                {
                    continue;
                }

                string propertyName = ShaderUtil.GetPropertyName(material.shader, i);
                if (string.IsNullOrWhiteSpace(propertyName) || !material.HasProperty(propertyName))
                {
                    continue;
                }

                snapshot.Add(AvatarRecordedValue.ForShaderFloat(path, displayPath, renderer, materialSlot, material, propertyName, material.GetFloat(propertyName)));
            }
        }

        private static bool TryReadComponentEnabled(Component component, out bool enabled)
        {
            enabled = false;
            if (component == null)
            {
                return false;
            }

            if (component is Behaviour behaviour)
            {
                enabled = behaviour.enabled;
                return true;
            }

            if (component is Renderer renderer)
            {
                enabled = renderer.enabled;
                return true;
            }

            if (component is Collider collider)
            {
                enabled = collider.enabled;
                return true;
            }

            PropertyInfo enabledProperty = component.GetType().GetProperty("enabled", BindingFlags.Instance | BindingFlags.Public);
            if (enabledProperty != null && enabledProperty.PropertyType == typeof(bool) && enabledProperty.CanRead)
            {
                enabled = (bool)enabledProperty.GetValue(component);
                return true;
            }

            return false;
        }

        private static bool RecordedValuesMatch(AvatarRecordedValue before, AvatarRecordedValue after)
        {
            if (before == null || after == null || before.Kind != after.Kind)
            {
                return false;
            }

            switch (after.Kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                case PuddlesAvatarActionKind.ComponentEnabled:
                    return before.BoolValue == after.BoolValue;
                case PuddlesAvatarActionKind.Blendshape:
                case PuddlesAvatarActionKind.ShaderFloat:
                    return Mathf.Abs(before.FloatValue - after.FloatValue) <= 0.0001f;
                case PuddlesAvatarActionKind.MaterialSwap:
                    return before.MaterialValue == after.MaterialValue;
                default:
                    return true;
            }
        }

        private void ApplyRecordedChange(PuddlesAvatarActionControl control, AvatarRecordedChange change, bool applyToOn, bool refreshBaselineAfterApply = true)
        {
            if (control == null || change == null || change.After == null || control.controlType != PuddlesAvatarControlType.Toggle)
            {
                return;
            }

            if (control.actions == null)
            {
                control.actions = new List<PuddlesAvatarActionRow>();
            }

            if (applyToOn && TryUndoRecordedToggleOnRow(control, change))
            {
                MarkProfileDirty();
                RemoveMasterRecordChange(change);
                masterRecordStatus = $"Removed recorded {GetActionKindLabel(change.After.Kind)} row because you flipped it back.";
                masterRecordPendingSince = 0d;
                masterRecordPendingSignature = string.Empty;
                if (refreshBaselineAfterApply && masterRecordArmed)
                {
                    masterRecordBaseline = CaptureAvatarRecordSnapshot();
                    masterRecordChanges.Clear();
                    masterRecordSelectedIndex = 0;
                    masterRecordStatus += " Recorder re-armed from the current avatar state.";
                }

                Repaint();
                return;
            }

            if (applyToOn && TryApplyRecordedBlendshapeUpdate(control, change))
            {
                return;
            }

            if (applyToOn && TryApplyRecordedMaterialUpdate(control, change))
            {
                return;
            }

            if (applyToOn && TryApplyRecordedShaderFloatUpdate(control, change))
            {
                return;
            }

            PuddlesAvatarActionRow row = CreateActionRowFromRecordedValue(change.After, applyToOn);
            if (row == null)
            {
                masterRecordStatus = "That recorded value could not be converted into an action row.";
                return;
            }

            control.actions.Add(row);
            StoreActionReferencePaths(row);
            if (applyToOn)
            {
                string signature = BuildRecordedToggleOnRowSignature(row);
                if (!string.IsNullOrWhiteSpace(signature))
                {
                    masterRecordAddedToggleOnRowSignatures.Add(signature);
                }
            }
            RegisterRecorderRowKey(row);

            MarkProfileDirty();
            RemoveMasterRecordChange(change);

            masterRecordStatus = $"Added {GetActionKindLabel(row.kind)} row to {(applyToOn ? "Toggle On" : "Toggle Off")}.";
            masterRecordPendingSince = 0d;
            masterRecordPendingSignature = string.Empty;
            if (refreshBaselineAfterApply && masterRecordArmed)
            {
                masterRecordBaseline = CaptureAvatarRecordSnapshot();
                masterRecordChanges.Clear();
                masterRecordSelectedIndex = 0;
                masterRecordStatus += " Recorder re-armed from the current avatar state.";
            }

            Repaint();
        }

        private bool TryApplyRecordedBlendshapeUpdate(PuddlesAvatarActionControl control, AvatarRecordedChange change)
        {
            if (control == null || change == null || change.After == null || change.After.Kind != PuddlesAvatarActionKind.Blendshape)
            {
                return false;
            }

            string key = BuildRecordedRowKey(change.After);
            if (string.IsNullOrWhiteSpace(key) || !masterRecordBlendshapeRowKeys.Contains(key))
            {
                return false;
            }

            int rowIndex = FindRecordedRowIndex(control, key, PuddlesAvatarActionKind.Blendshape);
            if (rowIndex < 0)
            {
                masterRecordBlendshapeRowKeys.Remove(key);
                return false;
            }

            PuddlesAvatarActionRow row = control.actions[rowIndex];
            row.onWriteMode = PuddlesAvatarWriteMode.Set;
            row.offWriteMode = PuddlesAvatarWriteMode.NoChange;
            row.onFloat = change.After.FloatValue;
            row.skinnedRenderer = change.After.SkinnedRenderer;
            row.skinnedRendererPath = change.After.Path;
            row.blendshapeName = change.After.BlendshapeName;
            StoreActionReferencePaths(row);
            FinishRecordedRowMutation(change, $"Updated Blendshape row to {change.After.FloatValue:0.###}.");
            return true;
        }

        private bool TryApplyRecordedMaterialUpdate(PuddlesAvatarActionControl control, AvatarRecordedChange change)
        {
            if (control == null || change == null || change.After == null || change.Before == null || change.After.Kind != PuddlesAvatarActionKind.MaterialSwap)
            {
                return false;
            }

            string key = BuildRecordedRowKey(change.After);
            if (string.IsNullOrWhiteSpace(key) || !masterRecordMaterialRowKeys.Contains(key))
            {
                return false;
            }

            int rowIndex = FindRecordedRowIndex(control, key, PuddlesAvatarActionKind.MaterialSwap);
            if (rowIndex < 0)
            {
                masterRecordMaterialRowKeys.Remove(key);
                return false;
            }

            PuddlesAvatarActionRow row = control.actions[rowIndex];
            Material startMaterial = GetStartMaterialForRecordedChange(change);
            if (change.After.MaterialValue == startMaterial)
            {
                control.actions.RemoveAt(rowIndex);
                masterRecordMaterialRowKeys.Remove(key);
                FinishRecordedRowMutation(change, "Removed Material Swap row because the slot returned to its start material.");
                return true;
            }

            row.onWriteMode = PuddlesAvatarWriteMode.Set;
            row.offWriteMode = PuddlesAvatarWriteMode.NoChange;
            row.onMaterial = change.After.MaterialValue;
            row.renderer = change.After.Renderer;
            row.rendererPath = change.After.Path;
            row.materialSlot = change.After.MaterialSlot;
            StoreActionReferencePaths(row);
            FinishRecordedRowMutation(change, $"Updated Material Swap row to {(change.After.MaterialValue != null ? change.After.MaterialValue.name : "None")}.");
            return true;
        }

        private bool TryApplyRecordedShaderFloatUpdate(PuddlesAvatarActionControl control, AvatarRecordedChange change)
        {
            if (control == null || change == null || change.After == null || change.After.Kind != PuddlesAvatarActionKind.ShaderFloat)
            {
                return false;
            }

            string key = BuildRecordedRowKey(change.After);
            if (string.IsNullOrWhiteSpace(key) || !masterRecordShaderFloatRowKeys.Contains(key))
            {
                return false;
            }

            int rowIndex = FindRecordedRowIndex(control, key, PuddlesAvatarActionKind.ShaderFloat);
            if (rowIndex < 0)
            {
                masterRecordShaderFloatRowKeys.Remove(key);
                return false;
            }

            PuddlesAvatarActionRow row = control.actions[rowIndex];
            ApplyShaderFloatRecordedValueToRow(row, change.After);
            StoreActionReferencePaths(row);
            FinishRecordedRowMutation(change, $"Updated Shader Float row to {change.After.FloatValue:0.###}.");
            return true;
        }

        private bool TryApplyShaderFloatFanout(PuddlesAvatarActionControl control, List<AvatarRecordedChange> changes, AvatarRecordSnapshot current)
        {
            if (control == null || changes == null || changes.Count <= 1 || current == null)
            {
                return false;
            }

            if (changes.Any(change => change == null || change.After == null || change.After.Kind != PuddlesAvatarActionKind.ShaderFloat))
            {
                return false;
            }

            AvatarRecordedValue first = changes[0].After;
            bool sameConceptualShaderEdit = changes.All(change =>
                change.After.MaterialValue == first.MaterialValue
                && string.Equals(change.After.ShaderPropertyName, first.ShaderPropertyName, StringComparison.Ordinal)
                && Mathf.Abs(change.After.FloatValue - first.FloatValue) <= 0.0001f);
            if (!sameConceptualShaderEdit)
            {
                return false;
            }

            int added = 0;
            int updated = 0;
            foreach (AvatarRecordedChange change in changes)
            {
                if (AddOrUpdateShaderFloatRecordedRow(control, change, out bool wasUpdate))
                {
                    if (wasUpdate)
                    {
                        updated++;
                    }
                    else
                    {
                        added++;
                    }
                }
            }

            if (added == 0 && updated == 0)
            {
                return false;
            }

            MarkProfileDirty();
            masterRecordBaseline = current;
            masterRecordChanges.Clear();
            masterRecordSelectedIndex = 0;
            masterRecordPendingSince = 0d;
            masterRecordPendingSignature = string.Empty;
            masterRecordStatus = $"Recorded shader float '{first.ShaderPropertyName}' on {added + updated} material slot(s): {added} added, {updated} updated. Recorder re-armed from the current avatar state.";
            Repaint();
            return true;
        }

        private bool AddOrUpdateShaderFloatRecordedRow(PuddlesAvatarActionControl control, AvatarRecordedChange change, out bool wasUpdate)
        {
            wasUpdate = false;
            if (control == null || change == null || change.After == null || change.After.Kind != PuddlesAvatarActionKind.ShaderFloat)
            {
                return false;
            }

            string key = BuildRecordedRowKey(change.After);
            if (string.IsNullOrWhiteSpace(key))
            {
                return false;
            }

            int rowIndex = masterRecordShaderFloatRowKeys.Contains(key)
                ? FindRecordedRowIndex(control, key, PuddlesAvatarActionKind.ShaderFloat)
                : -1;
            if (rowIndex >= 0)
            {
                ApplyShaderFloatRecordedValueToRow(control.actions[rowIndex], change.After);
                StoreActionReferencePaths(control.actions[rowIndex]);
                wasUpdate = true;
                return true;
            }

            PuddlesAvatarActionRow row = CreateActionRowFromRecordedValue(change.After, true);
            if (row == null)
            {
                return false;
            }

            control.actions.Add(row);
            StoreActionReferencePaths(row);
            masterRecordShaderFloatRowKeys.Add(key);
            return true;
        }

        private static void ApplyShaderFloatRecordedValueToRow(PuddlesAvatarActionRow row, AvatarRecordedValue value)
        {
            if (row == null || value == null)
            {
                return;
            }

            row.onWriteMode = PuddlesAvatarWriteMode.Set;
            row.offWriteMode = PuddlesAvatarWriteMode.NoChange;
            row.onFloat = value.FloatValue;
            row.renderer = value.Renderer;
            row.rendererPath = value.Path;
            row.materialSlot = value.MaterialSlot;
            row.shaderPropertyName = value.ShaderPropertyName;
        }

        private void FinishRecordedRowMutation(AvatarRecordedChange change, string status)
        {
            MarkProfileDirty();
            RemoveMasterRecordChange(change);
            masterRecordStatus = status;
            masterRecordPendingSince = 0d;
            masterRecordPendingSignature = string.Empty;
            if (masterRecordArmed)
            {
                masterRecordBaseline = CaptureAvatarRecordSnapshot();
                masterRecordChanges.Clear();
                masterRecordSelectedIndex = 0;
                masterRecordStatus += " Recorder re-armed from the current avatar state.";
            }

            Repaint();
        }

        private Material GetStartMaterialForRecordedChange(AvatarRecordedChange change)
        {
            if (change == null || change.After == null || masterRecordStartSnapshot == null)
            {
                return change != null && change.Before != null ? change.Before.MaterialValue : null;
            }

            if (masterRecordStartSnapshot.Values.TryGetValue(change.After.Key, out AvatarRecordedValue startValue))
            {
                return startValue.MaterialValue;
            }

            return change.Before != null ? change.Before.MaterialValue : null;
        }

        private bool TryUndoRecordedToggleOnRow(PuddlesAvatarActionControl control, AvatarRecordedChange change)
        {
            if (control == null || change == null || change.Before == null || control.actions == null)
            {
                return false;
            }

            if (change.After.Kind != PuddlesAvatarActionKind.ObjectState
                && change.After.Kind != PuddlesAvatarActionKind.ComponentEnabled)
            {
                return false;
            }

            string undoSignature = BuildRecordedToggleOnRowSignature(change.Before);
            if (string.IsNullOrWhiteSpace(undoSignature) || !masterRecordAddedToggleOnRowSignatures.Contains(undoSignature))
            {
                return false;
            }

            for (int i = control.actions.Count - 1; i >= 0; i--)
            {
                PuddlesAvatarActionRow row = control.actions[i];
                if (string.Equals(BuildRecordedToggleOnRowSignature(row), undoSignature, StringComparison.OrdinalIgnoreCase))
                {
                    control.actions.RemoveAt(i);
                    masterRecordAddedToggleOnRowSignatures.Remove(undoSignature);
                    return true;
                }
            }

            masterRecordAddedToggleOnRowSignatures.Remove(undoSignature);
            return false;
        }

        private void RemoveMasterRecordChange(AvatarRecordedChange change)
        {
            int removedIndex = masterRecordChanges.IndexOf(change);
            if (removedIndex >= 0)
            {
                masterRecordChanges.RemoveAt(removedIndex);
                masterRecordSelectedIndex = Mathf.Clamp(removedIndex, 0, Mathf.Max(0, masterRecordChanges.Count - 1));
            }
        }

        private static string BuildRecordedToggleOnRowSignature(AvatarRecordedValue value)
        {
            if (value == null)
            {
                return string.Empty;
            }

            switch (value.Kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    return $"{value.Kind}|{value.Path}|{value.BoolValue}";
                case PuddlesAvatarActionKind.ComponentEnabled:
                    return $"{value.Kind}|{value.Path}|{value.ComponentTypeName}|{value.BoolValue}";
                default:
                    return string.Empty;
            }
        }

        private static string BuildRecordedToggleOnRowSignature(PuddlesAvatarActionRow row)
        {
            if (row == null || row.onWriteMode != PuddlesAvatarWriteMode.Set || row.offWriteMode != PuddlesAvatarWriteMode.NoChange)
            {
                return string.Empty;
            }

            switch (row.kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    return $"{row.kind}|{row.targetObjectPath}|{row.onBool}";
                case PuddlesAvatarActionKind.ComponentEnabled:
                    return $"{row.kind}|{row.componentPath}|{row.componentTypeName}|{row.onBool}";
                default:
                    return string.Empty;
            }
        }

        private void RegisterRecorderRowKey(PuddlesAvatarActionRow row)
        {
            string key = BuildRecordedRowKey(row);
            if (string.IsNullOrWhiteSpace(key))
            {
                return;
            }

            switch (row.kind)
            {
                case PuddlesAvatarActionKind.Blendshape:
                    masterRecordBlendshapeRowKeys.Add(key);
                    break;
                case PuddlesAvatarActionKind.MaterialSwap:
                    masterRecordMaterialRowKeys.Add(key);
                    break;
                case PuddlesAvatarActionKind.ShaderFloat:
                    masterRecordShaderFloatRowKeys.Add(key);
                    break;
            }
        }

        private int FindRecordedRowIndex(PuddlesAvatarActionControl control, string key, PuddlesAvatarActionKind kind)
        {
            if (control == null || control.actions == null || string.IsNullOrWhiteSpace(key))
            {
                return -1;
            }

            for (int i = control.actions.Count - 1; i >= 0; i--)
            {
                PuddlesAvatarActionRow row = control.actions[i];
                if (row != null
                    && row.kind == kind
                    && string.Equals(BuildRecordedRowKey(row), key, StringComparison.OrdinalIgnoreCase))
                {
                    return i;
                }
            }

            return -1;
        }

        private static string BuildRecordedRowKey(AvatarRecordedValue value)
        {
            if (value == null)
            {
                return string.Empty;
            }

            switch (value.Kind)
            {
                case PuddlesAvatarActionKind.Blendshape:
                    return $"{value.Kind}|{value.Path}|{value.BlendshapeName}";
                case PuddlesAvatarActionKind.MaterialSwap:
                    return $"{value.Kind}|{value.Path}|{value.MaterialSlot}";
                case PuddlesAvatarActionKind.ShaderFloat:
                    return $"{value.Kind}|{value.Path}|{value.MaterialSlot}|{value.ShaderPropertyName}";
                default:
                    return string.Empty;
            }
        }

        private static string BuildRecordedRowKey(PuddlesAvatarActionRow row)
        {
            if (row == null)
            {
                return string.Empty;
            }

            switch (row.kind)
            {
                case PuddlesAvatarActionKind.Blendshape:
                    return $"{row.kind}|{row.skinnedRendererPath}|{row.blendshapeName}";
                case PuddlesAvatarActionKind.MaterialSwap:
                    return $"{row.kind}|{row.rendererPath}|{row.materialSlot}";
                case PuddlesAvatarActionKind.ShaderFloat:
                    return $"{row.kind}|{row.rendererPath}|{row.materialSlot}|{row.shaderPropertyName}";
                default:
                    return string.Empty;
            }
        }

        private static PuddlesAvatarActionRow CreateActionRowFromRecordedValue(AvatarRecordedValue value, bool applyToOn)
        {
            PuddlesAvatarActionRow row = new PuddlesAvatarActionRow
            {
                kind = value.Kind,
                offWriteMode = applyToOn ? PuddlesAvatarWriteMode.NoChange : PuddlesAvatarWriteMode.Set,
                onWriteMode = applyToOn ? PuddlesAvatarWriteMode.Set : PuddlesAvatarWriteMode.NoChange
            };

            switch (value.Kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    row.targetObject = value.TargetObject;
                    row.targetObjectPath = value.Path;
                    if (applyToOn)
                    {
                        row.onBool = value.BoolValue;
                    }
                    else
                    {
                        row.offBool = value.BoolValue;
                    }
                    break;

                case PuddlesAvatarActionKind.Blendshape:
                    row.skinnedRenderer = value.SkinnedRenderer;
                    row.skinnedRendererPath = value.Path;
                    row.blendshapeName = value.BlendshapeName;
                    if (applyToOn)
                    {
                        row.onFloat = value.FloatValue;
                    }
                    else
                    {
                        row.offFloat = value.FloatValue;
                    }
                    break;

                case PuddlesAvatarActionKind.MaterialSwap:
                    row.renderer = value.Renderer;
                    row.rendererPath = value.Path;
                    row.materialSlot = value.MaterialSlot;
                    if (applyToOn)
                    {
                        row.onMaterial = value.MaterialValue;
                    }
                    else
                    {
                        row.offMaterial = value.MaterialValue;
                    }
                    break;

                case PuddlesAvatarActionKind.ComponentEnabled:
                    row.component = value.Component;
                    row.componentPath = value.Path;
                    row.componentTypeName = value.ComponentTypeName;
                    if (applyToOn)
                    {
                        row.onBool = value.BoolValue;
                    }
                    else
                    {
                        row.offBool = value.BoolValue;
                    }
                    break;

                case PuddlesAvatarActionKind.ShaderFloat:
                    row.renderer = value.Renderer;
                    row.rendererPath = value.Path;
                    row.materialSlot = value.MaterialSlot;
                    row.shaderPropertyName = value.ShaderPropertyName;
                    if (applyToOn)
                    {
                        row.onFloat = value.FloatValue;
                    }
                    else
                    {
                        row.offFloat = value.FloatValue;
                    }
                    break;

                default:
                    return null;
            }

            return row;
        }

        private void StopMasterRecording(bool restoreStartState)
        {
            if (restoreStartState && masterRecordStartSnapshot != null)
            {
                RestoreAvatarRecordSnapshot(masterRecordStartSnapshot);
            }

            masterRecordArmed = false;
            masterRecordControlId = null;
            masterRecordBaseline = null;
            masterRecordStartSnapshot = null;
            masterRecordChanges.Clear();
            masterRecordSelectedIndex = 0;
            masterRecordStatus = string.Empty;
            masterRecordNextPollTime = 0d;
            masterRecordPendingSince = 0d;
            masterRecordPendingSignature = string.Empty;
            masterRecordAddedToggleOnRowSignatures.Clear();
            masterRecordBlendshapeRowKeys.Clear();
            masterRecordMaterialRowKeys.Clear();
            masterRecordShaderFloatRowKeys.Clear();
        }

        private void RestoreAvatarRecordSnapshot(AvatarRecordSnapshot snapshot)
        {
            if (snapshot == null)
            {
                return;
            }

            foreach (AvatarRecordedValue value in snapshot.Values.Values.Where(value => value.Kind == PuddlesAvatarActionKind.MaterialSwap))
            {
                RestoreRecordedMaterial(value);
            }

            foreach (AvatarRecordedValue value in snapshot.Values.Values.Where(value => value.Kind == PuddlesAvatarActionKind.ShaderFloat))
            {
                RestoreRecordedShaderFloat(value);
            }

            foreach (AvatarRecordedValue value in snapshot.Values.Values.Where(value => value.Kind == PuddlesAvatarActionKind.Blendshape))
            {
                RestoreRecordedBlendshape(value);
            }

            foreach (AvatarRecordedValue value in snapshot.Values.Values.Where(value => value.Kind == PuddlesAvatarActionKind.ComponentEnabled))
            {
                RestoreRecordedComponentEnabled(value);
            }

            foreach (AvatarRecordedValue value in snapshot.Values.Values.Where(value => value.Kind == PuddlesAvatarActionKind.ObjectState))
            {
                if (value.TargetObject != null && value.TargetObject.activeSelf != value.BoolValue)
                {
                    value.TargetObject.SetActive(value.BoolValue);
                    EditorUtility.SetDirty(value.TargetObject);
                }
            }

            SceneView.RepaintAll();
        }

        private static void RestoreRecordedMaterial(AvatarRecordedValue value)
        {
            if (value == null || value.Renderer == null || value.MaterialSlot < 0)
            {
                return;
            }

            Material[] materials = value.Renderer.sharedMaterials;
            if (value.MaterialSlot >= materials.Length)
            {
                return;
            }

            if (materials[value.MaterialSlot] == value.MaterialValue)
            {
                return;
            }

            materials[value.MaterialSlot] = value.MaterialValue;
            value.Renderer.sharedMaterials = materials;
            EditorUtility.SetDirty(value.Renderer);
        }

        private static void RestoreRecordedShaderFloat(AvatarRecordedValue value)
        {
            if (value == null || value.Renderer == null || value.MaterialSlot < 0 || string.IsNullOrWhiteSpace(value.ShaderPropertyName))
            {
                return;
            }

            Material[] materials = value.Renderer.sharedMaterials;
            if (value.MaterialSlot >= materials.Length)
            {
                return;
            }

            Material material = materials[value.MaterialSlot];
            if (material == null || !material.HasProperty(value.ShaderPropertyName))
            {
                return;
            }

            if (Mathf.Abs(material.GetFloat(value.ShaderPropertyName) - value.FloatValue) <= 0.0001f)
            {
                return;
            }

            material.SetFloat(value.ShaderPropertyName, value.FloatValue);
            EditorUtility.SetDirty(material);
        }

        private static void RestoreRecordedBlendshape(AvatarRecordedValue value)
        {
            if (value == null || value.SkinnedRenderer == null || value.SkinnedRenderer.sharedMesh == null || string.IsNullOrWhiteSpace(value.BlendshapeName))
            {
                return;
            }

            int index = value.SkinnedRenderer.sharedMesh.GetBlendShapeIndex(value.BlendshapeName);
            if (index < 0)
            {
                return;
            }

            if (Mathf.Abs(value.SkinnedRenderer.GetBlendShapeWeight(index) - value.FloatValue) <= 0.0001f)
            {
                return;
            }

            value.SkinnedRenderer.SetBlendShapeWeight(index, value.FloatValue);
            EditorUtility.SetDirty(value.SkinnedRenderer);
        }

        private static void RestoreRecordedComponentEnabled(AvatarRecordedValue value)
        {
            if (value == null || value.Component == null)
            {
                return;
            }

            if (value.Component is Behaviour behaviour)
            {
                if (behaviour.enabled != value.BoolValue)
                {
                    behaviour.enabled = value.BoolValue;
                    EditorUtility.SetDirty(behaviour);
                }

                return;
            }

            if (value.Component is Renderer renderer)
            {
                if (renderer.enabled != value.BoolValue)
                {
                    renderer.enabled = value.BoolValue;
                    EditorUtility.SetDirty(renderer);
                }

                return;
            }

            if (value.Component is Collider collider)
            {
                if (collider.enabled != value.BoolValue)
                {
                    collider.enabled = value.BoolValue;
                    EditorUtility.SetDirty(collider);
                }

                return;
            }

            PropertyInfo enabledProperty = value.Component.GetType().GetProperty("enabled", BindingFlags.Instance | BindingFlags.Public);
            if (enabledProperty == null || enabledProperty.PropertyType != typeof(bool) || !enabledProperty.CanWrite)
            {
                return;
            }

            bool current = enabledProperty.CanRead && (bool)enabledProperty.GetValue(value.Component);
            if (current == value.BoolValue)
            {
                return;
            }

            enabledProperty.SetValue(value.Component, value.BoolValue);
            EditorUtility.SetDirty(value.Component);
        }

        private static string GetRecorderDisplayPath(string path)
        {
            return string.IsNullOrWhiteSpace(path) ? "(Avatar Root)" : path;
        }

        private static string BuildMaterialSlotChangeKey(string path, int materialSlot)
        {
            return $"{path}|{materialSlot}";
        }

        private void DrawControlDefaultFields(PuddlesAvatarActionControl control)
        {
            switch (control.controlType)
            {
                case PuddlesAvatarControlType.Radial:
                    control.radialMode = (PuddlesAvatarRadialMode)EditorGUILayout.EnumPopup("Radial Mode", control.radialMode);
                    control.radialDefaultValue = EditorGUILayout.Slider("Default", control.radialDefaultValue, 0f, 1f);
                    break;
                case PuddlesAvatarControlType.Selector:
                    EnsureSelectorOptions(control);
                    string[] labels = control.selectorOptions.Select(option => string.IsNullOrWhiteSpace(option.displayName) ? "(Unnamed)" : option.displayName).ToArray();
                    control.selectorDefaultIndex = Mathf.Clamp(EditorGUILayout.Popup("Default Option", control.selectorDefaultIndex, labels), 0, Mathf.Max(0, control.selectorOptions.Count - 1));
                    break;
                default:
                    control.defaultValue = EditorGUILayout.Toggle("Default On", control.defaultValue);
                    break;
            }
        }

        private void DrawMenuPathField(PuddlesAvatarActionControl control)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.TextField("Destination Menu", GetControlDestinationPath(control));
                }

                if (GUILayout.Button("Select...", GUILayout.Width(90)))
                {
                    AvatarActionMenuSelectorWindow.Open(profile, control.id);
                }
            }

            if (control.destinationMenu == null && !string.IsNullOrWhiteSpace(control.menuPath))
            {
                EditorGUILayout.HelpBox("Legacy menu paths now default to root placement until you choose an existing or managed destination.", MessageType.Info);
            }
        }

        private void DrawSelectorOptions(PuddlesAvatarActionControl control)
        {
            EnsureSelectorOptions(control);
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Selector Options", EditorStyles.boldLabel);
            for (int i = 0; i < control.selectorOptions.Count; i++)
            {
                PuddlesAvatarSelectorOption option = control.selectorOptions[i];
                using (new EditorGUILayout.HorizontalScope())
                {
                    option.displayName = EditorGUILayout.TextField($"Option {i + 1}", option.displayName);
                    using (new EditorGUI.DisabledScope(control.selectorOptions.Count <= 1))
                    {
                        if (GUILayout.Button("Remove", GUILayout.Width(80)))
                        {
                            string removedId = option.id;
                            control.selectorOptions.RemoveAt(i);
                            foreach (PuddlesAvatarActionRow action in control.actions)
                            {
                                if (action.optionValues != null)
                                {
                                    action.optionValues.RemoveAll(value => value.optionId == removedId);
                                }
                            }

                            control.selectorDefaultIndex = Mathf.Clamp(control.selectorDefaultIndex, 0, Mathf.Max(0, control.selectorOptions.Count - 1));
                            i--;
                        }
                    }
                }
            }

            if (GUILayout.Button("Add Option"))
            {
                control.selectorOptions.Add(new PuddlesAvatarSelectorOption
                {
                    id = CreateStableId(),
                    displayName = $"Option {control.selectorOptions.Count + 1}"
                });
            }
        }

        private void DrawActionRows(PuddlesAvatarActionControl control)
        {
            if (control.actions == null)
            {
                control.actions = new List<PuddlesAvatarActionRow>();
            }

            EditorGUILayout.LabelField("Actions", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(control.controlType == PuddlesAvatarControlType.Radial))
                {
                    if (GUILayout.Button("Object"))
                    {
                        control.actions.Add(CreateNewActionRow(control, PuddlesAvatarActionKind.ObjectState, row => row.onBool = true));
                    }
                }

                if (GUILayout.Button("Blendshape"))
                {
                    control.actions.Add(CreateNewActionRow(control, PuddlesAvatarActionKind.Blendshape, row => row.onFloat = 100f));
                }

                using (new EditorGUI.DisabledScope(control.controlType == PuddlesAvatarControlType.Radial))
                {
                    if (GUILayout.Button("Material Swap"))
                    {
                        control.actions.Add(CreateNewActionRow(control, PuddlesAvatarActionKind.MaterialSwap));
                    }
                }

                using (new EditorGUI.DisabledScope(control.controlType == PuddlesAvatarControlType.Radial))
                {
                    if (GUILayout.Button("Component"))
                    {
                        control.actions.Add(CreateNewActionRow(control, PuddlesAvatarActionKind.ComponentEnabled, row => row.onBool = true));
                    }
                }

                if (GUILayout.Button("Shader Float"))
                {
                    control.actions.Add(CreateNewActionRow(control, PuddlesAvatarActionKind.ShaderFloat, row => row.onFloat = 1f));
                }

                using (new EditorGUI.DisabledScope(control.controlType != PuddlesAvatarControlType.Toggle))
                {
                    if (GUILayout.Button("Set Control"))
                    {
                        control.actions.Add(new PuddlesAvatarActionRow
                        {
                            kind = PuddlesAvatarActionKind.SetAnotherToggle,
                            offWriteMode = PuddlesAvatarWriteMode.NoChange,
                            onWriteMode = PuddlesAvatarWriteMode.Set,
                            onBool = false
                        });
                    }
                }
            }

            for (int i = 0; i < control.actions.Count; i++)
            {
                PuddlesAvatarActionRow action = control.actions[i];
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        action.kind = DrawActionKindPopup(action.kind);
                        GUILayout.FlexibleSpace();
                        if (GUILayout.Button("Remove", GUILayout.Width(80)))
                        {
                            control.actions.RemoveAt(i);
                            i--;
                            continue;
                        }
                    }

                    DrawActionFields(control, action);
                    if (control.controlType == PuddlesAvatarControlType.Radial && (action.kind == PuddlesAvatarActionKind.ObjectState || action.kind == PuddlesAvatarActionKind.MaterialSwap || action.kind == PuddlesAvatarActionKind.ComponentEnabled || action.kind == PuddlesAvatarActionKind.RawBinding))
                    {
                        EditorGUILayout.HelpBox("Radial controls support blendshape and shader float actions in this version.", MessageType.Info);
                    }
                    else if (control.controlType == PuddlesAvatarControlType.Selector)
                    {
                        DrawSelectorActionValues(control, action);
                    }
                }
            }
        }

        private static PuddlesAvatarActionRow CreateNewActionRow(PuddlesAvatarActionControl control, PuddlesAvatarActionKind kind, Action<PuddlesAvatarActionRow> configure = null)
        {
            PuddlesAvatarActionRow row = new PuddlesAvatarActionRow
            {
                kind = kind
            };

            if (control != null && control.controlType == PuddlesAvatarControlType.Toggle)
            {
                row.offWriteMode = PuddlesAvatarWriteMode.NoChange;
                row.onWriteMode = PuddlesAvatarWriteMode.Set;
            }

            configure?.Invoke(row);
            return row;
        }

        private static PuddlesAvatarActionKind DrawActionKindPopup(PuddlesAvatarActionKind current)
        {
#if PUDDLES_EXPERIMENTAL_TOOLS
            return (PuddlesAvatarActionKind)EditorGUILayout.EnumPopup(current);
#else
            PuddlesAvatarActionKind[] releaseKinds =
            {
                PuddlesAvatarActionKind.ObjectState,
                PuddlesAvatarActionKind.Blendshape,
                PuddlesAvatarActionKind.MaterialSwap,
                PuddlesAvatarActionKind.ComponentEnabled,
                PuddlesAvatarActionKind.ShaderFloat,
                PuddlesAvatarActionKind.SetAnotherToggle,
            };

            int currentIndex = Array.IndexOf(releaseKinds, current);
            if (currentIndex < 0)
            {
                currentIndex = releaseKinds.Length - 1;
            }

            string[] labels = releaseKinds.Select(GetActionKindLabel).ToArray();
            int selectedIndex = EditorGUILayout.Popup(currentIndex, labels);
            return releaseKinds[Mathf.Clamp(selectedIndex, 0, releaseKinds.Length - 1)];
#endif
        }

        private static string GetActionKindLabel(PuddlesAvatarActionKind kind)
        {
            switch (kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    return "Object State";
                case PuddlesAvatarActionKind.Blendshape:
                    return "Blendshape";
                case PuddlesAvatarActionKind.MaterialSwap:
                    return "Material Swap";
                case PuddlesAvatarActionKind.ComponentEnabled:
                    return "Component Enabled";
                case PuddlesAvatarActionKind.ShaderFloat:
                    return "Shader Float";
                case PuddlesAvatarActionKind.RawBinding:
                    return "Raw Preserved Binding";
                case PuddlesAvatarActionKind.SetAnotherToggle:
                    return "Set Control";
                default:
                    return kind.ToString();
            }
        }

        private void DrawActionFields(PuddlesAvatarActionControl control, PuddlesAvatarActionRow action)
        {
            ResolveActionReferences(action);
            switch (action.kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    EditorGUI.BeginChangeCheck();
                    action.targetObject = (GameObject)EditorGUILayout.ObjectField("Target Object", action.targetObject, typeof(GameObject), true);
                    if (EditorGUI.EndChangeCheck())
                    {
                        StoreActionReferencePaths(action);
                    }

                    if (control.controlType == PuddlesAvatarControlType.Toggle)
                    {
                        DrawObjectStateValueField("Toggle Off", ref action.offWriteMode, ref action.offBool);
                        DrawObjectStateValueField("Toggle On", ref action.onWriteMode, ref action.onBool);
                        EditorGUILayout.LabelField("Use No Change when another control should be allowed to own this object in that state.", EditorStyles.wordWrappedMiniLabel);
                    }
                    break;

                case PuddlesAvatarActionKind.Blendshape:
                    EditorGUI.BeginChangeCheck();
                    action.skinnedRenderer = (SkinnedMeshRenderer)EditorGUILayout.ObjectField("Renderer", action.skinnedRenderer, typeof(SkinnedMeshRenderer), true);
                    if (EditorGUI.EndChangeCheck())
                    {
                        StoreActionReferencePaths(action);
                    }

                    DrawBlendshapePicker(action);
                    if (control.controlType == PuddlesAvatarControlType.Radial)
                    {
                        action.offFloat = EditorGUILayout.FloatField("Radial 0 Value", action.offFloat);
                        action.onFloat = EditorGUILayout.FloatField("Radial 1 Value", action.onFloat);
                    }
                    else if (control.controlType == PuddlesAvatarControlType.Toggle)
                    {
                        DrawFloatWriteValueField("Toggle Off", ref action.offWriteMode, ref action.offFloat);
                        DrawFloatWriteValueField("Toggle On", ref action.onWriteMode, ref action.onFloat);
                    }
                    break;

                case PuddlesAvatarActionKind.MaterialSwap:
                    EditorGUI.BeginChangeCheck();
                    action.renderer = (Renderer)EditorGUILayout.ObjectField("Renderer", action.renderer, typeof(Renderer), true);
                    if (EditorGUI.EndChangeCheck())
                    {
                        StoreActionReferencePaths(action);
                    }

                    action.materialSlot = Mathf.Max(0, EditorGUILayout.IntField("Material Slot", action.materialSlot));
                    if (control.controlType == PuddlesAvatarControlType.Toggle)
                    {
                        DrawMaterialWriteValueField("Toggle Off Mat", ref action.offWriteMode, ref action.offMaterial);
                        DrawMaterialWriteValueField("Toggle On Mat", ref action.onWriteMode, ref action.onMaterial);
                        using (new EditorGUI.DisabledScope(action.renderer == null))
                        {
                            if (GUILayout.Button("Use Current Slot As Toggle Off Mat"))
                            {
                                action.offMaterial = GetRendererMaterialAtSlot(action.renderer, action.materialSlot);
                            }
                        }
                    }
                    break;

                case PuddlesAvatarActionKind.ComponentEnabled:
                    EditorGUI.BeginChangeCheck();
                    action.component = (Component)EditorGUILayout.ObjectField("Component", action.component, typeof(Component), true);
                    if (EditorGUI.EndChangeCheck())
                    {
                        StoreActionReferencePaths(action);
                    }

                    if (!string.IsNullOrWhiteSpace(action.componentTypeName))
                    {
                        EditorGUILayout.LabelField("Type", GetComponentTypeDisplayName(action.componentTypeName));
                    }

                    if (!string.IsNullOrWhiteSpace(action.componentPath))
                    {
                        EditorGUILayout.LabelField("Path", action.componentPath);
                        Transform target = FindAvatarTransform(action.componentPath);
                        Component resolved = action.component != null ? action.component : FindComponentOnTransform(target, action.componentTypeName);
                        if (resolved != null)
                        {
                            string resolvedPath = profile != null && profile.avatarRoot != null
                                ? AnimationUtility.CalculateTransformPath(resolved.transform, profile.avatarRoot.transform)
                                : resolved.gameObject.name;
                            EditorGUILayout.LabelField("Resolved", $"{resolvedPath} ({resolved.GetType().Name})");
                        }
                        else
                        {
                            EditorGUILayout.HelpBox("This saved path has not resolved to a component under the selected avatar root yet. Pick the component manually or check the Avatar Root field.", MessageType.Warning);
                        }
                    }

                    if (control.controlType == PuddlesAvatarControlType.Toggle)
                    {
                        DrawObjectStateValueField("Toggle Off", ref action.offWriteMode, ref action.offBool);
                        DrawObjectStateValueField("Toggle On", ref action.onWriteMode, ref action.onBool);
                    }
                    break;

                case PuddlesAvatarActionKind.RawBinding:
                    DrawRawBindingFields(control, action);
                    break;

                case PuddlesAvatarActionKind.ShaderFloat:
                    EditorGUI.BeginChangeCheck();
                    action.renderer = (Renderer)EditorGUILayout.ObjectField("Renderer", action.renderer, typeof(Renderer), true);
                    if (EditorGUI.EndChangeCheck())
                    {
                        StoreActionReferencePaths(action);
                    }

                    action.materialSlot = Mathf.Max(0, EditorGUILayout.IntField("Material Slot", action.materialSlot));
                    DrawShaderPropertyPasteField(action);
                    DrawShaderFloatPicker(action);
                    if (control.controlType == PuddlesAvatarControlType.Radial)
                    {
                        action.offFloat = EditorGUILayout.FloatField("Radial 0 Value", action.offFloat);
                        action.onFloat = EditorGUILayout.FloatField("Radial 1 Value", action.onFloat);
                    }
                    else if (control.controlType == PuddlesAvatarControlType.Toggle)
                    {
                        DrawFloatWriteValueField("Toggle Off", ref action.offWriteMode, ref action.offFloat);
                        DrawFloatWriteValueField("Toggle On", ref action.onWriteMode, ref action.onFloat);
                        using (new EditorGUI.DisabledScope(!CanReadShaderFloat(action)))
                        {
                            if (GUILayout.Button("Use Current As Toggle Off Value"))
                            {
                                Material material = GetRendererMaterialAtSlot(action.renderer, action.materialSlot);
                                action.offFloat = material.GetFloat(action.shaderPropertyName);
                            }
                        }
                    }
                    break;

                case PuddlesAvatarActionKind.SetAnotherToggle:
                    DrawSetAnotherToggleFields(control, action);
                    break;
            }
        }

        private void DrawSetAnotherToggleFields(PuddlesAvatarActionControl control, PuddlesAvatarActionRow action)
        {
            if (control.controlType != PuddlesAvatarControlType.Toggle)
            {
                EditorGUILayout.HelpBox("Set Control rows are only supported on Toggle controls.", MessageType.Info);
                return;
            }

            List<PuddlesAvatarActionControl> targets = profile.controls
                .Where(candidate => candidate != null
                    && (candidate.controlType == PuddlesAvatarControlType.Toggle || candidate.controlType == PuddlesAvatarControlType.Selector)
                    && !string.Equals(candidate.id, control.id, StringComparison.Ordinal))
                .OrderBy(candidate => candidate.displayName, StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (targets.Count == 0)
            {
                EditorGUILayout.HelpBox("Create another Action Builder toggle or selector before using Set Control.", MessageType.Info);
                action.targetControlId = string.Empty;
                action.targetControlLabel = string.Empty;
                return;
            }

            int currentIndex = targets.FindIndex(candidate => string.Equals(candidate.id, action.targetControlId, StringComparison.Ordinal));
            if (currentIndex < 0)
            {
                currentIndex = 0;
                action.targetControlId = targets[0].id;
                action.targetControlLabel = targets[0].displayName;
            }

            string[] labels = targets.Select(candidate =>
            {
                string name = string.IsNullOrWhiteSpace(candidate.displayName) ? "(Unnamed Control)" : candidate.displayName;
                return $"{name} [{candidate.controlType}]";
            }).ToArray();
            int nextIndex = EditorGUILayout.Popup("Target Control", currentIndex, labels);
            PuddlesAvatarActionControl target = targets[Mathf.Clamp(nextIndex, 0, targets.Count - 1)];
            action.targetControlId = target.id;
            action.targetControlLabel = target.displayName;

            if (target.controlType == PuddlesAvatarControlType.Selector)
            {
                EnsureSelectorOptions(target);
                DrawSelectorSetValueField("Toggle Off", target, ref action.offWriteMode, ref action.offTargetOptionId, ref action.offFloat);
                DrawSelectorSetValueField("Toggle On", target, ref action.onWriteMode, ref action.onTargetOptionId, ref action.onFloat);
                EditorGUILayout.LabelField("Generated avatar will set the target selector option. Live Preview does not simulate this yet.", EditorStyles.wordWrappedMiniLabel);
            }
            else
            {
                DrawToggleSetValueField("Toggle Off", ref action.offWriteMode, ref action.offBool);
                DrawToggleSetValueField("Toggle On", ref action.onWriteMode, ref action.onBool);
                EditorGUILayout.LabelField("Generated avatar will set the target toggle parameter. Live Preview does not simulate this yet.", EditorStyles.wordWrappedMiniLabel);
            }
        }

        private void DrawSelectorActionValues(PuddlesAvatarActionControl control, PuddlesAvatarActionRow action)
        {
            EnsureActionOptionValues(control, action);
            EditorGUILayout.LabelField("Option Values", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                foreach (PuddlesAvatarSelectorOption option in control.selectorOptions)
                {
                    PuddlesAvatarActionOptionValue value = GetOptionValue(action, option.id);
                    string label = string.IsNullOrWhiteSpace(option.displayName) ? "(Unnamed)" : option.displayName;
                    using (new EditorGUILayout.VerticalScope(GUILayout.Width(170)))
                    {
                        EditorGUILayout.LabelField(label, EditorStyles.miniBoldLabel);
                        switch (action.kind)
                        {
                            case PuddlesAvatarActionKind.ObjectState:
                            case PuddlesAvatarActionKind.ComponentEnabled:
                                DrawObjectStateValueField(string.Empty, ref value.writeMode, ref value.boolValue);
                                break;
                            case PuddlesAvatarActionKind.Blendshape:
                            case PuddlesAvatarActionKind.ShaderFloat:
                                DrawFloatWriteValueField(string.Empty, ref value.writeMode, ref value.floatValue);
                                break;
                            case PuddlesAvatarActionKind.MaterialSwap:
                                DrawMaterialWriteValueField(string.Empty, ref value.writeMode, ref value.materialValue);
                                break;
                            case PuddlesAvatarActionKind.RawBinding:
                                EditorGUILayout.LabelField("Preserved for toggles only.", EditorStyles.wordWrappedMiniLabel);
                                break;
                        }
                    }
                }
            }
        }

        private static void DrawRawBindingFields(PuddlesAvatarActionControl control, PuddlesAvatarActionRow action)
        {
            EditorGUILayout.LabelField("Raw Preserved Binding", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Path", string.IsNullOrWhiteSpace(action.rawBindingPath) ? "(Avatar Root)" : action.rawBindingPath);
            EditorGUILayout.LabelField("Type", GetComponentTypeDisplayName(action.rawBindingTypeName));
            EditorGUILayout.LabelField("Property", string.IsNullOrWhiteSpace(action.rawBindingPropertyName) ? "(Unknown Property)" : action.rawBindingPropertyName);
            EditorGUILayout.LabelField("Kind", action.rawBindingValueKind.ToString());

            if (control.controlType == PuddlesAvatarControlType.Toggle)
            {
                DrawRawBindingValueField("Toggle Off", action.rawBindingValueKind, ref action.offWriteMode, ref action.offFloat, ref action.offObjectReference);
                DrawRawBindingValueField("Toggle On", action.rawBindingValueKind, ref action.onWriteMode, ref action.onFloat, ref action.onObjectReference);
                EditorGUILayout.LabelField("Raw rows preserve imported bindings. Advanced editing comes later.", EditorStyles.wordWrappedMiniLabel);
            }
        }

        private static void DrawRawBindingValueField(string label, PuddlesAvatarRawBindingValueKind valueKind, ref PuddlesAvatarWriteMode writeMode, ref float floatValue, ref UnityEngine.Object objectValue)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                int selected = writeMode == PuddlesAvatarWriteMode.NoChange ? 0 : 1;
                int next = EditorGUILayout.Popup(label, selected, new[] { "No Change", "Preserve Value" }, GUILayout.MaxWidth(260));
                writeMode = next == 0 ? PuddlesAvatarWriteMode.NoChange : PuddlesAvatarWriteMode.Set;
                using (new EditorGUI.DisabledScope(true))
                {
                    if (valueKind == PuddlesAvatarRawBindingValueKind.ObjectReference)
                    {
                        EditorGUILayout.ObjectField(objectValue, typeof(UnityEngine.Object), false);
                    }
                    else
                    {
                        EditorGUILayout.FloatField(floatValue);
                    }
                }
            }
        }

        private static void DrawObjectStateValueField(string label, ref PuddlesAvatarWriteMode writeMode, ref bool activeValue)
        {
            GUIContent content = string.IsNullOrEmpty(label) ? GUIContent.none : new GUIContent(label);
            int selected = writeMode == PuddlesAvatarWriteMode.NoChange ? 0 : activeValue ? 2 : 1;
            int next = EditorGUILayout.Popup(content, selected, new[] { "No Change", "Inactive", "Active" });
            if (next == 0)
            {
                writeMode = PuddlesAvatarWriteMode.NoChange;
                return;
            }

            writeMode = PuddlesAvatarWriteMode.Set;
            activeValue = next == 2;
        }

        private static void DrawToggleSetValueField(string label, ref PuddlesAvatarWriteMode writeMode, ref bool toggleValue)
        {
            GUIContent content = string.IsNullOrEmpty(label) ? GUIContent.none : new GUIContent(label);
            int selected = writeMode == PuddlesAvatarWriteMode.NoChange ? 0 : toggleValue ? 2 : 1;
            int next = EditorGUILayout.Popup(content, selected, new[] { "No Change", "Set Off", "Set On" });
            if (next == 0)
            {
                writeMode = PuddlesAvatarWriteMode.NoChange;
                return;
            }

            writeMode = PuddlesAvatarWriteMode.Set;
            toggleValue = next == 2;
        }

        private static void DrawSelectorSetValueField(string label, PuddlesAvatarActionControl target, ref PuddlesAvatarWriteMode writeMode, ref string optionId, ref float optionIndexValue)
        {
            List<PuddlesAvatarSelectorOption> options = target != null && target.selectorOptions != null
                ? target.selectorOptions
                : new List<PuddlesAvatarSelectorOption>();
            string[] labels = new[] { "No Change" }
                .Concat(options.Select((option, index) => string.IsNullOrWhiteSpace(option.displayName) ? $"Option {index + 1}" : option.displayName))
                .ToArray();

            int selected = 0;
            if (writeMode == PuddlesAvatarWriteMode.Set && options.Count > 0)
            {
                string selectedOptionId = optionId;
                int optionIndex = options.FindIndex(option => string.Equals(option.id, selectedOptionId, StringComparison.Ordinal));
                if (optionIndex < 0)
                {
                    optionIndex = Mathf.Clamp(Mathf.RoundToInt(optionIndexValue), 0, options.Count - 1);
                }

                selected = optionIndex + 1;
            }

            int next = EditorGUILayout.Popup(label, selected, labels);
            if (next == 0 || options.Count == 0)
            {
                writeMode = PuddlesAvatarWriteMode.NoChange;
                return;
            }

            int selectedOptionIndex = Mathf.Clamp(next - 1, 0, options.Count - 1);
            writeMode = PuddlesAvatarWriteMode.Set;
            optionId = options[selectedOptionIndex].id;
            optionIndexValue = selectedOptionIndex;
        }

        private static void DrawFloatWriteValueField(string label, ref PuddlesAvatarWriteMode writeMode, ref float value)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUIContent content = string.IsNullOrEmpty(label) ? GUIContent.none : new GUIContent(label);
                int selected = writeMode == PuddlesAvatarWriteMode.NoChange ? 0 : 1;
                int next = EditorGUILayout.Popup(content, selected, new[] { "No Change", "Set Value" }, GUILayout.MaxWidth(string.IsNullOrEmpty(label) ? 95 : 260));
                writeMode = next == 0 ? PuddlesAvatarWriteMode.NoChange : PuddlesAvatarWriteMode.Set;
                using (new EditorGUI.DisabledScope(writeMode == PuddlesAvatarWriteMode.NoChange))
                {
                    value = EditorGUILayout.FloatField(value);
                }
            }
        }

        private static void DrawMaterialWriteValueField(string label, ref PuddlesAvatarWriteMode writeMode, ref Material material)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUIContent content = string.IsNullOrEmpty(label) ? GUIContent.none : new GUIContent(label);
                int selected = writeMode == PuddlesAvatarWriteMode.NoChange ? 0 : 1;
                int next = EditorGUILayout.Popup(content, selected, new[] { "No Change", "Set Material" }, GUILayout.MaxWidth(string.IsNullOrEmpty(label) ? 95 : 260));
                writeMode = next == 0 ? PuddlesAvatarWriteMode.NoChange : PuddlesAvatarWriteMode.Set;
                using (new EditorGUI.DisabledScope(writeMode == PuddlesAvatarWriteMode.NoChange))
                {
                    material = (Material)EditorGUILayout.ObjectField(material, typeof(Material), false);
                }
            }
        }

        private void DrawBlendshapePicker(PuddlesAvatarActionRow action)
        {
            if (action.skinnedRenderer == null || action.skinnedRenderer.sharedMesh == null)
            {
                action.blendshapeName = EditorGUILayout.TextField("Blendshape", action.blendshapeName);
                return;
            }

            Mesh mesh = action.skinnedRenderer.sharedMesh;
            List<string> names = new List<string>();
            for (int i = 0; i < mesh.blendShapeCount; i++)
            {
                names.Add(mesh.GetBlendShapeName(i));
            }

            if (names.Count == 0)
            {
                action.blendshapeName = EditorGUILayout.TextField("Blendshape", action.blendshapeName);
                return;
            }

            int index = Mathf.Max(0, names.IndexOf(action.blendshapeName));
            int nextIndex = EditorGUILayout.Popup("Blendshape", index, names.ToArray());
            action.blendshapeName = names[nextIndex];
        }

        private void DrawShaderFloatPicker(PuddlesAvatarActionRow action)
        {
            Material material = GetRendererMaterialAtSlot(action.renderer, action.materialSlot);
            if (material == null || material.shader == null)
            {
                action.shaderPropertyName = EditorGUILayout.TextField("Shader Property", action.shaderPropertyName);
                return;
            }

            List<string> propertyNames = new List<string>();
            int propertyCount = ShaderUtil.GetPropertyCount(material.shader);
            for (int i = 0; i < propertyCount; i++)
            {
                ShaderUtil.ShaderPropertyType type = ShaderUtil.GetPropertyType(material.shader, i);
                if (type == ShaderUtil.ShaderPropertyType.Float || type == ShaderUtil.ShaderPropertyType.Range)
                {
                    propertyNames.Add(ShaderUtil.GetPropertyName(material.shader, i));
                }
            }

            if (propertyNames.Count == 0)
            {
                action.shaderPropertyName = EditorGUILayout.TextField("Shader Property", action.shaderPropertyName);
                return;
            }

            int currentIndex = propertyNames.IndexOf(action.shaderPropertyName);
            currentIndex = currentIndex < 0 ? 0 : currentIndex;
            int nextIndex = EditorGUILayout.Popup("Shader Property", currentIndex, propertyNames.ToArray());
            action.shaderPropertyName = propertyNames[nextIndex];
        }

        private void DrawShaderPropertyPasteField(PuddlesAvatarActionRow action)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                action.shaderPropertyPaste = EditorGUILayout.TextField("Paste Property", action.shaderPropertyPaste);
                if (GUILayout.Button("Apply", GUILayout.Width(70)))
                {
                    ApplyShaderPropertyPaste(action);
                }
            }

            EditorGUILayout.LabelField("Paste Unity copied property names like _LightingCap, material._LightingCap, or Body : Renderer.material.[1]._Color.", EditorStyles.wordWrappedMiniLabel);
        }

        private void ApplyShaderPropertyPaste(PuddlesAvatarActionRow action)
        {
            if (action == null || string.IsNullOrWhiteSpace(action.shaderPropertyPaste))
            {
                return;
            }

            if (!TryParseShaderPropertyPaste(action.shaderPropertyPaste, out string rendererPath, out int materialSlot, out string shaderPropertyName))
            {
                EditorUtility.DisplayDialog("Shader Property Paste", "Could not understand that pasted property. Try Copy Property Name or Copy Animated Property Name from Unity's property context menu.", "OK");
                return;
            }

            if (!string.IsNullOrWhiteSpace(rendererPath))
            {
                Transform target = FindAvatarTransform(rendererPath);
                Renderer renderer = target != null ? target.GetComponent<Renderer>() : null;
                if (renderer != null)
                {
                    action.renderer = renderer;
                    StoreActionReferencePaths(action);
                }
                else
                {
                    Debug.LogWarning($"Puddles Action Builder could not resolve pasted renderer path '{rendererPath}'. Pick the renderer manually; the material slot and shader property were still applied.");
                }
            }

            action.materialSlot = Mathf.Max(0, materialSlot);
            action.shaderPropertyName = shaderPropertyName;
            StoreActionReferencePaths(action);
        }

        private static bool TryParseShaderPropertyPaste(string pastedText, out string rendererPath, out int materialSlot, out string shaderPropertyName)
        {
            rendererPath = string.Empty;
            materialSlot = 0;
            shaderPropertyName = string.Empty;
            string text = (pastedText ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            int colonIndex = text.IndexOf(':');
            if (colonIndex >= 0)
            {
                rendererPath = text.Substring(0, colonIndex).Trim();
                text = text.Substring(colonIndex + 1).Trim();
            }

            int materialIndex = text.IndexOf("material.", StringComparison.Ordinal);
            if (materialIndex >= 0)
            {
                text = text.Substring(materialIndex);
                return TryParseShaderFloatProperty(text, out materialSlot, out shaderPropertyName);
            }

            int lastDot = text.LastIndexOf('.');
            if (lastDot >= 0)
            {
                string maybePath = text.Substring(0, lastDot).Trim();
                string maybeProperty = text.Substring(lastDot + 1).Trim();
                if (LooksLikeShaderProperty(maybeProperty))
                {
                    if (string.IsNullOrWhiteSpace(rendererPath) && !string.IsNullOrWhiteSpace(maybePath))
                    {
                        rendererPath = maybePath;
                    }

                    shaderPropertyName = maybeProperty;
                    return true;
                }
            }

            shaderPropertyName = text;
            return LooksLikeShaderProperty(shaderPropertyName);
        }

        private static bool LooksLikeShaderProperty(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Contains("/") || value.Contains("\\") || value.Contains(" "))
            {
                return false;
            }

            return value.StartsWith("_", StringComparison.Ordinal) || value.All(character => char.IsLetterOrDigit(character) || character == '_');
        }

        private static bool TryParseShaderFloatProperty(string propertyName, out int materialSlot, out string shaderPropertyName)
        {
            materialSlot = 0;
            shaderPropertyName = string.Empty;
            const string prefix = "material.";
            if (string.IsNullOrWhiteSpace(propertyName) || !propertyName.StartsWith(prefix, StringComparison.Ordinal))
            {
                return false;
            }

            string rest = propertyName.Substring(prefix.Length);
            if (rest.StartsWith("[", StringComparison.Ordinal))
            {
                int closeIndex = rest.IndexOf("].", StringComparison.Ordinal);
                if (closeIndex <= 1 || !int.TryParse(rest.Substring(1, closeIndex - 1), out materialSlot))
                {
                    return false;
                }

                shaderPropertyName = rest.Substring(closeIndex + 2);
            }
            else
            {
                shaderPropertyName = rest;
            }

            return !string.IsNullOrWhiteSpace(shaderPropertyName) && !shaderPropertyName.Contains(".");
        }

        private void DrawBottomActions()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    PuddlesAvatarActionControl selected = GetSelectedControl();
                    using (new EditorGUI.DisabledScope(!CanGenerate() || selected == null))
                    {
                        if (GUILayout.Button("Generate Selected", GUILayout.Height(28)))
                        {
                            GenerateControls(new List<PuddlesAvatarActionControl> { selected }, true);
                        }
                    }

                    using (new EditorGUI.DisabledScope(!CanGenerate() || profile.controls.Count == 0))
                    {
                        if (GUILayout.Button("Generate All", GUILayout.Height(28)))
                        {
                            GenerateControls(profile.controls.ToList(), true);
                        }
                    }

                    using (new EditorGUI.DisabledScope(selected == null))
                    {
                        if (GUILayout.Button("Delete Selected Generated Assets", GUILayout.Height(28)))
                        {
                            DeleteSelectedGeneratedAssets();
                        }
                    }
                }

                EditorGUILayout.LabelField("Use Delete above to remove a control and its generated assets.", EditorStyles.wordWrappedMiniLabel);
            }
        }

        private void CreateProfileAsset()
        {
            EnsureFolder(DefaultProfileFolder);
            PuddlesAvatarActionProfile newProfile = CreateInstance<PuddlesAvatarActionProfile>();
            newProfile.outputFolder = DefaultOutputFolder;
            newProfile.parameterPrefix = DefaultParameterPrefix;
            newProfile.generatedMenuName = "Avatar Actions";
            newProfile.managedSubmenus = new List<PuddlesAvatarManagedSubmenu>();

            string assetName = "Avatar Action Profile.asset";
            if (profile != null && profile.avatarRoot != null)
            {
                assetName = $"{SanitizeAssetName(profile.avatarRoot.name)} Action Profile.asset";
            }

            string path = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(DefaultProfileFolder, assetName).Replace("\\", "/"));
            AssetDatabase.CreateAsset(newProfile, path);
            AssetDatabase.SaveAssets();
            profile = newProfile;
            profileRenamePath = path;
            profileRenameName = Path.GetFileNameWithoutExtension(path);
            selectedControlId = null;
        }

        private void RenameCurrentProfile(string requestedName)
        {
            if (profile == null)
            {
                return;
            }

            string path = AssetDatabase.GetAssetPath(profile);
            if (string.IsNullOrWhiteSpace(path))
            {
                EditorUtility.DisplayDialog("Avatar Action Builder", "This profile is not saved as an asset yet.", "OK");
                return;
            }

            string cleanName = SanitizeAssetName(requestedName);
            if (string.IsNullOrWhiteSpace(cleanName))
            {
                EditorUtility.DisplayDialog("Avatar Action Builder", "Profile name cannot be empty.", "OK");
                profileRenameName = Path.GetFileNameWithoutExtension(path);
                return;
            }

            string currentName = Path.GetFileNameWithoutExtension(path);
            if (string.Equals(cleanName, currentName, StringComparison.Ordinal))
            {
                profileRenameName = currentName;
                return;
            }

            string error = AssetDatabase.RenameAsset(path, cleanName);
            if (!string.IsNullOrEmpty(error))
            {
                EditorUtility.DisplayDialog("Avatar Action Builder", $"Could not rename profile:\n{error}", "OK");
                profileRenameName = currentName;
                return;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            profileRenamePath = AssetDatabase.GetAssetPath(profile);
            profileRenameName = Path.GetFileNameWithoutExtension(profileRenamePath);
        }

        private static void ShowProfilesFolder(string profilePath)
        {
            string folderPath = string.IsNullOrWhiteSpace(profilePath)
                ? DefaultProfileFolder
                : Path.GetDirectoryName(profilePath)?.Replace("\\", "/");

            if (string.IsNullOrWhiteSpace(folderPath))
            {
                folderPath = DefaultProfileFolder;
            }

            EnsureFolder(folderPath);
            DefaultAsset folderAsset = AssetDatabase.LoadAssetAtPath<DefaultAsset>(folderPath);
            if (folderAsset != null)
            {
                EditorUtility.FocusProjectWindow();
                Selection.activeObject = folderAsset;
                EditorGUIUtility.PingObject(folderAsset);
            }
        }

        private void AutoFillFromAvatarDescriptor()
        {
            if (profile.avatarRoot == null)
            {
                return;
            }

            VRCAvatarDescriptor descriptor = profile.avatarRoot.GetComponent<VRCAvatarDescriptor>();
            if (descriptor == null)
            {
                EditorUtility.DisplayDialog("Avatar Action Builder", "No VRCAvatarDescriptor was found on the avatar root.", "OK");
                return;
            }

            profile.expressionParameters = descriptor.expressionParameters;
            profile.rootMenu = descriptor.expressionsMenu;

            if (descriptor.baseAnimationLayers != null)
            {
                foreach (var layer in descriptor.baseAnimationLayers)
                {
                    if (layer.type == VRCAvatarDescriptor.AnimLayerType.FX && layer.animatorController != null)
                    {
                        profile.fxController = layer.animatorController as AnimatorController;
                        break;
                    }
                }
            }

            MarkProfileDirty();
        }

        private void AddControl(PuddlesAvatarControlType controlType)
        {
            if (profile == null)
            {
                return;
            }

            VRCExpressionsMenu destinationMenu = profile.lastDestinationMenu != null ? profile.lastDestinationMenu : profile.rootMenu;
            string destinationPath = !string.IsNullOrWhiteSpace(profile.lastDestinationPath) ? profile.lastDestinationPath : "Root";

            PuddlesAvatarActionControl control = new PuddlesAvatarActionControl
            {
                id = CreateStableId(),
                displayName = controlType == PuddlesAvatarControlType.Toggle ? "New Toggle" : $"New {controlType}",
                controlType = controlType,
                menuPath = string.Empty,
                destinationMenu = destinationMenu,
                destinationPath = destinationPath,
                saved = true,
                synced = true,
                defaultValue = false,
                radialMode = controlType == PuddlesAvatarControlType.Radial
                    ? PuddlesAvatarRadialMode.TimeParameter
                    : PuddlesAvatarRadialMode.BlendTree
            };

            EnsureControlDefaults(control);
            profile.controls.Add(control);
            selectedControlId = control.id;
            MarkProfileDirty();
        }

        private void DuplicateSelectedControl()
        {
            PuddlesAvatarActionControl selected = GetSelectedControl();
            if (selected == null)
            {
                return;
            }

            PuddlesAvatarActionControl copy = JsonUtility.FromJson<PuddlesAvatarActionControl>(JsonUtility.ToJson(selected));
            copy.id = CreateStableId();
            copy.displayName = $"{selected.displayName} Copy";
            profile.controls.Add(copy);
            selectedControlId = copy.id;
            MarkProfileDirty();
        }

        private void EnsureControlDefaults(PuddlesAvatarActionControl control)
        {
            if (control == null)
            {
                return;
            }

            if (control.actions == null)
            {
                control.actions = new List<PuddlesAvatarActionRow>();
            }

            control.radialDefaultValue = Mathf.Clamp01(control.radialDefaultValue);
            if (control.controlType == PuddlesAvatarControlType.Selector)
            {
                EnsureSelectorOptions(control);
                foreach (PuddlesAvatarActionRow action in control.actions)
                {
                    EnsureActionOptionValues(control, action);
                }
            }
        }

        private void EnsureSelectorOptions(PuddlesAvatarActionControl control)
        {
            if (control.selectorOptions == null)
            {
                control.selectorOptions = new List<PuddlesAvatarSelectorOption>();
            }

            if (control.selectorOptions.Count == 0)
            {
                control.selectorOptions.Add(new PuddlesAvatarSelectorOption { id = CreateStableId(), displayName = "Option 1" });
                control.selectorOptions.Add(new PuddlesAvatarSelectorOption { id = CreateStableId(), displayName = "Option 2" });
            }

            for (int i = 0; i < control.selectorOptions.Count; i++)
            {
                PuddlesAvatarSelectorOption option = control.selectorOptions[i];
                if (string.IsNullOrWhiteSpace(option.id))
                {
                    option.id = CreateStableId();
                }

                if (string.IsNullOrWhiteSpace(option.displayName))
                {
                    option.displayName = $"Option {i + 1}";
                }
            }

            control.selectorDefaultIndex = Mathf.Clamp(control.selectorDefaultIndex, 0, Mathf.Max(0, control.selectorOptions.Count - 1));
        }

        private void EnsureActionOptionValues(PuddlesAvatarActionControl control, PuddlesAvatarActionRow action)
        {
            if (action.optionValues == null)
            {
                action.optionValues = new List<PuddlesAvatarActionOptionValue>();
            }

            for (int i = 0; i < control.selectorOptions.Count; i++)
            {
                PuddlesAvatarSelectorOption option = control.selectorOptions[i];
                if (action.optionValues.Any(value => value.optionId == option.id))
                {
                    continue;
                }

                action.optionValues.Add(new PuddlesAvatarActionOptionValue
                {
                    optionId = option.id,
                    writeMode = i == 0 ? action.offWriteMode : i == 1 ? action.onWriteMode : PuddlesAvatarWriteMode.Set,
                    boolValue = i == 0 ? action.offBool : i == 1 ? action.onBool : false,
                    floatValue = i == 0 ? action.offFloat : i == 1 ? action.onFloat : 0f,
                    materialValue = i == 0 ? action.offMaterial : i == 1 ? action.onMaterial : null
                });
            }

            HashSet<string> optionIds = new HashSet<string>(control.selectorOptions.Select(option => option.id), StringComparer.Ordinal);
            action.optionValues.RemoveAll(value => value == null || !optionIds.Contains(value.optionId));
        }

        private static PuddlesAvatarActionOptionValue GetOptionValue(PuddlesAvatarActionRow action, string optionId)
        {
            if (action.optionValues == null)
            {
                action.optionValues = new List<PuddlesAvatarActionOptionValue>();
            }

            PuddlesAvatarActionOptionValue value = action.optionValues.FirstOrDefault(existing => existing.optionId == optionId);
            if (value == null)
            {
                value = new PuddlesAvatarActionOptionValue { optionId = optionId };
                action.optionValues.Add(value);
            }

            return value;
        }

        private void RemoveSelectedControl()
        {
            PuddlesAvatarActionControl selected = GetSelectedControl();
            if (selected == null)
            {
                return;
            }

            DeleteGeneratedArtifacts(selected, true);
            profile.controls.Remove(selected);
            selectedControlId = profile.controls.Count > 0 ? profile.controls[0].id : null;
            MarkProfileDirty();
        }

        private void ConfirmAndRemoveSelectedControl()
        {
            PuddlesAvatarActionControl selected = GetSelectedControl();
            if (selected == null)
            {
                return;
            }

            string label = string.IsNullOrWhiteSpace(selected.displayName) ? "(Unnamed Toggle)" : selected.displayName;
            if (!EditorUtility.DisplayDialog(
                "Delete Control",
                $"Delete '{label}' from this profile and remove its generated menu item, parameter, FX layer, and clips?",
                "Delete",
                "Cancel"))
            {
                return;
            }

            RemoveSelectedControl();
        }

        private void DeleteSelectedGeneratedAssets()
        {
            PuddlesAvatarActionControl selected = GetSelectedControl();
            if (selected == null)
            {
                return;
            }

            DeleteGeneratedArtifacts(selected, true);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private bool CanGenerate()
        {
            return profile != null
                && profile.avatarRoot != null
                && profile.fxController != null
                && profile.expressionParameters != null
                && profile.rootMenu != null
                && IsProjectAssetFolder(GetOutputFolder())
                && !string.IsNullOrWhiteSpace(GetOutputFolder())
                && !string.IsNullOrWhiteSpace(GetParameterPrefix());
        }

        private static VRCExpressionParameters.ValueType GetExpressionValueType(PuddlesAvatarActionControl control)
        {
            switch (control.controlType)
            {
                case PuddlesAvatarControlType.Radial:
                    return VRCExpressionParameters.ValueType.Float;
                case PuddlesAvatarControlType.Selector:
                    return VRCExpressionParameters.ValueType.Int;
                default:
                    return VRCExpressionParameters.ValueType.Bool;
            }
        }

        private static float GetExpressionDefaultValue(PuddlesAvatarActionControl control)
        {
            switch (control.controlType)
            {
                case PuddlesAvatarControlType.Radial:
                    return Mathf.Clamp01(control.radialDefaultValue);
                case PuddlesAvatarControlType.Selector:
                    return Mathf.Max(0, control.selectorDefaultIndex);
                default:
                    return control.defaultValue ? 1f : 0f;
            }
        }

        internal static bool GenerateControlsForProfile(PuddlesAvatarActionProfile actionProfile, List<PuddlesAvatarActionControl> controls, bool showDialog)
        {
            AvatarActionBuilderWindow generator = CreateInstance<AvatarActionBuilderWindow>();
            generator.profile = actionProfile;
            try
            {
                return generator.GenerateControls(controls, showDialog);
            }
            finally
            {
                DestroyImmediate(generator);
            }
        }

        private bool GenerateControls(List<PuddlesAvatarActionControl> controls, bool showDialog)
        {
            if (!CanGenerate())
            {
                if (showDialog)
                {
                    EditorUtility.DisplayDialog("Avatar Action Builder", "Assign avatar root, FX controller, expression parameters, root menu, and an Assets-relative output folder first.", "OK");
                }
                return false;
            }

            try
            {
                string outputFolder = GetProfileGenerationFolder();
                EnsureFolder(outputFolder);

                foreach (PuddlesAvatarActionControl control in controls)
                {
                    if (string.IsNullOrWhiteSpace(control.id))
                    {
                        control.id = CreateStableId();
                    }

                    EnsureControlDefaults(control);
                    DeleteGeneratedArtifacts(control, false);
                    AddExpressionParameter(control);
                    GenerateAnimatorLayer(control, outputFolder);
                    if (!AddMenuControl(control, outputFolder))
                    {
                        if (showDialog)
                        {
                            EditorUtility.DisplayDialog("Avatar Action Builder", $"Generated animator assets for '{control.displayName}', but could not add its menu control. Check whether the destination menu is full or missing.", "OK");
                        }
                        return false;
                    }
                }

                MarkProfileDirty();
                EditorUtility.SetDirty(profile.rootMenu);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                if (showDialog)
                {
                    EditorUtility.DisplayDialog("Avatar Action Builder", $"Generated {controls.Count} control(s).", "OK");
                }
                return true;
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                if (showDialog)
                {
                    EditorUtility.DisplayDialog("Avatar Action Builder", $"Generation failed:\n{ex.Message}", "OK");
                }
                return false;
            }
        }

        private void AddExpressionParameter(PuddlesAvatarActionControl control)
        {
            string parameterName = BuildParameterName(control);
            VRCExpressionParameters.ValueType valueType = GetExpressionValueType(control);
            float defaultValue = GetExpressionDefaultValue(control);
            List<VRCExpressionParameters.Parameter> parameters = profile.expressionParameters.parameters != null
                ? profile.expressionParameters.parameters.ToList()
                : new List<VRCExpressionParameters.Parameter>();

            VRCExpressionParameters.Parameter existing = parameters.FirstOrDefault(parameter => parameter.name == parameterName);
            if (existing != null)
            {
                existing.valueType = valueType;
                existing.defaultValue = defaultValue;
                existing.saved = control.saved;
                existing.networkSynced = control.synced;
            }
            else
            {
                parameters.Add(new VRCExpressionParameters.Parameter
                {
                    name = parameterName,
                    valueType = valueType,
                    defaultValue = defaultValue,
                    saved = control.saved,
                    networkSynced = control.synced
                });
            }

            profile.expressionParameters.parameters = parameters.ToArray();
            EditorUtility.SetDirty(profile.expressionParameters);
        }

        private void UpgradeGeneratedParameterNames()
        {
            if (profile == null || profile.controls == null)
            {
                return;
            }

            int changedCount = 0;
            foreach (PuddlesAvatarActionControl control in profile.controls)
            {
                EnsureControlDefaults(control);
                string newName = BuildParameterName(control);
                List<string> oldNames = GetParameterNamesForControl(control)
                    .Where(name => !string.IsNullOrWhiteSpace(name) && !string.Equals(name, newName, StringComparison.OrdinalIgnoreCase))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();

                foreach (string oldName in oldNames)
                {
                    if (RenameParameterReferences(oldName, newName))
                    {
                        changedCount++;
                    }
                }
            }

            if (changedCount > 0)
            {
                MarkProfileDirty();
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }

            EditorUtility.DisplayDialog(
                "Upgrade Generated Parameter Names",
                changedCount > 0
                    ? $"Updated {changedCount} generated parameter reference(s)."
                    : "No old generated parameter names were found to update.",
                "OK");
        }

        private bool RenameParameterReferences(string oldName, string newName)
        {
            bool changed = false;
            changed |= RenameExpressionParameter(oldName, newName);
            changed |= RenameAnimatorParameter(oldName, newName);

            if (profile.rootMenu != null)
            {
                changed |= RenameMenuParameterReferences(profile.rootMenu, oldName, newName, new HashSet<VRCExpressionsMenu>());
            }

            if (profile.fxController != null)
            {
                foreach (AnimatorControllerLayer layer in profile.fxController.layers)
                {
                    if (RenameStateMachineParameterReferences(layer.stateMachine, oldName, newName, new HashSet<AnimatorStateMachine>()))
                    {
                        changed = true;
                    }

                    if (RenameMotionParameterReferences(layer.stateMachine, oldName, newName, new HashSet<Motion>()))
                    {
                        changed = true;
                    }
                }

                if (changed)
                {
                    EditorUtility.SetDirty(profile.fxController);
                }
            }

            return changed;
        }

        private bool RenameExpressionParameter(string oldName, string newName)
        {
            if (profile.expressionParameters == null || profile.expressionParameters.parameters == null)
            {
                return false;
            }

            bool changed = false;
            List<VRCExpressionParameters.Parameter> parameters = profile.expressionParameters.parameters
                .Where(parameter => parameter != null)
                .ToList();
            VRCExpressionParameters.Parameter newParameter = parameters.FirstOrDefault(parameter => string.Equals(parameter.name, newName, StringComparison.OrdinalIgnoreCase));
            for (int i = parameters.Count - 1; i >= 0; i--)
            {
                VRCExpressionParameters.Parameter parameter = parameters[i];
                if (!string.Equals(parameter.name, oldName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (newParameter == null)
                {
                    parameter.name = newName;
                    newParameter = parameter;
                }
                else
                {
                    parameters.RemoveAt(i);
                }

                changed = true;
            }

            if (changed)
            {
                profile.expressionParameters.parameters = parameters.ToArray();
                EditorUtility.SetDirty(profile.expressionParameters);
            }

            return changed;
        }

        private bool RenameAnimatorParameter(string oldName, string newName)
        {
            if (profile.fxController == null)
            {
                return false;
            }

            bool changed = false;
            AnimatorControllerParameter newParameter = profile.fxController.parameters.FirstOrDefault(parameter => string.Equals(parameter.name, newName, StringComparison.OrdinalIgnoreCase));
            foreach (AnimatorControllerParameter parameter in profile.fxController.parameters.ToArray())
            {
                if (!string.Equals(parameter.name, oldName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (newParameter == null)
                {
                    parameter.name = newName;
                    newParameter = parameter;
                }
                else
                {
                    profile.fxController.RemoveParameter(parameter);
                }

                changed = true;
            }

            if (changed)
            {
                EditorUtility.SetDirty(profile.fxController);
            }

            return changed;
        }

        private static bool RenameMenuParameterReferences(VRCExpressionsMenu menu, string oldName, string newName, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return false;
            }

            bool changed = false;
            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.parameter != null && string.Equals(control.parameter.name, oldName, StringComparison.OrdinalIgnoreCase))
                {
                    control.parameter.name = newName;
                    changed = true;
                }

                if (control.subParameters != null)
                {
                    foreach (VRCExpressionsMenu.Control.Parameter parameter in control.subParameters)
                    {
                        if (parameter != null && string.Equals(parameter.name, oldName, StringComparison.OrdinalIgnoreCase))
                        {
                            parameter.name = newName;
                            changed = true;
                        }
                    }
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    changed |= RenameMenuParameterReferences(control.subMenu, oldName, newName, visited);
                }
            }

            if (changed)
            {
                EditorUtility.SetDirty(menu);
            }

            return changed;
        }

        private static bool RenameStateMachineParameterReferences(AnimatorStateMachine stateMachine, string oldName, string newName, HashSet<AnimatorStateMachine> visited)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return false;
            }

            bool changed = false;
            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
            {
                changed |= RenameTransitionParameterReferences(transition, oldName, newName);
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state == null)
                {
                    continue;
                }

                foreach (AnimatorStateTransition transition in childState.state.transitions)
                {
                    changed |= RenameTransitionParameterReferences(transition, oldName, newName);
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                changed |= RenameStateMachineParameterReferences(childMachine.stateMachine, oldName, newName, visited);
            }

            if (changed)
            {
                EditorUtility.SetDirty(stateMachine);
            }

            return changed;
        }

        private static bool RenameTransitionParameterReferences(AnimatorStateTransition transition, string oldName, string newName)
        {
            if (transition == null || transition.conditions == null)
            {
                return false;
            }

            AnimatorCondition[] conditions = transition.conditions;
            bool changed = false;
            for (int i = 0; i < conditions.Length; i++)
            {
                if (string.Equals(conditions[i].parameter, oldName, StringComparison.OrdinalIgnoreCase))
                {
                    conditions[i].parameter = newName;
                    changed = true;
                }
            }

            if (changed)
            {
                transition.conditions = conditions;
                EditorUtility.SetDirty(transition);
            }

            return changed;
        }

        private static bool RenameMotionParameterReferences(AnimatorStateMachine stateMachine, string oldName, string newName, HashSet<Motion> visited)
        {
            if (stateMachine == null)
            {
                return false;
            }

            bool changed = false;
            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state != null)
                {
                    changed |= RenameMotionParameterReferences(childState.state.motion, oldName, newName, visited);
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                changed |= RenameMotionParameterReferences(childMachine.stateMachine, oldName, newName, visited);
            }

            return changed;
        }

        private static bool RenameMotionParameterReferences(Motion motion, string oldName, string newName, HashSet<Motion> visited)
        {
            if (motion == null || !visited.Add(motion))
            {
                return false;
            }

            bool changed = false;
            if (motion is BlendTree blendTree)
            {
                if (string.Equals(blendTree.blendParameter, oldName, StringComparison.OrdinalIgnoreCase))
                {
                    blendTree.blendParameter = newName;
                    changed = true;
                }

                if (string.Equals(blendTree.blendParameterY, oldName, StringComparison.OrdinalIgnoreCase))
                {
                    blendTree.blendParameterY = newName;
                    changed = true;
                }

                foreach (ChildMotion child in blendTree.children)
                {
                    changed |= RenameMotionParameterReferences(child.motion, oldName, newName, visited);
                }

                if (changed)
                {
                    EditorUtility.SetDirty(blendTree);
                }
            }

            return changed;
        }

        private void GenerateAnimatorLayer(PuddlesAvatarActionControl control, string outputFolder)
        {
            switch (control.controlType)
            {
                case PuddlesAvatarControlType.Radial:
                    GenerateRadialAnimatorLayer(control, outputFolder);
                    break;
                case PuddlesAvatarControlType.Selector:
                    GenerateSelectorAnimatorLayer(control, outputFolder);
                    break;
                default:
                    GenerateToggleAnimatorLayer(control, outputFolder);
                    break;
            }
        }

        private void GenerateToggleAnimatorLayer(PuddlesAvatarActionControl control, string outputFolder)
        {
            string parameterName = BuildParameterName(control);
            EnsureAnimatorParameter(parameterName, AnimatorControllerParameterType.Bool);

            AnimationClip offClip = CreateToggleClip(control, false, outputFolder);
            AnimationClip onClip = CreateToggleClip(control, true, outputFolder);

            string layerName = BuildLayerName(control);
            RemoveLayersForControl(control);
            profile.fxController.AddLayer(layerName);

            AnimatorControllerLayer[] layers = profile.fxController.layers;
            AnimatorControllerLayer layer = layers[layers.Length - 1];
            layer.defaultWeight = 1f;
            layers[layers.Length - 1] = layer;
            profile.fxController.layers = layers;

            AnimatorStateMachine stateMachine = profile.fxController.layers[profile.fxController.layers.Length - 1].stateMachine;
            AnimatorState offState = stateMachine.AddState("Off");
            offState.motion = offClip;
            offState.writeDefaultValues = false;
            AnimatorState onState = stateMachine.AddState("On");
            onState.motion = onClip;
            onState.writeDefaultValues = false;
            stateMachine.defaultState = control.defaultValue ? onState : offState;

            AddSetToggleParameterDrivers(control, offState, onState);

            AnimatorStateTransition toOn = offState.AddTransition(onState);
            ConfigureInstantTransition(toOn);
            toOn.AddCondition(AnimatorConditionMode.If, 0f, parameterName);

            AnimatorStateTransition toOff = onState.AddTransition(offState);
            ConfigureInstantTransition(toOff);
            toOff.AddCondition(AnimatorConditionMode.IfNot, 0f, parameterName);

            EditorUtility.SetDirty(profile.fxController);
        }

        private void AddSetToggleParameterDrivers(PuddlesAvatarActionControl control, AnimatorState offState, AnimatorState onState)
        {
            if (control == null || control.actions == null)
            {
                return;
            }

            foreach (PuddlesAvatarActionRow action in control.actions.Where(action => action != null && action.kind == PuddlesAvatarActionKind.SetAnotherToggle))
            {
                PuddlesAvatarActionControl target = ResolveSetControlTarget(control, action);
                if (target == null)
                {
                    Debug.LogWarning($"Avatar Action Builder skipped Set Control row on '{control.displayName}' because its target control is missing or invalid.");
                    continue;
                }

                string targetParameterName = BuildParameterName(target);
                EnsureAnimatorParameter(targetParameterName, target.controlType == PuddlesAvatarControlType.Selector
                    ? AnimatorControllerParameterType.Int
                    : AnimatorControllerParameterType.Bool);

                if (TryGetSetControlDriverValue(action, target, false, out float offValue))
                {
                    AddParameterDriverSet(offState, targetParameterName, offValue);
                }

                if (TryGetSetControlDriverValue(action, target, true, out float onValue))
                {
                    AddParameterDriverSet(onState, targetParameterName, onValue);
                }
            }
        }

        private PuddlesAvatarActionControl ResolveSetControlTarget(PuddlesAvatarActionControl sourceControl, PuddlesAvatarActionRow action)
        {
            if (profile == null || profile.controls == null || sourceControl == null || action == null || string.IsNullOrWhiteSpace(action.targetControlId))
            {
                return null;
            }

            PuddlesAvatarActionControl target = profile.controls.FirstOrDefault(control =>
                control != null
                && (control.controlType == PuddlesAvatarControlType.Toggle || control.controlType == PuddlesAvatarControlType.Selector)
                && !string.Equals(control.id, sourceControl.id, StringComparison.Ordinal)
                && string.Equals(control.id, action.targetControlId, StringComparison.Ordinal));
            if (target != null)
            {
                action.targetControlLabel = target.displayName;
            }

            return target;
        }

        private bool TryGetSetControlDriverValue(PuddlesAvatarActionRow action, PuddlesAvatarActionControl target, bool onState, out float value)
        {
            value = 0f;
            PuddlesAvatarWriteMode writeMode = onState ? action.onWriteMode : action.offWriteMode;
            if (writeMode == PuddlesAvatarWriteMode.NoChange)
            {
                return false;
            }

            if (target.controlType == PuddlesAvatarControlType.Toggle)
            {
                value = onState ? (action.onBool ? 1f : 0f) : (action.offBool ? 1f : 0f);
                return true;
            }

            if (target.controlType != PuddlesAvatarControlType.Selector)
            {
                return false;
            }

            EnsureSelectorOptions(target);
            if (target.selectorOptions == null || target.selectorOptions.Count == 0)
            {
                return false;
            }

            string optionId = onState ? action.onTargetOptionId : action.offTargetOptionId;
            float storedIndex = onState ? action.onFloat : action.offFloat;
            int optionIndex = target.selectorOptions.FindIndex(option => string.Equals(option.id, optionId, StringComparison.Ordinal));
            if (optionIndex < 0)
            {
                optionIndex = Mathf.Clamp(Mathf.RoundToInt(storedIndex), 0, target.selectorOptions.Count - 1);
            }

            value = optionIndex;
            return true;
        }

        private static void AddParameterDriverSet(AnimatorState state, string parameterName, float value)
        {
            if (state == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return;
            }

            VRCAvatarParameterDriver driver = state.behaviours.FirstOrDefault(behaviour => behaviour is VRCAvatarParameterDriver) as VRCAvatarParameterDriver;
            if (driver == null)
            {
                driver = state.AddStateMachineBehaviour(typeof(VRCAvatarParameterDriver)) as VRCAvatarParameterDriver;
            }

            if (driver == null)
            {
                return;
            }

            if (driver.parameters == null)
            {
                driver.parameters = new List<VRC.SDKBase.VRC_AvatarParameterDriver.Parameter>();
            }

            driver.parameters.Add(new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
            {
                name = parameterName,
                type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set,
                value = value
            });
        }

        private void GenerateRadialAnimatorLayer(PuddlesAvatarActionControl control, string outputFolder)
        {
            string parameterName = BuildParameterName(control);
            EnsureAnimatorParameter(parameterName, AnimatorControllerParameterType.Float);

            if (control.radialMode == PuddlesAvatarRadialMode.TimeParameter)
            {
                GenerateTimeParameterRadialAnimatorLayer(control, outputFolder, parameterName);
                return;
            }

            GenerateBlendTreeRadialAnimatorLayer(control, outputFolder, parameterName);
        }

        private void GenerateTimeParameterRadialAnimatorLayer(PuddlesAvatarActionControl control, string outputFolder, string parameterName)
        {
            AnimationClip clip = CreateRadialTimeParameterClip(control, outputFolder);

            string layerName = BuildLayerName(control);
            RemoveLayersForControl(control);
            profile.fxController.AddLayer(layerName);

            AnimatorControllerLayer[] layers = profile.fxController.layers;
            AnimatorControllerLayer layer = layers[layers.Length - 1];
            layer.defaultWeight = 1f;
            layers[layers.Length - 1] = layer;
            profile.fxController.layers = layers;

            AnimatorStateMachine stateMachine = profile.fxController.layers[profile.fxController.layers.Length - 1].stateMachine;
            AnimatorState state = stateMachine.AddState("Radial");
            state.motion = clip;
            state.writeDefaultValues = false;
            state.speed = 0f;
            state.timeParameterActive = true;
            state.timeParameter = parameterName;
            stateMachine.defaultState = state;

            EditorUtility.SetDirty(profile.fxController);
        }

        private void GenerateBlendTreeRadialAnimatorLayer(PuddlesAvatarActionControl control, string outputFolder, string parameterName)
        {
            AnimationClip minClip = CreateToggleClip(control, false, outputFolder);
            AnimationClip maxClip = CreateToggleClip(control, true, outputFolder);

            string layerName = BuildLayerName(control);
            RemoveLayersForControl(control);
            profile.fxController.AddLayer(layerName);

            AnimatorControllerLayer[] layers = profile.fxController.layers;
            AnimatorControllerLayer layer = layers[layers.Length - 1];
            layer.defaultWeight = 1f;
            layers[layers.Length - 1] = layer;
            profile.fxController.layers = layers;

            AnimatorStateMachine stateMachine = profile.fxController.layers[profile.fxController.layers.Length - 1].stateMachine;
            AnimatorState state = stateMachine.AddState("Blend");
            state.writeDefaultValues = false;
            stateMachine.defaultState = state;

            BlendTree blendTree = new BlendTree
            {
                name = $"{SanitizeAssetName(control.displayName)} Blend",
                blendType = BlendTreeType.Simple1D,
                blendParameter = parameterName,
                useAutomaticThresholds = false
            };

            AssetDatabase.AddObjectToAsset(blendTree, profile.fxController);
            blendTree.AddChild(minClip, 0f);
            blendTree.AddChild(maxClip, 1f);
            state.motion = blendTree;
            EditorUtility.SetDirty(profile.fxController);
        }

        private void GenerateSelectorAnimatorLayer(PuddlesAvatarActionControl control, string outputFolder)
        {
            EnsureSelectorOptions(control);
            string parameterName = BuildParameterName(control);
            EnsureAnimatorParameter(parameterName, AnimatorControllerParameterType.Int);

            string layerName = BuildLayerName(control);
            RemoveLayersForControl(control);
            profile.fxController.AddLayer(layerName);

            AnimatorControllerLayer[] layers = profile.fxController.layers;
            AnimatorControllerLayer layer = layers[layers.Length - 1];
            layer.defaultWeight = 1f;
            layers[layers.Length - 1] = layer;
            profile.fxController.layers = layers;

            AnimatorStateMachine stateMachine = profile.fxController.layers[profile.fxController.layers.Length - 1].stateMachine;
            for (int i = 0; i < control.selectorOptions.Count; i++)
            {
                PuddlesAvatarSelectorOption option = control.selectorOptions[i];
                AnimationClip clip = CreateSelectorClip(control, option, i, outputFolder);
                AnimatorState state = stateMachine.AddState(TruncateMenuName(option.displayName));
                state.motion = clip;
                state.writeDefaultValues = false;
                if (i == Mathf.Clamp(control.selectorDefaultIndex, 0, control.selectorOptions.Count - 1))
                {
                    stateMachine.defaultState = state;
                }

                AnimatorStateTransition transition = stateMachine.AddAnyStateTransition(state);
                ConfigureInstantTransition(transition);
                transition.canTransitionToSelf = false;
                transition.AddCondition(AnimatorConditionMode.Equals, i, parameterName);
            }

            EditorUtility.SetDirty(profile.fxController);
        }

        private AnimationClip CreateRadialTimeParameterClip(PuddlesAvatarActionControl control, string outputFolder)
        {
            string controlFolder = GetControlFolder(control);
            EnsureFolder(controlFolder);
            string clipPath = Path.Combine(controlFolder, $"{SanitizeAssetName(control.displayName)} Radial.anim").Replace("\\", "/");
            AssetDatabase.DeleteAsset(clipPath);

            AnimationClip clip = new AnimationClip
            {
                name = $"{control.displayName} Radial"
            };

            clip.frameRate = 60f;
            foreach (PuddlesAvatarActionRow action in control.actions)
            {
                WriteRadialTimeParameterActionToClip(clip, action);
            }

            AssetDatabase.CreateAsset(clip, clipPath);
            EditorUtility.SetDirty(clip);
            return clip;
        }

        private AnimationClip CreateToggleClip(PuddlesAvatarActionControl control, bool onState, string outputFolder)
        {
            string controlFolder = GetControlFolder(control);
            EnsureFolder(controlFolder);
            string suffix = control.controlType == PuddlesAvatarControlType.Radial
                ? (onState ? "Radial 1" : "Radial 0")
                : (onState ? "On" : "Off");
            string clipPath = Path.Combine(controlFolder, $"{SanitizeAssetName(control.displayName)} {suffix}.anim").Replace("\\", "/");
            AssetDatabase.DeleteAsset(clipPath);

            AnimationClip clip = new AnimationClip
            {
                name = $"{control.displayName} {suffix}",
                frameRate = 60f
            };

            foreach (PuddlesAvatarActionRow action in control.actions)
            {
                WriteActionToClip(clip, action, onState, control.controlType != PuddlesAvatarControlType.Radial);
            }

            AssetDatabase.CreateAsset(clip, clipPath);
            EditorUtility.SetDirty(clip);
            return clip;
        }

        private AnimationClip CreateSelectorClip(PuddlesAvatarActionControl control, PuddlesAvatarSelectorOption option, int optionIndex, string outputFolder)
        {
            string controlFolder = GetControlFolder(control);
            EnsureFolder(controlFolder);
            string optionLabel = string.IsNullOrWhiteSpace(option.displayName) ? $"Option {optionIndex + 1}" : option.displayName;
            string clipPath = Path.Combine(controlFolder, $"{SanitizeAssetName(control.displayName)} {SanitizeAssetName(optionLabel)}.anim").Replace("\\", "/");
            AssetDatabase.DeleteAsset(clipPath);

            AnimationClip clip = new AnimationClip
            {
                name = $"{control.displayName} {optionLabel}",
                frameRate = 60f
            };

            foreach (PuddlesAvatarActionRow action in control.actions)
            {
                WriteSelectorActionToClip(clip, action, option.id);
            }

            AssetDatabase.CreateAsset(clip, clipPath);
            EditorUtility.SetDirty(clip);
            return clip;
        }

        private AnimationClip CreatePreviewToggleClip(PuddlesAvatarActionControl control, bool onState)
        {
            AnimationClip clip = new AnimationClip
            {
                name = $"{control.displayName} Preview {(onState ? "On" : "Off")}",
                frameRate = 60f
            };

            bool previousSuppressProfileDirty = suppressProfileDirty;
            suppressProfileDirty = true;
            try
            {
                foreach (PuddlesAvatarActionRow action in control.actions)
                {
                    WriteActionToClip(clip, action, onState, true);
                }
            }
            finally
            {
                suppressProfileDirty = previousSuppressProfileDirty;
            }

            return clip;
        }

        private AnimationClip CreatePreviewRadialClip(PuddlesAvatarActionControl control)
        {
            AnimationClip clip = new AnimationClip
            {
                name = $"{control.displayName} Preview Radial",
                frameRate = 60f
            };

            bool previousSuppressProfileDirty = suppressProfileDirty;
            suppressProfileDirty = true;
            try
            {
                foreach (PuddlesAvatarActionRow action in control.actions)
                {
                    WriteRadialTimeParameterActionToClip(clip, action);
                }
            }
            finally
            {
                suppressProfileDirty = previousSuppressProfileDirty;
            }

            return clip;
        }

        private AnimationClip CreatePreviewSelectorClip(PuddlesAvatarActionControl control, string optionId)
        {
            AnimationClip clip = new AnimationClip
            {
                name = $"{control.displayName} Preview Option",
                frameRate = 60f
            };

            bool previousSuppressProfileDirty = suppressProfileDirty;
            suppressProfileDirty = true;
            try
            {
                foreach (PuddlesAvatarActionRow action in control.actions)
                {
                    WriteSelectorActionToClip(clip, action, optionId);
                }
            }
            finally
            {
                suppressProfileDirty = previousSuppressProfileDirty;
            }

            return clip;
        }

        private bool StartActionPreview()
        {
            if (profile == null || profile.avatarRoot == null)
            {
                livePreviewStatus = "Assign an avatar root before previewing.";
                return false;
            }

            if (!isActionPreviewActive && AnimationMode.InAnimationMode())
            {
                livePreviewStatus = "Unity is already in animation preview mode. Stop the other preview first.";
                return false;
            }

            if (!isActionPreviewActive)
            {
                AnimationMode.StartAnimationMode();
                isActionPreviewActive = true;
            }
            else if (!AnimationMode.InAnimationMode())
            {
                AnimationMode.StartAnimationMode();
            }

            return true;
        }

        private void SamplePreviewClip(PuddlesAvatarActionControl control, AnimationClip clip, float time, string status)
        {
            bool wasPreviewActive = isActionPreviewActive;
            if (wasPreviewActive && AnimationMode.InAnimationMode())
            {
                AnimationMode.StopAnimationMode();
                isActionPreviewActive = false;
            }

            if (control == null || clip == null || !StartActionPreview())
            {
                return;
            }

            livePreviewControlId = control.id;
            float sampleTime = Mathf.Clamp(time, 0f, Mathf.Max(clip.length, 0f));
            AnimationMode.SampleAnimationClip(profile.avatarRoot, clip, sampleTime);
            livePreviewStatus = status;
            SceneView.RepaintAll();
            if (!wasPreviewActive)
            {
                FocusAvatarInSceneViewSoon();
            }
            Repaint();
        }

        private void StopActionPreview()
        {
            if (isActionPreviewActive && AnimationMode.InAnimationMode())
            {
                AnimationMode.StopAnimationMode();
            }

            isActionPreviewActive = false;
            livePreviewControlId = null;
            livePreviewStatus = string.Empty;
            SceneView.RepaintAll();
            FocusAvatarInSceneViewSoon();
        }

        private void FocusAvatarInSceneViewSoon()
        {
            if (!livePreviewAutoFocus)
            {
                return;
            }

            EditorApplication.delayCall += FocusAvatarInSceneView;
        }

        private void FocusAvatarInSceneView()
        {
            if (!livePreviewAutoFocus)
            {
                return;
            }

            if (profile == null || profile.avatarRoot == null)
            {
                return;
            }

            SceneView sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null)
            {
                return;
            }

            Bounds bounds = CalculateAvatarBounds(profile.avatarRoot);
            float size = Mathf.Clamp(bounds.extents.magnitude * livePreviewFocusDistance, 1.5f, 8f);
            sceneView.LookAt(bounds.center, sceneView.rotation, size, false);
            sceneView.Repaint();
        }

        private static Bounds CalculateAvatarBounds(GameObject root)
        {
            if (root == null)
            {
                return new Bounds(Vector3.zero, Vector3.one);
            }

            Renderer[] renderers = root.GetComponentsInChildren<Renderer>(true);
            bool hasBounds = false;
            Bounds bounds = new Bounds(GetDefaultAvatarFocusPoint(root), Vector3.one * 1.8f);
            foreach (Renderer renderer in renderers)
            {
                if (!ShouldUseRendererForAvatarFocus(renderer))
                {
                    continue;
                }

                Bounds rendererBounds = renderer.bounds;
                if (!IsUsableFocusBounds(root, rendererBounds))
                {
                    continue;
                }

                if (!hasBounds)
                {
                    bounds = rendererBounds;
                    hasBounds = true;
                }
                else
                {
                    bounds.Encapsulate(rendererBounds);
                }
            }

            if (!hasBounds || !IsUsableFocusBounds(root, bounds))
            {
                bounds = new Bounds(GetDefaultAvatarFocusPoint(root), Vector3.one * 1.8f);
            }

            return bounds;
        }

        private static bool ShouldUseRendererForAvatarFocus(Renderer renderer)
        {
            if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy)
            {
                return false;
            }

            return renderer is SkinnedMeshRenderer || renderer is MeshRenderer;
        }

        private static bool IsUsableFocusBounds(GameObject root, Bounds bounds)
        {
            if (root == null)
            {
                return false;
            }

            Vector3 size = bounds.size;
            if (!IsFinite(bounds.center) || !IsFinite(size) || size == Vector3.zero)
            {
                return false;
            }

            if (size.x > 20f || size.y > 20f || size.z > 20f)
            {
                return false;
            }

            return Vector3.Distance(bounds.center, root.transform.position) < 15f;
        }

        private static Vector3 GetDefaultAvatarFocusPoint(GameObject root)
        {
            return root != null ? root.transform.position + Vector3.up : Vector3.up;
        }

        private static bool IsFinite(Vector3 value)
        {
            return IsFinite(value.x)
                && IsFinite(value.y)
                && IsFinite(value.z);
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private void WriteRadialTimeParameterActionToClip(AnimationClip clip, PuddlesAvatarActionRow action)
        {
            ResolveActionReferences(action);
            switch (action.kind)
            {
                case PuddlesAvatarActionKind.Blendshape:
                    if (action.skinnedRenderer == null || string.IsNullOrWhiteSpace(action.blendshapeName) || !IsUnderAvatar(action.skinnedRenderer.transform))
                    {
                        return;
                    }

                    WriteRadialFloatCurve(clip, action.skinnedRenderer.transform, typeof(SkinnedMeshRenderer), $"blendShape.{action.blendshapeName}", action.offFloat, action.onFloat);
                    break;

                case PuddlesAvatarActionKind.ShaderFloat:
                    if (action.renderer == null || string.IsNullOrWhiteSpace(action.shaderPropertyName) || !IsUnderAvatar(action.renderer.transform))
                    {
                        return;
                    }

                    WriteRadialShaderFloatCurve(clip, action.renderer, action.materialSlot, action.shaderPropertyName, action.offFloat, action.onFloat);
                    break;
            }
        }

        private void WriteActionToClip(AnimationClip clip, PuddlesAvatarActionRow action, bool onState, bool allowNoChange)
        {
            ResolveActionReferences(action);
            if (allowNoChange && (onState ? action.onWriteMode : action.offWriteMode) == PuddlesAvatarWriteMode.NoChange)
            {
                return;
            }

            switch (action.kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    if (action.targetObject == null || !IsUnderAvatar(action.targetObject.transform))
                    {
                        return;
                    }

                    WriteFloatCurve(clip, action.targetObject.transform, typeof(GameObject), "m_IsActive", onState ? BoolToFloat(action.onBool) : BoolToFloat(action.offBool));
                    break;

                case PuddlesAvatarActionKind.Blendshape:
                    if (action.skinnedRenderer == null || string.IsNullOrWhiteSpace(action.blendshapeName) || !IsUnderAvatar(action.skinnedRenderer.transform))
                    {
                        return;
                    }

                    WriteFloatCurve(clip, action.skinnedRenderer.transform, typeof(SkinnedMeshRenderer), $"blendShape.{action.blendshapeName}", onState ? action.onFloat : action.offFloat);
                    break;

                case PuddlesAvatarActionKind.MaterialSwap:
                    if (action.renderer == null || !IsUnderAvatar(action.renderer.transform))
                    {
                        return;
                    }

                    WriteMaterialCurve(clip, action.renderer, action.materialSlot, onState ? action.onMaterial : action.offMaterial);
                    break;

                case PuddlesAvatarActionKind.ComponentEnabled:
                    if (!TryWriteComponentEnabledCurve(clip, action, onState ? action.onBool : action.offBool))
                    {
                        return;
                    }
                    break;

                case PuddlesAvatarActionKind.RawBinding:
                    if (!allowNoChange)
                    {
                        return;
                    }

                    WriteRawBindingToClip(clip, action, onState);
                    break;

                case PuddlesAvatarActionKind.SetAnotherToggle:
                    return;

                case PuddlesAvatarActionKind.ShaderFloat:
                    if (action.renderer == null || string.IsNullOrWhiteSpace(action.shaderPropertyName) || !IsUnderAvatar(action.renderer.transform))
                    {
                        return;
                    }

                    WriteShaderFloatCurve(clip, action.renderer, action.materialSlot, action.shaderPropertyName, onState ? action.onFloat : action.offFloat);
                    break;
            }
        }

        private void WriteSelectorActionToClip(AnimationClip clip, PuddlesAvatarActionRow action, string optionId)
        {
            ResolveActionReferences(action);
            PuddlesAvatarActionOptionValue value = GetOptionValue(action, optionId);
            if (value.writeMode == PuddlesAvatarWriteMode.NoChange)
            {
                return;
            }

            switch (action.kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    if (action.targetObject == null || !IsUnderAvatar(action.targetObject.transform))
                    {
                        return;
                    }

                    WriteFloatCurve(clip, action.targetObject.transform, typeof(GameObject), "m_IsActive", BoolToFloat(value.boolValue));
                    break;

                case PuddlesAvatarActionKind.Blendshape:
                    if (action.skinnedRenderer == null || string.IsNullOrWhiteSpace(action.blendshapeName) || !IsUnderAvatar(action.skinnedRenderer.transform))
                    {
                        return;
                    }

                    WriteFloatCurve(clip, action.skinnedRenderer.transform, typeof(SkinnedMeshRenderer), $"blendShape.{action.blendshapeName}", value.floatValue);
                    break;

                case PuddlesAvatarActionKind.MaterialSwap:
                    if (action.renderer == null || !IsUnderAvatar(action.renderer.transform))
                    {
                        return;
                    }

                    WriteMaterialCurve(clip, action.renderer, action.materialSlot, value.materialValue);
                    break;

                case PuddlesAvatarActionKind.ComponentEnabled:
                    if (!TryWriteComponentEnabledCurve(clip, action, value.boolValue))
                    {
                        return;
                    }
                    break;

                case PuddlesAvatarActionKind.RawBinding:
                    return;

                case PuddlesAvatarActionKind.SetAnotherToggle:
                    return;

                case PuddlesAvatarActionKind.ShaderFloat:
                    if (action.renderer == null || string.IsNullOrWhiteSpace(action.shaderPropertyName) || !IsUnderAvatar(action.renderer.transform))
                    {
                        return;
                    }

                    WriteShaderFloatCurve(clip, action.renderer, action.materialSlot, action.shaderPropertyName, value.floatValue);
                    break;
            }
        }

        private void WriteFloatCurve(AnimationClip clip, Transform target, Type bindingType, string propertyName, float value)
        {
            string path = AnimationUtility.CalculateTransformPath(target, profile.avatarRoot.transform);
            EditorCurveBinding binding = EditorCurveBinding.FloatCurve(path, bindingType, propertyName);
            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0f, 1f / 60f, value));
        }

        private void WriteRadialFloatCurve(AnimationClip clip, Transform target, Type bindingType, string propertyName, float minValue, float maxValue)
        {
            string path = AnimationUtility.CalculateTransformPath(target, profile.avatarRoot.transform);
            EditorCurveBinding binding = EditorCurveBinding.FloatCurve(path, bindingType, propertyName);
            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Linear(0f, minValue, 1f, maxValue));
        }

        private bool TryWriteComponentEnabledCurve(AnimationClip clip, PuddlesAvatarActionRow action, bool value)
        {
            if (action.component != null && IsUnderAvatar(action.component.transform))
            {
                WriteFloatCurve(clip, action.component.transform, action.component.GetType(), "m_Enabled", BoolToFloat(value));
                return true;
            }

            Transform target = FindAvatarTransform(action.componentPath);
            Component resolvedComponent = FindComponentOnTransform(target, action.componentTypeName);
            if (resolvedComponent != null && IsUnderAvatar(resolvedComponent.transform))
            {
                action.component = resolvedComponent;
                WriteFloatCurve(clip, resolvedComponent.transform, resolvedComponent.GetType(), "m_Enabled", BoolToFloat(value));
                MarkProfileDirty();
                return true;
            }

            Type bindingType = GetComponentType(action.componentTypeName);
            if (target == null || bindingType == null)
            {
                Debug.LogWarning($"Puddles Action Builder skipped component enabled binding at '{action.componentPath}' because its target path or type could not be resolved.");
                return false;
            }

            string path = AnimationUtility.CalculateTransformPath(target, profile.avatarRoot.transform);
            EditorCurveBinding binding = EditorCurveBinding.FloatCurve(path, bindingType, "m_Enabled");
            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0f, 1f / 60f, BoolToFloat(value)));
            return true;
        }

        private void WriteRawBindingToClip(AnimationClip clip, PuddlesAvatarActionRow action, bool onState)
        {
            Type bindingType = GetComponentType(action.rawBindingTypeName);
            Transform target = FindAvatarTransform(action.rawBindingPath);
            if (bindingType == null || target == null || string.IsNullOrWhiteSpace(action.rawBindingPropertyName))
            {
                Debug.LogWarning($"Puddles Action Builder skipped raw binding '{action.rawBindingPropertyName}' because its target path or type could not be resolved.");
                return;
            }

            string path = AnimationUtility.CalculateTransformPath(target, profile.avatarRoot.transform);
            if (action.rawBindingValueKind == PuddlesAvatarRawBindingValueKind.ObjectReference)
            {
                EditorCurveBinding binding = EditorCurveBinding.PPtrCurve(path, bindingType, action.rawBindingPropertyName);
                UnityEngine.Object objectValue = onState ? action.onObjectReference : action.offObjectReference;
                ObjectReferenceKeyframe[] keyframes =
                {
                    new ObjectReferenceKeyframe { time = 0f, value = objectValue },
                    new ObjectReferenceKeyframe { time = 1f / 60f, value = objectValue }
                };
                AnimationUtility.SetObjectReferenceCurve(clip, binding, keyframes);
                return;
            }

            float floatValue = onState ? action.onFloat : action.offFloat;
            EditorCurveBinding floatBinding = EditorCurveBinding.FloatCurve(path, bindingType, action.rawBindingPropertyName);
            AnimationUtility.SetEditorCurve(clip, floatBinding, AnimationCurve.Constant(0f, 1f / 60f, floatValue));
        }

        private void WriteMaterialCurve(AnimationClip clip, Renderer renderer, int materialSlot, Material material)
        {
            string path = AnimationUtility.CalculateTransformPath(renderer.transform, profile.avatarRoot.transform);
            EditorCurveBinding binding = EditorCurveBinding.PPtrCurve(path, renderer.GetType(), $"m_Materials.Array.data[{materialSlot}]");
            ObjectReferenceKeyframe[] keyframes =
            {
                new ObjectReferenceKeyframe { time = 0f, value = material },
                new ObjectReferenceKeyframe { time = 1f / 60f, value = material }
            };
            AnimationUtility.SetObjectReferenceCurve(clip, binding, keyframes);
        }

        private void WriteShaderFloatCurve(AnimationClip clip, Renderer renderer, int materialSlot, string propertyName, float value)
        {
            string path = AnimationUtility.CalculateTransformPath(renderer.transform, profile.avatarRoot.transform);
            string animatedProperty = materialSlot == 0 ? $"material.{propertyName}" : $"material.[{materialSlot}].{propertyName}";
            EditorCurveBinding binding = EditorCurveBinding.FloatCurve(path, renderer.GetType(), animatedProperty);
            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0f, 1f / 60f, value));
        }

        private void WriteRadialShaderFloatCurve(AnimationClip clip, Renderer renderer, int materialSlot, string propertyName, float minValue, float maxValue)
        {
            string path = AnimationUtility.CalculateTransformPath(renderer.transform, profile.avatarRoot.transform);
            string animatedProperty = materialSlot == 0 ? $"material.{propertyName}" : $"material.[{materialSlot}].{propertyName}";
            EditorCurveBinding binding = EditorCurveBinding.FloatCurve(path, renderer.GetType(), animatedProperty);
            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Linear(0f, minValue, 1f, maxValue));
        }

        private bool AddMenuControl(PuddlesAvatarActionControl control, string outputFolder)
        {
            switch (control.controlType)
            {
                case PuddlesAvatarControlType.Radial:
                    return AddRadialMenuControl(control, outputFolder);
                case PuddlesAvatarControlType.Selector:
                    return AddSelectorMenuControl(control, outputFolder);
                default:
                    return AddToggleMenuControl(control, outputFolder);
            }
        }

        private bool AddToggleMenuControl(PuddlesAvatarActionControl control, string outputFolder)
        {
            string parameterName = BuildParameterName(control);
            RemoveMenuControlByParameter(profile.rootMenu, parameterName);

            VRCExpressionsMenu targetMenu = ResolveControlDestinationMenu(control);
            if (targetMenu == null)
            {
                Debug.LogWarning($"Avatar Action Builder: Destination menu for {control.displayName} is missing. Falling back to the avatar root menu.");
                targetMenu = profile.rootMenu;
            }

            VRCExpressionsMenu.Control menuControl = new VRCExpressionsMenu.Control
            {
                name = TruncateMenuName(string.IsNullOrWhiteSpace(control.displayName) ? "Toggle" : control.displayName),
                type = VRCExpressionsMenu.Control.ControlType.Toggle,
                parameter = new VRCExpressionsMenu.Control.Parameter { name = parameterName },
                value = 1f
            };

            if (!TryAddControlToMenu(targetMenu, menuControl, outputFolder, SanitizeAssetName(GetControlDestinationPath(control))))
            {
                Debug.LogWarning($"Avatar Action Builder: Could not add menu control for {control.displayName}; target menu is full.");
                return false;
            }

            return true;
        }

        private bool AddRadialMenuControl(PuddlesAvatarActionControl control, string outputFolder)
        {
            string parameterName = BuildParameterName(control);
            RemoveMenuControlByParameter(profile.rootMenu, parameterName);

            VRCExpressionsMenu targetMenu = ResolveControlDestinationMenu(control);
            if (targetMenu == null)
            {
                Debug.LogWarning($"Avatar Action Builder: Destination menu for {control.displayName} is missing. Falling back to the avatar root menu.");
                targetMenu = profile.rootMenu;
            }

            VRCExpressionsMenu.Control menuControl = new VRCExpressionsMenu.Control
            {
                name = TruncateMenuName(string.IsNullOrWhiteSpace(control.displayName) ? "Radial" : control.displayName),
                type = VRCExpressionsMenu.Control.ControlType.RadialPuppet,
                subParameters = new[]
                {
                    new VRCExpressionsMenu.Control.Parameter { name = parameterName }
                }
            };

            if (!TryAddControlToMenu(targetMenu, menuControl, outputFolder, SanitizeAssetName(GetControlDestinationPath(control))))
            {
                Debug.LogWarning($"Avatar Action Builder: Could not add radial menu control for {control.displayName}; target menu is full.");
                return false;
            }

            return true;
        }

        private bool AddSelectorMenuControl(PuddlesAvatarActionControl control, string outputFolder)
        {
            EnsureSelectorOptions(control);
            string parameterName = BuildParameterName(control);
            RemoveMenuControlByParameter(profile.rootMenu, parameterName);

            VRCExpressionsMenu targetMenu = ResolveControlDestinationMenu(control);
            if (targetMenu == null)
            {
                Debug.LogWarning($"Avatar Action Builder: Destination menu for {control.displayName} is missing. Falling back to the avatar root menu.");
                targetMenu = profile.rootMenu;
            }

            string controlFolder = GetControlFolder(control);
            EnsureFolder(controlFolder);
            string selectorPath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(controlFolder, $"{SanitizeAssetName(control.displayName)} Selector Menu.asset").Replace("\\", "/"));
            VRCExpressionsMenu selectorMenu = CreateInstance<VRCExpressionsMenu>();
            EnsureMenuControlList(selectorMenu);
            AssetDatabase.CreateAsset(selectorMenu, selectorPath);

            for (int i = 0; i < control.selectorOptions.Count; i++)
            {
                PuddlesAvatarSelectorOption option = control.selectorOptions[i];
                VRCExpressionsMenu.Control optionControl = new VRCExpressionsMenu.Control
                {
                    name = TruncateMenuName(string.IsNullOrWhiteSpace(option.displayName) ? $"Option {i + 1}" : option.displayName),
                    type = VRCExpressionsMenu.Control.ControlType.Toggle,
                    parameter = new VRCExpressionsMenu.Control.Parameter { name = parameterName },
                    value = i
                };

                if (!TryAddControlToMenu(selectorMenu, optionControl, controlFolder, SanitizeAssetName(control.displayName)))
                {
                    Debug.LogWarning($"Avatar Action Builder: Could not add selector option '{option.displayName}' for {control.displayName}; selector menu is full.");
                    return false;
                }
            }

            VRCExpressionsMenu.Control submenuControl = new VRCExpressionsMenu.Control
            {
                name = TruncateMenuName(string.IsNullOrWhiteSpace(control.displayName) ? "Selector" : control.displayName),
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = selectorMenu
            };

            if (!TryAddControlToMenu(targetMenu, submenuControl, outputFolder, SanitizeAssetName(GetControlDestinationPath(control))))
            {
                Debug.LogWarning($"Avatar Action Builder: Could not add selector submenu for {control.displayName}; target menu is full.");
                return false;
            }

            AddManagedSubmenuRecord(TruncateMenuName(control.displayName), targetMenu, selectorMenu);
            EditorUtility.SetDirty(selectorMenu);
            return true;
        }

        private VRCExpressionsMenu FindOrCreateSubMenu(VRCExpressionsMenu parent, string name, string outputFolder)
        {
            EnsureMenuControlList(parent);
            foreach (VRCExpressionsMenu.Control control in parent.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                    && control.subMenu != null
                    && string.Equals(control.name, name, StringComparison.OrdinalIgnoreCase))
                {
                    EnsureMenuControlList(control.subMenu);
                    return control.subMenu;
                }
            }

            if (parent.controls.Count >= MaxControlsPerMenu)
            {
                return null;
            }

            string path = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(outputFolder, $"{SanitizeAssetName(name)} Menu.asset").Replace("\\", "/"));
            VRCExpressionsMenu menu = CreateInstance<VRCExpressionsMenu>();
            EnsureMenuControlList(menu);
            AssetDatabase.CreateAsset(menu, path);
            parent.controls.Add(new VRCExpressionsMenu.Control
            {
                name = name,
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = menu
            });
            EditorUtility.SetDirty(parent);
            return menu;
        }

        private bool TryAddControlToMenu(VRCExpressionsMenu menu, VRCExpressionsMenu.Control control, string outputFolder, string pagePrefix)
        {
            EnsureMenuControlList(menu);
            if (menu.controls.Count < MaxControlsPerMenu)
            {
                menu.controls.Add(control);
                EditorUtility.SetDirty(menu);
                return true;
            }

            if (!EnsurePagedMenu(menu, outputFolder, pagePrefix))
            {
                return false;
            }

            VRCExpressionsMenu page = FindPageWithRoom(menu);
            if (page == null)
            {
                if (menu.controls.Count >= MaxControlsPerMenu)
                {
                    return false;
                }

                page = CreatePageMenu(menu, outputFolder, pagePrefix);
            }

            page.controls.Add(control);
            EditorUtility.SetDirty(page);
            EditorUtility.SetDirty(menu);
            return true;
        }

        private bool EnsurePagedMenu(VRCExpressionsMenu menu, string outputFolder, string pagePrefix)
        {
            List<VRCExpressionsMenu.Control> directControls = menu.controls
                .Where(control => control.type != VRCExpressionsMenu.Control.ControlType.SubMenu)
                .ToList();

            if (directControls.Count == 0)
            {
                return true;
            }

            if (menu.controls.Count - directControls.Count >= MaxControlsPerMenu)
            {
                return false;
            }

            menu.controls.RemoveAll(control => control.type != VRCExpressionsMenu.Control.ControlType.SubMenu);
            foreach (List<VRCExpressionsMenu.Control> chunk in Chunk(directControls, ControlsPerPagedMenu))
            {
                VRCExpressionsMenu page = CreatePageMenu(menu, outputFolder, pagePrefix);
                page.controls.AddRange(chunk);
                EditorUtility.SetDirty(page);
            }

            EditorUtility.SetDirty(menu);
            return true;
        }

        private VRCExpressionsMenu CreatePageMenu(VRCExpressionsMenu menu, string outputFolder, string pagePrefix)
        {
            int pageIndex = menu.controls.Count(control => control.type == VRCExpressionsMenu.Control.ControlType.SubMenu) + 1;
            string pageName = $"Page {pageIndex}";
            string filePrefix = string.IsNullOrWhiteSpace(pagePrefix) ? "Actions" : pagePrefix;
            string path = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(outputFolder, $"{SanitizeAssetName(filePrefix)} {pageName}.asset").Replace("\\", "/"));
            VRCExpressionsMenu page = CreateInstance<VRCExpressionsMenu>();
            EnsureMenuControlList(page);
            AssetDatabase.CreateAsset(page, path);
            menu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = TruncateMenuName(pageName),
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = page
            });
            AddManagedSubmenuRecord(pageName, menu, page);
            EditorUtility.SetDirty(menu);
            return page;
        }

        private static bool HasSubMenuControls(VRCExpressionsMenu menu)
        {
            return menu.controls.Any(control => control.type == VRCExpressionsMenu.Control.ControlType.SubMenu);
        }

        private static VRCExpressionsMenu FindPageWithRoom(VRCExpressionsMenu menu)
        {
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                {
                    EnsureMenuControlList(control.subMenu);
                    if (control.subMenu.controls.Count < MaxControlsPerMenu)
                    {
                        return control.subMenu;
                    }
                }
            }

            return null;
        }

        private void AppendGeneratedMenuToRoot(VRCExpressionsMenu generatedMenu)
        {
            EnsureMenuControlList(profile.rootMenu);
            string menuName = TruncateMenuName(GetGeneratedMenuName());
            profile.rootMenu.controls.RemoveAll(control => control.name == menuName);
            if (profile.rootMenu.controls.Count >= MaxControlsPerMenu)
            {
                Debug.LogWarning("Avatar Action Builder: Root expression menu is full, so the generated menu was not appended.");
                EditorUtility.SetDirty(profile.rootMenu);
                return;
            }

            profile.rootMenu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = menuName,
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = generatedMenu
            });
            EditorUtility.SetDirty(profile.rootMenu);
        }

        private void DeleteGeneratedArtifacts(PuddlesAvatarActionControl control, bool saveAssets)
        {
            if (profile == null || control == null)
            {
                return;
            }

            List<string> parameterNames = GetParameterNamesForControl(control).ToList();
            if (profile.fxController != null)
            {
                RemoveLayersForControl(control);
                foreach (string parameterName in parameterNames)
                {
                    RemoveAnimatorParameter(parameterName);
                }

                EditorUtility.SetDirty(profile.fxController);
            }

            if (profile.expressionParameters != null && profile.expressionParameters.parameters != null)
            {
                int beforeCount = profile.expressionParameters.parameters.Length;
                profile.expressionParameters.parameters = profile.expressionParameters.parameters
                    .Where(parameter => parameter == null || !parameterNames.Contains(parameter.name, StringComparer.OrdinalIgnoreCase))
                    .ToArray();
                if (profile.expressionParameters.parameters.Length != beforeCount)
                {
                    EditorUtility.SetDirty(profile.expressionParameters);
                }
            }

            if (profile.rootMenu != null)
            {
                foreach (string parameterName in parameterNames)
                {
                    RemoveMenuControlByParameter(profile.rootMenu, parameterName);
                }

                RemoveMenuControlsReferencingAssetsInFolder(profile.rootMenu, GetControlFolder(control));
            }

            string controlFolder = GetControlFolder(control);
            if (AssetDatabase.IsValidFolder(controlFolder))
            {
                AssetDatabase.DeleteAsset(controlFolder);
            }

            if (saveAssets)
            {
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
        }

        private void RemoveLayersForControl(PuddlesAvatarActionControl control)
        {
            if (profile == null || profile.fxController == null)
            {
                return;
            }

            AnimatorControllerLayer[] layers = profile.fxController.layers;
            for (int i = layers.Length - 1; i >= 0; i--)
            {
                if (IsGeneratedLayerForControl(layers[i].name, control))
                {
                    profile.fxController.RemoveLayer(i);
                }
            }
        }

        private void RemoveLayer(string layerName)
        {
            if (profile == null || profile.fxController == null)
            {
                return;
            }

            AnimatorControllerLayer[] layers = profile.fxController.layers;
            for (int i = layers.Length - 1; i >= 0; i--)
            {
                if (layers[i].name == layerName)
                {
                    profile.fxController.RemoveLayer(i);
                }
            }
        }

        private void EnsureAnimatorParameter(string parameterName, AnimatorControllerParameterType parameterType)
        {
            AnimatorControllerParameter existing = profile.fxController.parameters.FirstOrDefault(parameter => parameter.name == parameterName);
            if (existing != null && existing.type != parameterType)
            {
                profile.fxController.RemoveParameter(existing);
                existing = null;
            }

            if (existing == null)
            {
                profile.fxController.AddParameter(parameterName, parameterType);
            }
        }

        private void RemoveAnimatorParameter(string parameterName)
        {
            AnimatorControllerParameter parameter = profile.fxController.parameters.FirstOrDefault(existing => existing.name == parameterName);
            if (parameter != null)
            {
                profile.fxController.RemoveParameter(parameter);
            }
        }

        private void ConfigureInstantTransition(AnimatorStateTransition transition)
        {
            transition.hasExitTime = false;
            transition.exitTime = 0f;
            transition.duration = 0f;
            transition.offset = 0f;
            transition.hasFixedDuration = true;
        }

        private void ScanExistingControls()
        {
            existingControlLines.Clear();
            if (profile == null)
            {
                return;
            }

            HashSet<string> ownedParameters = new HashSet<string>(
                profile.controls.SelectMany(GetParameterNamesForControl),
                StringComparer.OrdinalIgnoreCase);
            if (profile.rootMenu != null)
            {
                existingControlLines.Add("Menus:");
                CollectMenuLines(profile.rootMenu, string.Empty, ownedParameters, new HashSet<VRCExpressionsMenu>());
            }

            if (profile.expressionParameters != null && profile.expressionParameters.parameters != null)
            {
                existingControlLines.Add("Parameters:");
                foreach (VRCExpressionParameters.Parameter parameter in profile.expressionParameters.parameters)
                {
                    if (parameter == null)
                    {
                        continue;
                    }

                    string owner = ownedParameters.Contains(parameter.name) ? " [Action Builder]" : string.Empty;
                    existingControlLines.Add($"- {parameter.name} ({parameter.valueType}){owner}");
                }
            }

            if (profile.fxController != null)
            {
                existingControlLines.Add("FX Layers:");
                foreach (AnimatorControllerLayer layer in profile.fxController.layers)
                {
                    string owner = layer.name.StartsWith("Puddles Action ", StringComparison.OrdinalIgnoreCase) ? " [Action Builder]" : string.Empty;
                    existingControlLines.Add($"- {layer.name}{owner}");
                    foreach (string animatedProperty in CollectLayerAnimatedProperties(layer).Take(8))
                    {
                        existingControlLines.Add($"  - {animatedProperty}");
                    }
                }
            }
        }

        private static IEnumerable<string> CollectLayerAnimatedProperties(AnimatorControllerLayer layer)
        {
            HashSet<string> properties = new HashSet<string>(StringComparer.Ordinal);
            if (layer == null || layer.stateMachine == null)
            {
                yield break;
            }

            foreach (ChildAnimatorState childState in layer.stateMachine.states)
            {
                if (childState.state == null || childState.state.motion == null)
                {
                    continue;
                }

                foreach (AnimationClip clip in CollectMotionClips(childState.state.motion))
                {
                    foreach (EditorCurveBinding binding in AnimationUtility.GetCurveBindings(clip))
                    {
                        string label = $"{binding.path} :: {binding.propertyName}";
                        if (properties.Add(label))
                        {
                            yield return label;
                        }
                    }

                    foreach (EditorCurveBinding binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                    {
                        string label = $"{binding.path} :: {binding.propertyName}";
                        if (properties.Add(label))
                        {
                            yield return label;
                        }
                    }
                }
            }
        }

        private static IEnumerable<AnimationClip> CollectMotionClips(Motion motion)
        {
            if (motion is AnimationClip clip)
            {
                yield return clip;
                yield break;
            }

            if (motion is BlendTree blendTree)
            {
                foreach (ChildMotion child in blendTree.children)
                {
                    foreach (AnimationClip childClip in CollectMotionClips(child.motion))
                    {
                        yield return childClip;
                    }
                }
            }
        }

        private void CollectMenuLines(VRCExpressionsMenu menu, string path, HashSet<string> ownedParameters, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                string controlPath = string.IsNullOrWhiteSpace(path) ? control.name : $"{path}/{control.name}";
                string parameterName = GetMenuControlParameterName(control);
                string owner = ownedParameters.Contains(parameterName) ? " [Action Builder]" : string.Empty;
                existingControlLines.Add($"- {controlPath} ({control.type}) {parameterName}{owner}");
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    CollectMenuLines(control.subMenu, controlPath, ownedParameters, visited);
                }
            }
        }

        private PuddlesAvatarActionControl GetSelectedControl()
        {
            if (profile == null)
            {
                return null;
            }

            PuddlesAvatarActionControl selected = profile.controls.FirstOrDefault(control => control.id == selectedControlId);
            if (selected == null && profile.controls.Count > 0)
            {
                selected = profile.controls[0];
                selectedControlId = selected.id;
            }

            return selected;
        }

        private string BuildParameterName(PuddlesAvatarActionControl control)
        {
            string prefix = GetParameterPrefix().Trim().Trim('/');
            return BuildReadableParameterName(prefix, control);
        }

        private string BuildLegacyParameterName(PuddlesAvatarActionControl control)
        {
            string prefix = GetParameterPrefix().Trim().Trim('/');
            return $"{prefix}/{control.id}";
        }

        private IEnumerable<string> GetParameterNamesForControl(PuddlesAvatarActionControl control)
        {
            if (control == null)
            {
                yield break;
            }

            yield return BuildParameterName(control);
            yield return BuildLegacyParameterName(control);

            string suffix = $"_{control.id}";
            foreach (string parameterName in GetExistingAvatarParameterNames())
            {
                if (parameterName.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
                {
                    yield return parameterName;
                }
            }
        }

        private string BuildLayerName(PuddlesAvatarActionControl control)
        {
            string label = SanitizeLayerLabel(control.displayName);
            return $"Puddles Action {label} [{control.id}]";
        }

        private string BuildLegacyLayerName(PuddlesAvatarActionControl control)
        {
            return $"Puddles Action {control.id}";
        }

        private bool IsGeneratedLayerForControl(string layerName, PuddlesAvatarActionControl control)
        {
            if (string.IsNullOrWhiteSpace(layerName) || control == null)
            {
                return false;
            }

            return layerName == BuildLayerName(control)
                || layerName == BuildLegacyLayerName(control)
                || (layerName.StartsWith("Puddles Action ", StringComparison.OrdinalIgnoreCase)
                    && layerName.EndsWith($"[{control.id}]", StringComparison.OrdinalIgnoreCase));
        }

        private VRCExpressionsMenu ResolveControlDestinationMenu(PuddlesAvatarActionControl control)
        {
            if (control == null || control.destinationMenu == null)
            {
                return profile.rootMenu;
            }

            return MenuExistsInTree(profile.rootMenu, control.destinationMenu, new HashSet<VRCExpressionsMenu>())
                ? control.destinationMenu
                : null;
        }

        private string GetControlDestinationPath(PuddlesAvatarActionControl control)
        {
            if (control == null || control.destinationMenu == null)
            {
                return "Root";
            }

            if (!string.IsNullOrWhiteSpace(control.destinationPath))
            {
                return control.destinationPath;
            }

            string path = FindMenuPath(profile.rootMenu, control.destinationMenu, "Root", new HashSet<VRCExpressionsMenu>());
            return string.IsNullOrWhiteSpace(path) ? "Root" : path;
        }

        private void AddManagedSubmenuRecord(string displayName, VRCExpressionsMenu parentMenu, VRCExpressionsMenu submenu)
        {
            if (profile == null || submenu == null)
            {
                return;
            }

            EnsureManagedMenuList();
            PuddlesAvatarManagedSubmenu existing = profile.managedSubmenus.FirstOrDefault(record => record.menu == submenu);
            if (existing == null)
            {
                existing = new PuddlesAvatarManagedSubmenu { id = CreateStableId() };
                profile.managedSubmenus.Add(existing);
            }

            existing.displayName = displayName;
            existing.parentMenu = parentMenu;
            existing.menu = submenu;
            existing.path = FindMenuPath(profile.rootMenu, submenu, "Root", new HashSet<VRCExpressionsMenu>());
            MarkProfileDirty();
        }

        private void EnsureManagedMenuList()
        {
            if (profile != null && profile.managedSubmenus == null)
            {
                profile.managedSubmenus = new List<PuddlesAvatarManagedSubmenu>();
            }
        }

        private string GetOutputFolder()
        {
            return string.IsNullOrWhiteSpace(profile.outputFolder) ? DefaultOutputFolder : profile.outputFolder.Trim();
        }

        private string GetParameterPrefix()
        {
            return string.IsNullOrWhiteSpace(profile.parameterPrefix) ? DefaultParameterPrefix : profile.parameterPrefix.Trim();
        }

        private string GetGeneratedMenuName()
        {
            return string.IsNullOrWhiteSpace(profile.generatedMenuName) ? "Avatar Actions" : profile.generatedMenuName.Trim();
        }

        private string GetProfileGenerationFolder()
        {
            string profileName = profile == null ? "Profile" : SanitizeAssetName(profile.name);
            return Path.Combine(GetOutputFolder(), profileName).Replace("\\", "/");
        }

        private string GetGeneratedMenuPath(string outputFolder)
        {
            return Path.Combine(outputFolder, $"{SanitizeAssetName(GetGeneratedMenuName())} Menu.asset").Replace("\\", "/");
        }

        private string GetControlFolder(PuddlesAvatarActionControl control)
        {
            return Path.Combine(GetProfileGenerationFolder(), control.id).Replace("\\", "/");
        }

        private bool IsUnderAvatar(Transform target)
        {
            return profile.avatarRoot != null && target != null && (target == profile.avatarRoot.transform || target.IsChildOf(profile.avatarRoot.transform));
        }

        private void StoreActionReferencePaths(PuddlesAvatarActionRow action)
        {
            if (profile == null || profile.avatarRoot == null || action == null)
            {
                return;
            }

            if (action.targetObject != null && IsUnderAvatar(action.targetObject.transform))
            {
                action.targetObjectPath = AnimationUtility.CalculateTransformPath(action.targetObject.transform, profile.avatarRoot.transform);
            }

            if (action.skinnedRenderer != null && IsUnderAvatar(action.skinnedRenderer.transform))
            {
                action.skinnedRendererPath = AnimationUtility.CalculateTransformPath(action.skinnedRenderer.transform, profile.avatarRoot.transform);
            }

            if (action.renderer != null && IsUnderAvatar(action.renderer.transform))
            {
                action.rendererPath = AnimationUtility.CalculateTransformPath(action.renderer.transform, profile.avatarRoot.transform);
            }

            if (action.component != null && IsUnderAvatar(action.component.transform))
            {
                action.componentPath = AnimationUtility.CalculateTransformPath(action.component.transform, profile.avatarRoot.transform);
                action.componentTypeName = action.component.GetType().AssemblyQualifiedName;
            }

            MarkProfileDirty();
        }

        private void ResolveActionReferences(PuddlesAvatarActionRow action)
        {
            if (profile == null || profile.avatarRoot == null || action == null)
            {
                return;
            }

            if (action.targetObject == null && !string.IsNullOrWhiteSpace(action.targetObjectPath))
            {
                Transform target = FindAvatarTransform(action.targetObjectPath);
                if (target != null)
                {
                    action.targetObject = target.gameObject;
                    MarkProfileDirty();
                }
            }

            if (action.skinnedRenderer == null && !string.IsNullOrWhiteSpace(action.skinnedRendererPath))
            {
                Transform target = FindAvatarTransform(action.skinnedRendererPath);
                if (target != null)
                {
                    action.skinnedRenderer = target.GetComponent<SkinnedMeshRenderer>();
                    MarkProfileDirty();
                }
            }

            if (action.renderer == null && !string.IsNullOrWhiteSpace(action.rendererPath))
            {
                Transform target = FindAvatarTransform(action.rendererPath);
                if (target != null)
                {
                    action.renderer = target.GetComponent<Renderer>();
                    MarkProfileDirty();
                }
            }

            if (action.component == null && !string.IsNullOrWhiteSpace(action.componentPath))
            {
                Transform target = FindAvatarTransform(action.componentPath);
                Component component = FindComponentOnTransform(target, action.componentTypeName);
                if (component != null)
                {
                    action.component = component;
                    MarkProfileDirty();
                }
            }

            StoreActionReferencePaths(action);
        }

        private static Type GetComponentType(string componentTypeName)
        {
            if (string.IsNullOrWhiteSpace(componentTypeName))
            {
                return null;
            }

            Type direct = Type.GetType(componentTypeName);
            if (direct != null)
            {
                return direct;
            }

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = assembly.GetType(componentTypeName, false);
                if (type != null)
                {
                    return type;
                }
            }

            string shortName = componentTypeName.Split(',')[0].Trim();
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = GetLoadableTypes(assembly).FirstOrDefault(candidate =>
                    string.Equals(candidate.FullName, shortName, StringComparison.Ordinal)
                    || string.Equals(candidate.Name, shortName, StringComparison.Ordinal));
                if (type != null)
                {
                    return type;
                }
            }

            return null;
        }

        private static IEnumerable<Type> GetLoadableTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException exception)
            {
                return exception.Types.Where(type => type != null);
            }
        }

        private static string GetComponentTypeDisplayName(string componentTypeName)
        {
            Type type = GetComponentType(componentTypeName);
            return type != null ? type.Name : string.IsNullOrWhiteSpace(componentTypeName) ? "(Unknown Type)" : componentTypeName;
        }

        private Transform FindAvatarTransform(string relativePath)
        {
            if (profile == null || profile.avatarRoot == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(relativePath))
            {
                return profile.avatarRoot.transform;
            }

            return FindTransformByFlexiblePath(profile.avatarRoot.transform, relativePath);
        }

        private static Transform FindTransformByFlexiblePath(Transform root, string relativePath)
        {
            if (root == null)
            {
                return null;
            }

            string normalized = NormalizeAvatarPath(relativePath);
            Transform exact = root.Find(normalized);
            if (exact != null)
            {
                return exact;
            }

            string rootPrefix = $"{root.name}/";
            if (normalized.StartsWith(rootPrefix, StringComparison.Ordinal))
            {
                exact = root.Find(normalized.Substring(rootPrefix.Length));
                if (exact != null)
                {
                    return exact;
                }
            }

            Transform[] descendants = root.GetComponentsInChildren<Transform>(true);
            Transform match = null;
            int bestLength = int.MaxValue;
            foreach (Transform candidate in descendants)
            {
                string candidatePath = NormalizeAvatarPath(AnimationUtility.CalculateTransformPath(candidate, root));
                if (!string.Equals(candidatePath, normalized, StringComparison.Ordinal)
                    && !candidatePath.EndsWith($"/{normalized}", StringComparison.Ordinal)
                    && !normalized.EndsWith($"/{candidatePath}", StringComparison.Ordinal))
                {
                    continue;
                }

                if (candidatePath.Length < bestLength)
                {
                    match = candidate;
                    bestLength = candidatePath.Length;
                }
            }

            return match;
        }

        private static string NormalizeAvatarPath(string path)
        {
            return (path ?? string.Empty).Replace("\\", "/").Trim('/');
        }

        private static Component FindComponentOnTransform(Transform target, string componentTypeName)
        {
            if (target == null)
            {
                return null;
            }

            Type componentType = GetComponentType(componentTypeName);
            if (componentType != null)
            {
                Component component = target.GetComponent(componentType);
                if (component != null)
                {
                    return component;
                }
            }

            string fullName = componentType != null ? componentType.FullName : GetFullTypeNameWithoutAssembly(componentTypeName);
            string shortName = componentType != null ? componentType.Name : GetShortTypeName(componentTypeName);
            foreach (Component component in target.GetComponents<Component>())
            {
                if (component == null)
                {
                    continue;
                }

                Type actualType = component.GetType();
                if (string.Equals(actualType.AssemblyQualifiedName, componentTypeName, StringComparison.Ordinal)
                    || string.Equals(actualType.FullName, fullName, StringComparison.Ordinal)
                    || string.Equals(actualType.Name, shortName, StringComparison.Ordinal))
                {
                    return component;
                }
            }

            return null;
        }

        private static string GetFullTypeNameWithoutAssembly(string typeName)
        {
            return string.IsNullOrWhiteSpace(typeName) ? string.Empty : typeName.Split(',')[0].Trim();
        }

        private static string GetShortTypeName(string typeName)
        {
            string fullName = GetFullTypeNameWithoutAssembly(typeName);
            int dot = fullName.LastIndexOf('.');
            return dot >= 0 ? fullName.Substring(dot + 1) : fullName;
        }

        private static bool CanReadShaderFloat(PuddlesAvatarActionRow action)
        {
            Material material = GetRendererMaterialAtSlot(action.renderer, action.materialSlot);
            return material != null && !string.IsNullOrWhiteSpace(action.shaderPropertyName) && material.HasProperty(action.shaderPropertyName);
        }

        private static Material GetRendererMaterialAtSlot(Renderer renderer, int slot)
        {
            if (renderer == null || renderer.sharedMaterials == null || slot < 0 || slot >= renderer.sharedMaterials.Length)
            {
                return null;
            }

            return renderer.sharedMaterials[slot];
        }

        private static float BoolToFloat(bool value)
        {
            return value ? 1f : 0f;
        }

        private void MarkProfileDirty()
        {
            if (suppressProfileDirty)
            {
                return;
            }

            if (profile != null)
            {
                EditorUtility.SetDirty(profile);
            }
        }

        private static string CreateStableId()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 12);
        }

        private static string SanitizeAssetName(string value)
        {
            string cleaned = string.Join("_", (value ?? "Asset").Split(Path.GetInvalidFileNameChars()));
            return string.IsNullOrWhiteSpace(cleaned) ? "Asset" : cleaned;
        }

        private static string SanitizeLayerLabel(string value)
        {
            string cleaned = string.Join(" ", (value ?? "Toggle").Split(Path.GetInvalidFileNameChars())).Trim();
            if (string.IsNullOrWhiteSpace(cleaned))
            {
                cleaned = "Toggle";
            }

            return cleaned.Length <= 36 ? cleaned : cleaned.Substring(0, 36);
        }

        internal static string BuildReadableParameterName(string prefix, PuddlesAvatarActionControl control)
        {
            string label = SanitizeParameterSegment(control == null ? null : control.displayName);
            string id = string.IsNullOrWhiteSpace(control == null ? null : control.id) ? "missingid" : control.id.Trim();
            return $"{prefix}/{label}_{id}";
        }

        private static string SanitizeParameterSegment(string value)
        {
            string source = string.IsNullOrWhiteSpace(value) ? "Control" : value.Trim();
            StringBuilder builder = new StringBuilder(source.Length);
            bool previousWasSeparator = false;
            foreach (char character in source)
            {
                if (char.IsLetterOrDigit(character))
                {
                    builder.Append(character);
                    previousWasSeparator = false;
                }
                else if (!previousWasSeparator)
                {
                    builder.Append('_');
                    previousWasSeparator = true;
                }
            }

            string cleaned = builder.ToString().Trim('_');
            return string.IsNullOrWhiteSpace(cleaned) ? "Control" : cleaned;
        }

        private sealed class AvatarRecordSnapshot
        {
            public readonly Dictionary<string, AvatarRecordedValue> Values = new Dictionary<string, AvatarRecordedValue>(StringComparer.OrdinalIgnoreCase);

            public void Add(AvatarRecordedValue value)
            {
                if (value == null || string.IsNullOrWhiteSpace(value.Key))
                {
                    return;
                }

                Values[value.Key] = value;
            }
        }

        private sealed class AvatarRecordedValue
        {
            public string Key;
            public string Path;
            public string DisplayPath;
            public string Label;
            public PuddlesAvatarActionKind Kind;
            public GameObject TargetObject;
            public SkinnedMeshRenderer SkinnedRenderer;
            public Renderer Renderer;
            public Component Component;
            public string ComponentTypeName;
            public string BlendshapeName;
            public int MaterialSlot;
            public Material MaterialValue;
            public string ShaderPropertyName;
            public bool BoolValue;
            public float FloatValue;

            public static AvatarRecordedValue ForObjectState(string path, string displayPath, GameObject targetObject, bool active)
            {
                return new AvatarRecordedValue
                {
                    Key = $"object|{path}|GameObject.m_IsActive",
                    Path = path,
                    DisplayPath = displayPath,
                    Label = $"Object State: {displayPath}",
                    Kind = PuddlesAvatarActionKind.ObjectState,
                    TargetObject = targetObject,
                    BoolValue = active
                };
            }

            public static AvatarRecordedValue ForBlendshape(string path, string displayPath, SkinnedMeshRenderer renderer, string blendshapeName, float value)
            {
                return new AvatarRecordedValue
                {
                    Key = $"blendshape|{path}|{blendshapeName}",
                    Path = path,
                    DisplayPath = displayPath,
                    Label = $"Blendshape: {displayPath} / {blendshapeName}",
                    Kind = PuddlesAvatarActionKind.Blendshape,
                    SkinnedRenderer = renderer,
                    BlendshapeName = blendshapeName,
                    FloatValue = value
                };
            }

            public static AvatarRecordedValue ForMaterialSwap(string path, string displayPath, Renderer renderer, int materialSlot, Material material)
            {
                return new AvatarRecordedValue
                {
                    Key = $"material|{path}|{materialSlot}",
                    Path = path,
                    DisplayPath = displayPath,
                    Label = $"Material Swap: {displayPath} slot {materialSlot}",
                    Kind = PuddlesAvatarActionKind.MaterialSwap,
                    Renderer = renderer,
                    MaterialSlot = materialSlot,
                    MaterialValue = material
                };
            }

            public static AvatarRecordedValue ForShaderFloat(string path, string displayPath, Renderer renderer, int materialSlot, Material material, string shaderPropertyName, float value)
            {
                return new AvatarRecordedValue
                {
                    Key = $"shaderfloat|{path}|{materialSlot}|{shaderPropertyName}",
                    Path = path,
                    DisplayPath = displayPath,
                    Label = $"Shader Float: {displayPath} slot {materialSlot} {shaderPropertyName}",
                    Kind = PuddlesAvatarActionKind.ShaderFloat,
                    Renderer = renderer,
                    MaterialSlot = materialSlot,
                    MaterialValue = material,
                    ShaderPropertyName = shaderPropertyName,
                    FloatValue = value
                };
            }

            public static AvatarRecordedValue ForComponentEnabled(string path, string displayPath, Component component, bool enabled)
            {
                string typeName = component != null ? component.GetType().AssemblyQualifiedName : string.Empty;
                string displayType = component != null ? component.GetType().Name : "Component";
                return new AvatarRecordedValue
                {
                    Key = $"component|{path}|{typeName}|m_Enabled",
                    Path = path,
                    DisplayPath = displayPath,
                    Label = $"Component Enabled: {displayPath} / {displayType}",
                    Kind = PuddlesAvatarActionKind.ComponentEnabled,
                    Component = component,
                    ComponentTypeName = typeName,
                    BoolValue = enabled
                };
            }

            public string FormatValue()
            {
                switch (Kind)
                {
                    case PuddlesAvatarActionKind.ObjectState:
                        return BoolValue ? "Active" : "Inactive";
                    case PuddlesAvatarActionKind.ComponentEnabled:
                        return BoolValue ? "Enabled" : "Disabled";
                    case PuddlesAvatarActionKind.MaterialSwap:
                        return MaterialValue != null ? MaterialValue.name : "None";
                    case PuddlesAvatarActionKind.Blendshape:
                    case PuddlesAvatarActionKind.ShaderFloat:
                        return FloatValue.ToString("0.###");
                    default:
                        return string.Empty;
                }
            }
        }

        private sealed class AvatarRecordedChange
        {
            public readonly AvatarRecordedValue Before;
            public readonly AvatarRecordedValue After;

            public AvatarRecordedChange(AvatarRecordedValue before, AvatarRecordedValue after)
            {
                Before = before;
                After = after;
            }

            public string Summary => $"{After.Label}: {Before.FormatValue()} -> {After.FormatValue()}";

            public string Detail => $"{After.Label}\nBefore: {Before.FormatValue()}\nAfter: {After.FormatValue()}";

            public string Signature => $"{After.Key}|{After.FormatValue()}";
        }

        private IEnumerable<string> GetExistingAvatarParameterNames()
        {
            if (profile == null)
            {
                yield break;
            }

            if (profile.expressionParameters != null && profile.expressionParameters.parameters != null)
            {
                foreach (VRCExpressionParameters.Parameter parameter in profile.expressionParameters.parameters)
                {
                    if (parameter != null && !string.IsNullOrWhiteSpace(parameter.name))
                    {
                        yield return parameter.name;
                    }
                }
            }

            if (profile.fxController != null)
            {
                foreach (AnimatorControllerParameter parameter in profile.fxController.parameters)
                {
                    if (parameter != null && !string.IsNullOrWhiteSpace(parameter.name))
                    {
                        yield return parameter.name;
                    }
                }
            }
        }

        private static string TruncateMenuName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "Toggle";
            }

            return value.Length <= 32 ? value : value.Substring(0, 32);
        }

        private static bool IsProjectAssetFolder(string folder)
        {
            string normalized = (folder ?? string.Empty).Replace("\\", "/").Trim('/');
            return normalized == "Assets" || normalized.StartsWith("Assets/", StringComparison.Ordinal);
        }

        private static void EnsureFolder(string folder)
        {
            string normalized = folder.Replace("\\", "/").Trim('/');
            if (AssetDatabase.IsValidFolder(normalized))
            {
                return;
            }

            string[] parts = normalized.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = $"{current}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                current = next;
            }
        }

        private static void EnsureMenuControlList(VRCExpressionsMenu menu)
        {
            if (menu != null && menu.controls == null)
            {
                menu.controls = new List<VRCExpressionsMenu.Control>();
            }
        }

        private static bool MenuExistsInTree(VRCExpressionsMenu current, VRCExpressionsMenu target, HashSet<VRCExpressionsMenu> visited)
        {
            if (current == null || target == null || !visited.Add(current))
            {
                return false;
            }

            if (current == target)
            {
                return true;
            }

            EnsureMenuControlList(current);
            return current.controls.Any(control =>
                control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                && MenuExistsInTree(control.subMenu, target, visited));
        }

        private static string FindMenuPath(VRCExpressionsMenu current, VRCExpressionsMenu target, string path, HashSet<VRCExpressionsMenu> visited)
        {
            if (current == null || target == null || !visited.Add(current))
            {
                return string.Empty;
            }

            if (current == target)
            {
                return path;
            }

            EnsureMenuControlList(current);
            foreach (VRCExpressionsMenu.Control control in current.controls)
            {
                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null)
                {
                    continue;
                }

                string childPath = $"{path}/{control.name}";
                string foundPath = FindMenuPath(control.subMenu, target, childPath, visited);
                if (!string.IsNullOrWhiteSpace(foundPath))
                {
                    return foundPath;
                }
            }

            return string.Empty;
        }

        private static bool RemoveMenuControlByParameter(VRCExpressionsMenu menu, string parameterName)
        {
            return RemoveMenuControlByParameter(menu, parameterName, new HashSet<VRCExpressionsMenu>());
        }

        private static string GetMenuControlParameterName(VRCExpressionsMenu.Control control)
        {
            if (control == null)
            {
                return string.Empty;
            }

            if (control.parameter != null && !string.IsNullOrWhiteSpace(control.parameter.name))
            {
                return control.parameter.name;
            }

            if (control.subParameters != null)
            {
                VRCExpressionsMenu.Control.Parameter parameter = control.subParameters.FirstOrDefault(subParameter => subParameter != null && !string.IsNullOrWhiteSpace(subParameter.name));
                if (parameter != null)
                {
                    return parameter.name;
                }
            }

            return string.Empty;
        }

        private static bool MenuControlUsesParameter(VRCExpressionsMenu.Control control, string parameterName)
        {
            if (control == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return false;
            }

            if (control.parameter != null && string.Equals(control.parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return control.subParameters != null
                && control.subParameters.Any(subParameter => subParameter != null && string.Equals(subParameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private static bool RemoveMenuControlByParameter(VRCExpressionsMenu menu, string parameterName, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return false;
            }

            bool removed = false;
            EnsureMenuControlList(menu);
            for (int i = menu.controls.Count - 1; i >= 0; i--)
            {
                VRCExpressionsMenu.Control control = menu.controls[i];
                if (MenuControlUsesParameter(control, parameterName))
                {
                    menu.controls.RemoveAt(i);
                    removed = true;
                    continue;
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                    && RemoveMenuControlByParameter(control.subMenu, parameterName, visited))
                {
                    removed = true;
                }
            }

            if (removed)
            {
                EditorUtility.SetDirty(menu);
            }

            return removed;
        }

        private static bool RemoveMenuControlsReferencingAssetsInFolder(VRCExpressionsMenu menu, string folder)
        {
            return RemoveMenuControlsReferencingAssetsInFolder(menu, (folder ?? string.Empty).Replace("\\", "/").TrimEnd('/'), new HashSet<VRCExpressionsMenu>());
        }

        private static bool RemoveMenuControlsReferencingAssetsInFolder(VRCExpressionsMenu menu, string folder, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || string.IsNullOrWhiteSpace(folder) || !visited.Add(menu))
            {
                return false;
            }

            bool removed = false;
            EnsureMenuControlList(menu);
            for (int i = menu.controls.Count - 1; i >= 0; i--)
            {
                VRCExpressionsMenu.Control control = menu.controls[i];
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                {
                    string path = AssetDatabase.GetAssetPath(control.subMenu).Replace("\\", "/");
                    if (path.StartsWith($"{folder}/", StringComparison.OrdinalIgnoreCase))
                    {
                        menu.controls.RemoveAt(i);
                        removed = true;
                        continue;
                    }

                    if (RemoveMenuControlsReferencingAssetsInFolder(control.subMenu, folder, visited))
                    {
                        removed = true;
                    }
                }
            }

            if (removed)
            {
                EditorUtility.SetDirty(menu);
            }

            return removed;
        }

        private static IEnumerable<List<T>> Chunk<T>(IReadOnlyList<T> items, int size)
        {
            for (int i = 0; i < items.Count; i += size)
            {
                List<T> chunk = new List<T>();
                for (int j = i; j < Math.Min(i + size, items.Count); j++)
                {
                    chunk.Add(items[j]);
                }

                yield return chunk;
            }
        }
    }

    public sealed class AvatarActionMenuManagerWindow : EditorWindow
    {
        private const string DefaultOutputFolder = "Assets/PuddlesVrcTools/Generated/AvatarActions";
        private const string DefaultParameterPrefix = "Puddles/Action";
        private const int MaxControlsPerMenu = 8;

        private PuddlesAvatarActionProfile profile;
        private string selectedControlId;
        private VRCExpressionsMenu selectedMenu;
        private string selectedPath = "Root";
        private string newSubmenuName = "New Submenu";
        private string renameText = string.Empty;
        private bool menuEditingFoldout = true;
        private bool menuContentsFoldout = true;
        private int selectedCleanupIndex = -1;
        private Vector2 treeScroll;
        private Vector2 detailScroll;
        private Vector2 menuContentsScroll;
        private Vector2 cleanupScroll;
        private readonly List<MenuCleanupItem> cleanupItems = new List<MenuCleanupItem>();
        private readonly HashSet<string> expandedPaths = new HashSet<string>();

        public static void Open(PuddlesAvatarActionProfile profile, string selectedControlId = null)
        {
            AvatarActionMenuManagerWindow window = GetWindow<AvatarActionMenuManagerWindow>("Action Menu Manager");
            window.profile = profile;
            window.selectedControlId = selectedControlId;
            window.selectedMenu = profile != null ? profile.rootMenu : null;
            window.selectedPath = "Root";
            window.renameText = "Root";
            window.selectedCleanupIndex = -1;
            window.cleanupItems.Clear();
            window.expandedPaths.Clear();
            window.expandedPaths.Add("Root");
            window.RefreshCleanupItems();
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Action Builder Menu Manager", EditorStyles.boldLabel);
            if (profile == null || profile.rootMenu == null)
            {
                EditorGUILayout.HelpBox("Assign a profile with a root expression menu first.", MessageType.Warning);
                return;
            }

            EnsureLists();
            expandedPaths.Add("Root");
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawMenuTree();
                DrawDetails();
            }
        }

        private void DrawMenuTree()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(320)))
            {
                EditorGUILayout.LabelField("Expression Menu Tree", EditorStyles.boldLabel);
                treeScroll = EditorGUILayout.BeginScrollView(treeScroll, EditorStyles.helpBox);
                DrawMenuNode(profile.rootMenu, "Root", 0, new HashSet<VRCExpressionsMenu>());
                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawMenuNode(VRCExpressionsMenu menu, string path, int depth, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            List<VRCExpressionsMenu.Control> childMenus = menu.controls
                .Where(control => control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                .ToList();
            bool hasChildren = childMenus.Count > 0;
            bool expanded = expandedPaths.Contains(path);
            bool isManaged = IsManaged(menu);
            string flags = BuildMenuFlags(menu, isManaged);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(depth * 16);
                using (new EditorGUI.DisabledScope(!hasChildren))
                {
                    if (GUILayout.Button(hasChildren ? (expanded ? "v" : ">") : " ", GUILayout.Width(24)))
                    {
                        if (expanded)
                        {
                            expandedPaths.Remove(path);
                        }
                        else
                        {
                            expandedPaths.Add(path);
                        }
                    }
                }

                GUIStyle style = selectedMenu == menu ? EditorStyles.toolbarButton : GUI.skin.button;
                string label = path.Split('/').Last();
                if (GUILayout.Button($"{label} {flags}", style))
                {
                    selectedMenu = menu;
                    selectedPath = path;
                    renameText = GetEditableMenuName(menu, path);
                    selectedCleanupIndex = -1;
                    RefreshCleanupItems();
                }
            }

            if (!expanded)
            {
                return;
            }

            foreach (VRCExpressionsMenu.Control control in childMenus)
            {
                DrawMenuNode(control.subMenu, $"{path}/{control.name}", depth + 1, visited);
            }
        }

        private void DrawDetails()
        {
            using (new EditorGUILayout.VerticalScope())
            {
                detailScroll = EditorGUILayout.BeginScrollView(detailScroll);
                EditorGUILayout.LabelField("Selected Menu", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("Path", selectedPath);
                EditorGUILayout.ObjectField("Menu Asset", selectedMenu, typeof(VRCExpressionsMenu), false);
                DrawSelectedMenuLabelRename();
                EditorGUILayout.LabelField("Type", IsManaged(selectedMenu) ? "Managed" : "Existing");
                EditorGUILayout.LabelField("Controls", selectedMenu != null && selectedMenu.controls != null ? selectedMenu.controls.Count.ToString() : "0");

                if (GetSelectedControl() != null)
                {
                    using (new EditorGUI.DisabledScope(selectedMenu == null))
                    {
                        if (GUILayout.Button("Use This Menu For Selected Toggle", GUILayout.Height(28)))
                        {
                            UseSelectedMenuForToggle();
                        }
                    }
                }

                EditorGUILayout.Space();
                DrawMenuEditing();
#if PUDDLES_EXPERIMENTAL_TOOLS
                EditorGUILayout.Space();
                DrawSelectedMenuContents();
#endif

                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawMenuEditing()
        {
            menuEditingFoldout = EditorGUILayout.Foldout(menuEditingFoldout, "Menu Editing", true);
            if (!menuEditingFoldout)
            {
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Rename Managed Submenu", EditorStyles.boldLabel);
                bool canRename = IsManaged(selectedMenu);
                using (new EditorGUI.DisabledScope(!canRename))
                {
                    renameText = EditorGUILayout.TextField("Name", string.IsNullOrWhiteSpace(renameText) ? GetEditableMenuName(selectedMenu, selectedPath) : renameText);
                    if (GUILayout.Button("Rename Managed Submenu"))
                    {
                        RenameManagedSubmenu();
                    }
                }

                if (!canRename)
                {
                    EditorGUILayout.LabelField("Existing/manual menus are shown read-only here.", EditorStyles.wordWrappedMiniLabel);
                }

                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Create Managed Submenu", EditorStyles.boldLabel);
                newSubmenuName = EditorGUILayout.TextField("Name", newSubmenuName);
                using (new EditorGUI.DisabledScope(selectedMenu == null || string.IsNullOrWhiteSpace(newSubmenuName)))
                {
                    if (GUILayout.Button("Create Managed Submenu Here"))
                    {
                        CreateManagedSubmenu();
                    }
                }

                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Delete Managed Submenu", EditorStyles.boldLabel);
                using (new EditorGUI.DisabledScope(!IsManaged(selectedMenu)))
                {
                    if (GUILayout.Button("Delete Managed Submenu"))
                    {
                        DeleteManagedSubmenu();
                    }
                }

                EditorGUILayout.Space();
                DrawReadOnlyMenuContents();
            }
        }

        private void DrawReadOnlyMenuContents()
        {
            string countText = selectedMenu != null && selectedMenu.controls != null ? selectedMenu.controls.Count.ToString() : "0";
            menuContentsFoldout = EditorGUILayout.Foldout(menuContentsFoldout, $"Menu Contents ({countText})", true);
            if (!menuContentsFoldout)
            {
                return;
            }

            if (selectedMenu == null)
            {
                EditorGUILayout.LabelField("Select a menu to view its controls.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            EnsureMenuControlList(selectedMenu);
            if (selectedMenu.controls.Count == 0)
            {
                EditorGUILayout.LabelField("This menu has no direct controls.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            menuContentsScroll = EditorGUILayout.BeginScrollView(menuContentsScroll, GUILayout.MinHeight(90), GUILayout.MaxHeight(220));
            for (int i = 0; i < selectedMenu.controls.Count; i++)
            {
                DrawReadOnlyMenuControl(selectedMenu.controls[i], i);
            }

            EditorGUILayout.EndScrollView();
        }

        private void DrawReadOnlyMenuControl(VRCExpressionsMenu.Control control, int index)
        {
            if (control == null)
            {
                EditorGUILayout.LabelField($"{index + 1}. Missing Control", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField($"{index + 1}. {GetMenuControlDisplayName(control)}", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("Type", GetMenuControlTypeLabel(control));

                string parameterName = GetMenuControlParameterName(control);
                if (!string.IsNullOrWhiteSpace(parameterName))
                {
                    EditorGUILayout.LabelField("Parameter", parameterName);
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    EditorGUILayout.ObjectField("Submenu", control.subMenu, typeof(VRCExpressionsMenu), false);
                    int childCount = control.subMenu != null && control.subMenu.controls != null ? control.subMenu.controls.Count : 0;
                    EditorGUILayout.LabelField("Child Controls", childCount.ToString());
                }
                else if (control.type == VRCExpressionsMenu.Control.ControlType.Toggle
                    || control.type == VRCExpressionsMenu.Control.ControlType.Button)
                {
                    EditorGUILayout.LabelField("Value", control.value.ToString("0.###"));
                }

                string subParameterSummary = GetSubParameterSummary(control);
                if (!string.IsNullOrWhiteSpace(subParameterSummary))
                {
                    EditorGUILayout.LabelField("Sub Parameters", subParameterSummary, EditorStyles.wordWrappedMiniLabel);
                }
            }
        }

        private static string GetMenuControlDisplayName(VRCExpressionsMenu.Control control)
        {
            return control == null || string.IsNullOrWhiteSpace(control.name) ? "(Unnamed)" : control.name;
        }

        private static string GetMenuControlTypeLabel(VRCExpressionsMenu.Control control)
        {
            if (control == null)
            {
                return "Missing";
            }

            switch (control.type)
            {
                case VRCExpressionsMenu.Control.ControlType.SubMenu:
                    return "Submenu";
                case VRCExpressionsMenu.Control.ControlType.Toggle:
                    return "Toggle";
                case VRCExpressionsMenu.Control.ControlType.Button:
                    return "Button";
                case VRCExpressionsMenu.Control.ControlType.RadialPuppet:
                    return "Radial Puppet";
                case VRCExpressionsMenu.Control.ControlType.TwoAxisPuppet:
                    return "Two Axis Puppet";
                case VRCExpressionsMenu.Control.ControlType.FourAxisPuppet:
                    return "Four Axis Puppet";
                default:
                    return control.type.ToString();
            }
        }

        private static string GetSubParameterSummary(VRCExpressionsMenu.Control control)
        {
            if (control == null || control.subParameters == null || control.subParameters.Length == 0)
            {
                return string.Empty;
            }

            return string.Join(", ", control.subParameters
                .Where(parameter => parameter != null && !string.IsNullOrWhiteSpace(parameter.name))
                .Select(parameter => parameter.name));
        }

        private void DrawSelectedMenuLabelRename()
        {
            VRCExpressionsMenu parentMenu = FindParentMenu(profile.rootMenu, selectedMenu, new HashSet<VRCExpressionsMenu>());
            bool canRename = selectedMenu != null && parentMenu != null;
            using (new EditorGUI.DisabledScope(!canRename))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    renameText = EditorGUILayout.TextField("Menu Label", string.IsNullOrWhiteSpace(renameText) ? GetEditableMenuName(selectedMenu, selectedPath) : renameText);
                    if (GUILayout.Button("Rename", GUILayout.Width(80)))
                    {
                        RenameSelectedMenuLabel(parentMenu);
                    }
                }
            }
        }

        private void RenameSelectedMenuLabel(VRCExpressionsMenu parentMenu)
        {
            if (parentMenu == null || selectedMenu == null)
            {
                return;
            }

            string displayName = TruncateMenuName(renameText.Trim());
            if (string.IsNullOrWhiteSpace(displayName))
            {
                return;
            }

            EnsureMenuControlList(parentMenu);
            VRCExpressionsMenu.Control parentControl = parentMenu.controls.FirstOrDefault(control =>
                control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                && control.subMenu == selectedMenu);
            if (parentControl == null)
            {
                return;
            }

            parentControl.name = displayName;
            PuddlesAvatarManagedSubmenu record = profile.managedSubmenus.FirstOrDefault(menu => menu != null && menu.menu == selectedMenu);
            if (record != null)
            {
                record.displayName = displayName;
            }

            RefreshMenuPathCaches();
            selectedPath = FindMenuPath(profile.rootMenu, selectedMenu, "Root", new HashSet<VRCExpressionsMenu>());
            if (string.IsNullOrWhiteSpace(selectedPath))
            {
                selectedPath = "Root";
            }

            expandedPaths.Add(GetParentPath(selectedPath));
            EditorUtility.SetDirty(parentMenu);
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            Repaint();
        }

        private void DrawSelectedMenuContents()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("Selected Menu Contents", EditorStyles.boldLabel);
                    if (GUILayout.Button("Refresh", GUILayout.Width(80)))
                    {
                        RefreshCleanupItems();
                    }
                }

                if (cleanupItems.Count == 0)
                {
                    EditorGUILayout.LabelField("No direct controls found in this menu.", EditorStyles.wordWrappedMiniLabel);
                    return;
                }

                cleanupScroll = EditorGUILayout.BeginScrollView(cleanupScroll, GUILayout.MinHeight(110), GUILayout.MaxHeight(190));
                for (int i = 0; i < cleanupItems.Count; i++)
                {
                    MenuCleanupItem item = cleanupItems[i];
                    GUIStyle style = selectedCleanupIndex == i ? EditorStyles.toolbarButton : GUI.skin.button;
                    if (GUILayout.Button(item.RowLabel, style))
                    {
                        selectedCleanupIndex = i;
                    }
                }

                EditorGUILayout.EndScrollView();

                MenuCleanupItem selected = GetSelectedCleanupItem();
                if (selected != null)
                {
                    DrawCleanupDetails(selected);
                }
            }
        }

        private void DrawCleanupDetails(MenuCleanupItem item)
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Cleanup Details", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Menu Item", item.Name);
            EditorGUILayout.LabelField("Type", item.TypeLabel);
            EditorGUILayout.LabelField("Confidence", item.Confidence);
            EditorGUILayout.LabelField("Location", item.Location);

            if (!string.IsNullOrWhiteSpace(item.ParameterName))
            {
                EditorGUILayout.LabelField("Parameter", item.ParameterName);
                EditorGUILayout.LabelField("Expression Parameter", item.HasExpressionParameter ? "Found" : "Not found");
                EditorGUILayout.LabelField("FX Parameter", item.HasAnimatorParameter ? "Found" : "Not found");
                EditorGUILayout.LabelField("Matched FX Layers", item.MatchedLayers.Count.ToString());
            }

            if (item.Submenu != null)
            {
                EnsureMenuControlList(item.Submenu);
                EditorGUILayout.ObjectField("Submenu Asset", item.Submenu, typeof(VRCExpressionsMenu), false);
                EditorGUILayout.LabelField("Child Controls", item.Submenu.controls.Count.ToString());
            }

            if (item.MatchedLayers.Count > 0)
            {
                EditorGUILayout.LabelField("FX Layers", EditorStyles.boldLabel);
                foreach (AnimatorControllerLayer layer in item.MatchedLayers)
                {
                    EditorGUILayout.LabelField($"- {layer.name}", EditorStyles.wordWrappedMiniLabel);
                }
            }

            if (item.Clips.Count > 0)
            {
                EditorGUILayout.LabelField("Animation Clips", EditorStyles.boldLabel);
                foreach (AnimationClip clip in item.Clips.Take(8))
                {
                    EditorGUILayout.ObjectField(clip, typeof(AnimationClip), false);
                }

                if (item.Clips.Count > 8)
                {
                    EditorGUILayout.LabelField($"+ {item.Clips.Count - 8} more", EditorStyles.miniLabel);
                }
            }

            if (!item.CanRemoveFromAvatar)
            {
                EditorGUILayout.HelpBox(item.BlockReason, MessageType.Info);
            }

            using (new EditorGUI.DisabledScope(!item.CanRemoveFromAvatar))
            {
                if (GUILayout.Button("Remove From Avatar", GUILayout.Height(28)))
                {
                    RemoveCleanupItemFromAvatar(item, true);
                }
            }

            using (new EditorGUI.DisabledScope(!item.CanRemoveFromAvatar || BuildDeleteCandidates(item).Count == 0))
            {
                if (GUILayout.Button("Delete From Project...", GUILayout.Height(28)))
                {
                    OpenDeleteChecklist(item);
                }
            }
        }

        private void RefreshCleanupItems()
        {
            cleanupItems.Clear();
            if (profile == null || selectedMenu == null)
            {
                selectedCleanupIndex = -1;
                return;
            }

            EnsureLists();
            EnsureMenuControlList(selectedMenu);
            HashSet<string> ownedParameters = new HashSet<string>(
                profile.controls.SelectMany(control => BuildParameterNames(profile, control)),
                StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < selectedMenu.controls.Count; i++)
            {
                cleanupItems.Add(BuildCleanupItem(selectedMenu.controls[i], i, ownedParameters));
            }

            if (selectedCleanupIndex >= cleanupItems.Count)
            {
                selectedCleanupIndex = cleanupItems.Count - 1;
            }
        }

        private MenuCleanupItem BuildCleanupItem(VRCExpressionsMenu.Control menuControl, int index, HashSet<string> ownedParameters)
        {
            string parameterName = GetMenuControlParameterName(menuControl);
            string name = menuControl != null && !string.IsNullOrWhiteSpace(menuControl.name) ? menuControl.name : "(Unnamed)";
            VRCExpressionsMenu.Control.ControlType controlType = menuControl != null ? menuControl.type : default;
            PuddlesAvatarActionControl ownedControl = !string.IsNullOrWhiteSpace(parameterName)
                ? profile.controls.FirstOrDefault(control => string.Equals(BuildParameterName(profile, control), parameterName, StringComparison.OrdinalIgnoreCase))
                : null;
            List<AnimatorControllerLayer> matchedLayers = FindLayersUsingParameter(parameterName).ToList();
            List<AnimationClip> clips = matchedLayers
                .SelectMany(CollectLayerClips)
                .Where(clip => clip != null)
                .Distinct()
                .ToList();

            MenuCleanupItem item = new MenuCleanupItem
            {
                Name = name,
                Type = controlType,
                TypeLabel = controlType.ToString(),
                ParameterName = parameterName,
                ParentMenu = selectedMenu,
                MenuControl = menuControl,
                ControlIndex = index,
                Submenu = menuControl != null ? menuControl.subMenu : null,
                ActionBuilderControl = ownedControl,
                IsActionBuilderOwned = ownedControl != null || (!string.IsNullOrWhiteSpace(parameterName) && ownedParameters.Contains(parameterName)),
                HasExpressionParameter = HasExpressionParameter(parameterName),
                HasAnimatorParameter = HasAnimatorParameter(parameterName),
                MatchedLayers = matchedLayers,
                Clips = clips,
                Location = $"{selectedPath}/{name}"
            };

            item.IsSubmenu = menuControl != null && menuControl.type == VRCExpressionsMenu.Control.ControlType.SubMenu;
            item.Confidence = GetCleanupConfidence(item);
            item.CanRemoveFromAvatar = CanRemoveCleanupItem(item, out string blockReason);
            item.BlockReason = blockReason;
            item.RowLabel = BuildCleanupRowLabel(item);
            return item;
        }

        private MenuCleanupItem GetSelectedCleanupItem()
        {
            return selectedCleanupIndex >= 0 && selectedCleanupIndex < cleanupItems.Count ? cleanupItems[selectedCleanupIndex] : null;
        }

        private string GetCleanupConfidence(MenuCleanupItem item)
        {
            if (item.IsSubmenu && item.Submenu == null)
            {
                return "Missing Asset";
            }

            if (item.IsActionBuilderOwned)
            {
                return "Action Builder";
            }

            if (string.IsNullOrWhiteSpace(item.ParameterName) && !item.IsSubmenu)
            {
                return "No Parameter";
            }

            if (!item.IsSubmenu && item.MatchedLayers.Count == 0)
            {
                return "Complex";
            }

            return "Likely Manual";
        }

        private bool CanRemoveCleanupItem(MenuCleanupItem item, out string blockReason)
        {
            blockReason = string.Empty;
            if (item == null || item.ParentMenu == null || item.MenuControl == null)
            {
                blockReason = "This menu item is missing or could not be found.";
                return false;
            }

            if (item.IsSubmenu)
            {
                return true;
            }

            if (item.IsActionBuilderOwned)
            {
                return true;
            }

            if (string.IsNullOrWhiteSpace(item.ParameterName))
            {
                blockReason = "This control has no parameter to trace, so cleanup is blocked.";
                return false;
            }

            if (profile.fxController != null && item.MatchedLayers.Count == 0)
            {
                blockReason = "No FX layers were found using this parameter. This may be a complex or nonstandard control.";
                return false;
            }

            return true;
        }

        private string BuildCleanupRowLabel(MenuCleanupItem item)
        {
            string parameter = string.IsNullOrWhiteSpace(item.ParameterName) ? "no parameter" : item.ParameterName;
            return $"{item.Name} ({item.TypeLabel}) - {parameter} - {item.Confidence}";
        }

        private static string GetMenuControlParameterName(VRCExpressionsMenu.Control control)
        {
            if (control == null)
            {
                return string.Empty;
            }

            if (control.parameter != null && !string.IsNullOrWhiteSpace(control.parameter.name))
            {
                return control.parameter.name;
            }

            if (control.subParameters != null)
            {
                VRCExpressionsMenu.Control.Parameter parameter = control.subParameters.FirstOrDefault(subParameter => subParameter != null && !string.IsNullOrWhiteSpace(subParameter.name));
                if (parameter != null)
                {
                    return parameter.name;
                }
            }

            return string.Empty;
        }

        private static bool MenuControlUsesParameter(VRCExpressionsMenu.Control control, string parameterName)
        {
            if (control == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return false;
            }

            if (control.parameter != null && string.Equals(control.parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return control.subParameters != null
                && control.subParameters.Any(subParameter => subParameter != null && string.Equals(subParameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private bool HasExpressionParameter(string parameterName)
        {
            return !string.IsNullOrWhiteSpace(parameterName)
                && profile.expressionParameters != null
                && profile.expressionParameters.parameters != null
                && profile.expressionParameters.parameters.Any(parameter => parameter != null && parameter.name == parameterName);
        }

        private bool HasAnimatorParameter(string parameterName)
        {
            return !string.IsNullOrWhiteSpace(parameterName)
                && profile.fxController != null
                && profile.fxController.parameters.Any(parameter => parameter.name == parameterName);
        }

        private IEnumerable<AnimatorControllerLayer> FindLayersUsingParameter(string parameterName)
        {
            if (string.IsNullOrWhiteSpace(parameterName) || profile.fxController == null)
            {
                yield break;
            }

            foreach (AnimatorControllerLayer layer in profile.fxController.layers)
            {
                if (LayerUsesParameter(layer, parameterName))
                {
                    yield return layer;
                }
            }
        }

        private static bool LayerUsesParameter(AnimatorControllerLayer layer, string parameterName)
        {
            return layer != null
                && layer.stateMachine != null
                && StateMachineUsesParameter(layer.stateMachine, parameterName, new HashSet<AnimatorStateMachine>(), new HashSet<Motion>());
        }

        private static bool StateMachineUsesParameter(AnimatorStateMachine stateMachine, string parameterName, HashSet<AnimatorStateMachine> visited, HashSet<Motion> visitedMotions)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return false;
            }

            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
            {
                if (TransitionUsesParameter(transition, parameterName))
                {
                    return true;
                }
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state == null)
                {
                    continue;
                }

                if (AnimatorStateUsesParameter(childState.state, parameterName))
                {
                    return true;
                }

                if (MotionUsesParameter(childState.state.motion, parameterName, visitedMotions))
                {
                    return true;
                }

                foreach (AnimatorStateTransition transition in childState.state.transitions)
                {
                    if (TransitionUsesParameter(transition, parameterName))
                    {
                        return true;
                    }
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                if (StateMachineUsesParameter(childMachine.stateMachine, parameterName, visited, visitedMotions))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool TransitionUsesParameter(AnimatorStateTransition transition, string parameterName)
        {
            return transition != null
                && transition.conditions.Any(condition => string.Equals(condition.parameter, parameterName, StringComparison.Ordinal));
        }

        private static bool AnimatorStateUsesParameter(AnimatorState state, string parameterName)
        {
            if (state == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return false;
            }

            return (state.timeParameterActive && string.Equals(state.timeParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                || (state.speedParameterActive && string.Equals(state.speedParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                || (state.cycleOffsetParameterActive && string.Equals(state.cycleOffsetParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                || (state.mirrorParameterActive && string.Equals(state.mirrorParameter, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private static bool MotionUsesParameter(Motion motion, string parameterName, HashSet<Motion> visited)
        {
            if (motion == null || !visited.Add(motion))
            {
                return false;
            }

            if (motion is BlendTree blendTree)
            {
                if (string.Equals(blendTree.blendParameter, parameterName, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(blendTree.blendParameterY, parameterName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                foreach (ChildMotion child in blendTree.children)
                {
                    if (MotionUsesParameter(child.motion, parameterName, visited))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static IEnumerable<AnimationClip> CollectLayerClips(AnimatorControllerLayer layer)
        {
            if (layer == null || layer.stateMachine == null)
            {
                yield break;
            }

            foreach (AnimationClip clip in CollectStateMachineClips(layer.stateMachine, new HashSet<AnimatorStateMachine>()))
            {
                yield return clip;
            }
        }

        private static IEnumerable<AnimationClip> CollectStateMachineClips(AnimatorStateMachine stateMachine, HashSet<AnimatorStateMachine> visited)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                yield break;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state == null || childState.state.motion == null)
                {
                    continue;
                }

                foreach (AnimationClip clip in CollectMotionClips(childState.state.motion))
                {
                    yield return clip;
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                foreach (AnimationClip clip in CollectStateMachineClips(childMachine.stateMachine, visited))
                {
                    yield return clip;
                }
            }
        }

        private static IEnumerable<AnimationClip> CollectMotionClips(Motion motion)
        {
            if (motion is AnimationClip clip)
            {
                yield return clip;
                yield break;
            }

            if (motion is BlendTree blendTree)
            {
                foreach (ChildMotion child in blendTree.children)
                {
                    foreach (AnimationClip childClip in CollectMotionClips(child.motion))
                    {
                        yield return childClip;
                    }
                }
            }
        }

        private void RemoveCleanupItemFromAvatar(MenuCleanupItem item, bool showDialog)
        {
            if (item == null || !item.CanRemoveFromAvatar)
            {
                return;
            }

            if (showDialog && !ConfirmRemoveCleanupItem(item))
            {
                return;
            }

            if (item.ParentMenu != null)
            {
                EnsureMenuControlList(item.ParentMenu);
                if (item.ControlIndex >= 0
                    && item.ControlIndex < item.ParentMenu.controls.Count
                    && ReferenceEquals(item.ParentMenu.controls[item.ControlIndex], item.MenuControl))
                {
                    item.ParentMenu.controls.RemoveAt(item.ControlIndex);
                }
                else
                {
                    item.ParentMenu.controls.Remove(item.MenuControl);
                }

                EditorUtility.SetDirty(item.ParentMenu);
            }

            if (!item.IsSubmenu && !string.IsNullOrWhiteSpace(item.ParameterName))
            {
                RemoveExpressionParameter(item.ParameterName);
                RemoveAnimatorParameter(item.ParameterName);
                RemoveMatchedLayers(item);
            }

            if (item.ActionBuilderControl != null)
            {
                RemoveLayerByName(BuildLayerName(profile, item.ActionBuilderControl));
                RemoveLayerByName(BuildLegacyLayerName(item.ActionBuilderControl));
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            RefreshCleanupItems();
            Repaint();
        }

        private bool ConfirmRemoveCleanupItem(MenuCleanupItem item)
        {
            string message;
            if (item.IsSubmenu)
            {
                int childCount = item.Submenu != null && item.Submenu.controls != null ? item.Submenu.controls.Count : 0;
                message = $"Remove submenu '{item.Name}' from the avatar menu?\n\nChild controls inside it: {childCount}\n\nThis does not delete project assets.";
            }
            else
            {
                message = $"Remove '{item.Name}' from the avatar?\n\n"
                    + $"Parameter: {(string.IsNullOrWhiteSpace(item.ParameterName) ? "none" : item.ParameterName)}\n"
                    + $"FX layers removed: {item.MatchedLayers.Count}\n\n"
                    + "This does not delete project assets.";
            }

            return EditorUtility.DisplayDialog("Remove From Avatar", message, "Remove", "Cancel");
        }

        private void RemoveExpressionParameter(string parameterName)
        {
            if (profile.expressionParameters == null || profile.expressionParameters.parameters == null)
            {
                return;
            }

            int beforeCount = profile.expressionParameters.parameters.Length;
            profile.expressionParameters.parameters = profile.expressionParameters.parameters
                .Where(parameter => parameter == null || parameter.name != parameterName)
                .ToArray();
            if (profile.expressionParameters.parameters.Length != beforeCount)
            {
                EditorUtility.SetDirty(profile.expressionParameters);
            }
        }

        private void RemoveAnimatorParameter(string parameterName)
        {
            if (profile.fxController == null)
            {
                return;
            }

            AnimatorControllerParameter parameter = profile.fxController.parameters.FirstOrDefault(existing => existing.name == parameterName);
            if (parameter != null)
            {
                profile.fxController.RemoveParameter(parameter);
                EditorUtility.SetDirty(profile.fxController);
            }
        }

        private void RemoveMatchedLayers(MenuCleanupItem item)
        {
            if (profile.fxController == null || item.MatchedLayers.Count == 0)
            {
                return;
            }

            HashSet<string> layerNames = new HashSet<string>(item.MatchedLayers.Select(layer => layer.name), StringComparer.Ordinal);
            for (int i = profile.fxController.layers.Length - 1; i >= 0; i--)
            {
                if (layerNames.Contains(profile.fxController.layers[i].name))
                {
                    profile.fxController.RemoveLayer(i);
                }
            }

            EditorUtility.SetDirty(profile.fxController);
        }

        private void RemoveLayerByName(string layerName)
        {
            if (profile.fxController == null || string.IsNullOrWhiteSpace(layerName))
            {
                return;
            }

            for (int i = profile.fxController.layers.Length - 1; i >= 0; i--)
            {
                if (profile.fxController.layers[i].name == layerName)
                {
                    profile.fxController.RemoveLayer(i);
                }
            }

            EditorUtility.SetDirty(profile.fxController);
        }

        private void OpenDeleteChecklist(MenuCleanupItem item)
        {
            List<CleanupAssetCandidate> candidates = BuildDeleteCandidates(item);
            if (candidates.Count == 0)
            {
                EditorUtility.DisplayDialog("Delete From Project", "No project assets were traced for this menu item.", "OK");
                return;
            }

            MenuCleanupItem itemToRemove = item;
            AvatarActionCleanupDeleteWindow.Open(item.Name, candidates, paths =>
            {
                if (itemToRemove != null && itemToRemove.CanRemoveFromAvatar)
                {
                    RemoveCleanupItemFromAvatar(itemToRemove, false);
                }

                foreach (string path in paths)
                {
                    if (!string.IsNullOrWhiteSpace(path))
                    {
                        AssetDatabase.DeleteAsset(path);
                    }
                }

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                RefreshCleanupItems();
                Repaint();
            });
        }

        private List<CleanupAssetCandidate> BuildDeleteCandidates(MenuCleanupItem item)
        {
            Dictionary<string, CleanupAssetCandidate> candidates = new Dictionary<string, CleanupAssetCandidate>(StringComparer.OrdinalIgnoreCase);
            if (item == null)
            {
                return candidates.Values.ToList();
            }

            if (item.Submenu != null)
            {
                AddAssetCandidate(candidates, item.Submenu, "Submenu Asset", IsGeneratedAsset(item.Submenu), false);
                AddSubmenuAssetCandidates(candidates, item.Submenu, new HashSet<VRCExpressionsMenu>());
            }

            foreach (AnimationClip clip in item.Clips)
            {
                bool shared = IsClipSharedOutsideLayers(clip, item.MatchedLayers);
                AddAssetCandidate(candidates, clip, "Animation Clip", IsGeneratedAsset(clip) && !shared, shared);
            }

            if (item.ActionBuilderControl != null)
            {
                string controlFolder = Path.Combine(GetProfileGenerationFolder(profile), item.ActionBuilderControl.id).Replace("\\", "/");
                if (AssetDatabase.IsValidFolder(controlFolder))
                {
                    AddAssetCandidate(candidates, controlFolder, "Generated Folder", true, false);
                }
            }

            return candidates.Values
                .Where(candidate => !IsProtectedAsset(candidate.Path))
                .OrderByDescending(candidate => candidate.DefaultSelected)
                .ThenBy(candidate => candidate.Path, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private void AddSubmenuAssetCandidates(Dictionary<string, CleanupAssetCandidate> candidates, VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                {
                    AddAssetCandidate(candidates, control.subMenu, "Child Submenu Asset", IsGeneratedAsset(control.subMenu), false);
                    AddSubmenuAssetCandidates(candidates, control.subMenu, visited);
                    continue;
                }

                string parameterName = GetMenuControlParameterName(control);
                foreach (AnimatorControllerLayer layer in FindLayersUsingParameter(parameterName))
                {
                    List<AnimatorControllerLayer> owningLayers = new List<AnimatorControllerLayer> { layer };
                    foreach (AnimationClip clip in CollectLayerClips(layer))
                    {
                        bool shared = IsClipSharedOutsideLayers(clip, owningLayers);
                        AddAssetCandidate(candidates, clip, "Child Animation Clip", IsGeneratedAsset(clip) && !shared, shared);
                    }
                }
            }
        }

        private void AddAssetCandidate(Dictionary<string, CleanupAssetCandidate> candidates, UnityEngine.Object asset, string kind, bool defaultSelected, bool shared)
        {
            if (asset == null)
            {
                return;
            }

            string path = AssetDatabase.GetAssetPath(asset);
            AddAssetCandidate(candidates, path, kind, defaultSelected, shared);
        }

        private void AddAssetCandidate(Dictionary<string, CleanupAssetCandidate> candidates, string path, string kind, bool defaultSelected, bool shared)
        {
            if (string.IsNullOrWhiteSpace(path) || candidates.ContainsKey(path) || IsProtectedAsset(path))
            {
                return;
            }

            candidates[path] = new CleanupAssetCandidate
            {
                Path = path,
                Kind = kind,
                DefaultSelected = defaultSelected,
                Selected = defaultSelected,
                Shared = shared
            };
        }

        private bool IsGeneratedAsset(UnityEngine.Object asset)
        {
            string path = asset == null ? string.Empty : AssetDatabase.GetAssetPath(asset);
            return IsGeneratedPath(path);
        }

        private bool IsGeneratedPath(string path)
        {
            string normalized = (path ?? string.Empty).Replace("\\", "/");
            string outputFolder = (string.IsNullOrWhiteSpace(profile.outputFolder) ? DefaultOutputFolder : profile.outputFolder).Replace("\\", "/").TrimEnd('/');
            string profileFolder = GetProfileGenerationFolder(profile).Replace("\\", "/").TrimEnd('/');
            return normalized.StartsWith("Assets/PuddlesVrcTools/Generated/", StringComparison.OrdinalIgnoreCase)
                || normalized.StartsWith($"{outputFolder}/", StringComparison.OrdinalIgnoreCase)
                || normalized.StartsWith($"{profileFolder}/", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsProtectedAsset(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return true;
            }

            return path == AssetDatabase.GetAssetPath(profile.fxController)
                || path == AssetDatabase.GetAssetPath(profile.expressionParameters)
                || path == AssetDatabase.GetAssetPath(profile.rootMenu);
        }

        private bool IsClipSharedOutsideLayers(AnimationClip clip, IReadOnlyCollection<AnimatorControllerLayer> owningLayers)
        {
            if (clip == null || profile.fxController == null)
            {
                return false;
            }

            HashSet<string> owningLayerNames = new HashSet<string>(owningLayers.Select(layer => layer.name), StringComparer.Ordinal);
            foreach (AnimatorControllerLayer layer in profile.fxController.layers)
            {
                if (owningLayerNames.Contains(layer.name))
                {
                    continue;
                }

                if (CollectLayerClips(layer).Any(layerClip => layerClip == clip))
                {
                    return true;
                }
            }

            return false;
        }

        private void UseSelectedMenuForToggle()
        {
            PuddlesAvatarActionControl control = GetSelectedControl();
            if (control == null || selectedMenu == null)
            {
                return;
            }

            control.destinationMenu = selectedMenu;
            control.destinationPath = selectedPath;
            profile.lastDestinationMenu = selectedMenu;
            profile.lastDestinationPath = selectedPath;
            EditorUtility.SetDirty(profile);
            Repaint();
        }

        private void CreateManagedSubmenu()
        {
            EnsureFolder(GetProfileGenerationFolder(profile));
            EnsureMenuControlList(selectedMenu);
            if (selectedMenu.controls.Count >= MaxControlsPerMenu)
            {
                EditorUtility.DisplayDialog("Action Menu Manager", "The selected menu is full.", "OK");
                return;
            }

            string displayName = TruncateMenuName(newSubmenuName.Trim());
            VRCExpressionsMenu parentMenu = selectedMenu;
            string parentPath = selectedPath;
            string path = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(GetProfileGenerationFolder(profile), $"{SanitizeAssetName(displayName)} Menu.asset").Replace("\\", "/"));
            VRCExpressionsMenu submenu = CreateInstance<VRCExpressionsMenu>();
            EnsureMenuControlList(submenu);
            AssetDatabase.CreateAsset(submenu, path);
            parentMenu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = displayName,
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = submenu
            });

            string submenuPath = $"{parentPath}/{displayName}";
            profile.managedSubmenus.Add(new PuddlesAvatarManagedSubmenu
            {
                id = CreateStableId(),
                displayName = displayName,
                parentMenu = parentMenu,
                menu = submenu,
                path = submenuPath
            });

            selectedMenu = submenu;
            selectedPath = submenuPath;
            renameText = displayName;
            profile.lastDestinationMenu = submenu;
            profile.lastDestinationPath = submenuPath;
            expandedPaths.Add(parentPath);
            expandedPaths.Add(submenuPath);
            RefreshMenuPathCaches();
            EditorUtility.SetDirty(profile);
            EditorUtility.SetDirty(parentMenu);
            EditorUtility.SetDirty(submenu);
            AssetDatabase.SaveAssets();
            Repaint();
        }

        private void RenameManagedSubmenu()
        {
            PuddlesAvatarManagedSubmenu record = profile.managedSubmenus.FirstOrDefault(menu => menu != null && menu.menu == selectedMenu);
            if (record == null || record.parentMenu == null || selectedMenu == null)
            {
                return;
            }

            string displayName = TruncateMenuName(renameText.Trim());
            if (string.IsNullOrWhiteSpace(displayName))
            {
                return;
            }

            EnsureMenuControlList(record.parentMenu);
            VRCExpressionsMenu.Control parentControl = record.parentMenu.controls.FirstOrDefault(control =>
                control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                && control.subMenu == selectedMenu);
            if (parentControl != null)
            {
                parentControl.name = displayName;
                EditorUtility.SetDirty(record.parentMenu);
            }

            record.displayName = displayName;
            RefreshMenuPathCaches();
            selectedPath = FindMenuPath(profile.rootMenu, selectedMenu, "Root", new HashSet<VRCExpressionsMenu>());
            if (string.IsNullOrWhiteSpace(selectedPath))
            {
                selectedPath = "Root";
            }

            expandedPaths.Add(GetParentPath(selectedPath));
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            Repaint();
        }

        private string GetEditableMenuName(VRCExpressionsMenu menu, string path)
        {
            PuddlesAvatarManagedSubmenu record = profile.managedSubmenus.FirstOrDefault(managed => managed != null && managed.menu == menu);
            if (record != null && !string.IsNullOrWhiteSpace(record.displayName))
            {
                return record.displayName;
            }

            return string.IsNullOrWhiteSpace(path) ? "Root" : path.Split('/').Last();
        }

        private void RefreshMenuPathCaches()
        {
            foreach (PuddlesAvatarManagedSubmenu managed in profile.managedSubmenus)
            {
                if (managed == null || managed.menu == null)
                {
                    continue;
                }

                string path = FindMenuPath(profile.rootMenu, managed.menu, "Root", new HashSet<VRCExpressionsMenu>());
                if (!string.IsNullOrWhiteSpace(path))
                {
                    managed.path = path;
                }
            }

            foreach (PuddlesAvatarActionControl control in profile.controls)
            {
                if (control == null || control.destinationMenu == null)
                {
                    continue;
                }

                string path = FindMenuPath(profile.rootMenu, control.destinationMenu, "Root", new HashSet<VRCExpressionsMenu>());
                if (!string.IsNullOrWhiteSpace(path))
                {
                    control.destinationPath = path;
                }
            }

            if (profile.lastDestinationMenu != null)
            {
                string path = FindMenuPath(profile.rootMenu, profile.lastDestinationMenu, "Root", new HashSet<VRCExpressionsMenu>());
                if (!string.IsNullOrWhiteSpace(path))
                {
                    profile.lastDestinationPath = path;
                }
            }
        }

        private void DeleteManagedSubmenu()
        {
            PuddlesAvatarManagedSubmenu record = profile.managedSubmenus.FirstOrDefault(menu => menu != null && menu.menu == selectedMenu);
            if (record == null)
            {
                return;
            }

            HashSet<VRCExpressionsMenu> subtree = CollectMenuSubtree(selectedMenu, new HashSet<VRCExpressionsMenu>());
            HashSet<string> ownedParameters = new HashSet<string>(
                profile.controls.SelectMany(control => BuildParameterNames(profile, control)),
                StringComparer.OrdinalIgnoreCase);
            if (HasNonOwnedControls(selectedMenu, ownedParameters, subtree, new HashSet<VRCExpressionsMenu>()))
            {
                EditorUtility.DisplayDialog("Action Menu Manager", "This managed submenu contains manual or non-Action-Builder controls. Move those first, then delete it.", "OK");
                return;
            }

            List<PuddlesAvatarActionControl> controlsToDelete = profile.controls
                .Where(control => control.destinationMenu != null && subtree.Contains(control.destinationMenu))
                .ToList();

            string message = $"Delete managed submenu '{record.displayName}' and {controlsToDelete.Count} Action Builder toggle(s)?";
            if (!EditorUtility.DisplayDialog("Delete Managed Submenu", message, "Delete", "Cancel"))
            {
                return;
            }

            foreach (PuddlesAvatarActionControl control in controlsToDelete)
            {
                DeleteControlArtifacts(profile, control);
                profile.controls.Remove(control);
            }

            RemoveSubmenuEntry(record.parentMenu, selectedMenu);
            foreach (PuddlesAvatarManagedSubmenu managed in profile.managedSubmenus.Where(menu => menu != null && menu.menu != null && subtree.Contains(menu.menu)).ToList())
            {
                string assetPath = AssetDatabase.GetAssetPath(managed.menu);
                if (!string.IsNullOrWhiteSpace(assetPath))
                {
                    AssetDatabase.DeleteAsset(assetPath);
                }

                profile.managedSubmenus.Remove(managed);
            }

            if (profile.lastDestinationMenu != null && subtree.Contains(profile.lastDestinationMenu))
            {
                profile.lastDestinationMenu = profile.rootMenu;
                profile.lastDestinationPath = "Root";
            }

            selectedMenu = profile.rootMenu;
            selectedPath = "Root";
            renameText = "Root";
            RefreshMenuPathCaches();
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private PuddlesAvatarActionControl GetSelectedControl()
        {
            return profile.controls.FirstOrDefault(control => control.id == selectedControlId);
        }

        private bool IsManaged(VRCExpressionsMenu menu)
        {
            return menu != null && profile.managedSubmenus.Any(record => record != null && record.menu == menu);
        }

        private static string BuildMenuFlags(VRCExpressionsMenu menu, bool managed)
        {
            EnsureMenuControlList(menu);
            List<string> flags = new List<string> { managed ? "Managed" : "Existing" };
            if (menu != null && menu.controls.Count >= MaxControlsPerMenu)
            {
                flags.Add("Full");
            }

            return $"[{string.Join(", ", flags)}]";
        }

        private static string GetParentPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !path.Contains("/"))
            {
                return "Root";
            }

            return path.Substring(0, path.LastIndexOf("/", StringComparison.Ordinal));
        }

        private void EnsureLists()
        {
            if (profile.controls == null)
            {
                profile.controls = new List<PuddlesAvatarActionControl>();
            }

            if (profile.managedSubmenus == null)
            {
                profile.managedSubmenus = new List<PuddlesAvatarManagedSubmenu>();
            }
        }

        internal static HashSet<VRCExpressionsMenu> CollectMenuSubtree(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return visited;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    CollectMenuSubtree(control.subMenu, visited);
                }
            }

            return visited;
        }

        internal static string FindMenuPath(VRCExpressionsMenu current, VRCExpressionsMenu target, string path, HashSet<VRCExpressionsMenu> visited)
        {
            if (current == null || target == null || !visited.Add(current))
            {
                return string.Empty;
            }

            if (current == target)
            {
                return path;
            }

            EnsureMenuControlList(current);
            foreach (VRCExpressionsMenu.Control control in current.controls)
            {
                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null)
                {
                    continue;
                }

                string childPath = $"{path}/{control.name}";
                string foundPath = FindMenuPath(control.subMenu, target, childPath, visited);
                if (!string.IsNullOrWhiteSpace(foundPath))
                {
                    return foundPath;
                }
            }

            return string.Empty;
        }

        internal static VRCExpressionsMenu FindParentMenu(VRCExpressionsMenu current, VRCExpressionsMenu target, HashSet<VRCExpressionsMenu> visited)
        {
            if (current == null || target == null || !visited.Add(current))
            {
                return null;
            }

            EnsureMenuControlList(current);
            foreach (VRCExpressionsMenu.Control control in current.controls)
            {
                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null)
                {
                    continue;
                }

                if (control.subMenu == target)
                {
                    return current;
                }

                VRCExpressionsMenu parent = FindParentMenu(control.subMenu, target, visited);
                if (parent != null)
                {
                    return parent;
                }
            }

            return null;
        }

        private bool HasNonOwnedControls(VRCExpressionsMenu menu, HashSet<string> ownedParameters, HashSet<VRCExpressionsMenu> subtree, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return false;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    if (control.subMenu != null && !IsManaged(control.subMenu) && control.subMenu != selectedMenu)
                    {
                        return true;
                    }

                    if (HasNonOwnedControls(control.subMenu, ownedParameters, subtree, visited))
                    {
                        return true;
                    }

                    continue;
                }

                string parameterName = GetMenuControlParameterName(control);
                if (string.IsNullOrWhiteSpace(parameterName) || !ownedParameters.Contains(parameterName))
                {
                    return true;
                }
            }

            return false;
        }

        internal static void DeleteControlArtifacts(PuddlesAvatarActionProfile profile, PuddlesAvatarActionControl control)
        {
            List<string> parameterNames = BuildParameterNames(profile, control).ToList();
            if (profile.fxController != null)
            {
                for (int i = profile.fxController.layers.Length - 1; i >= 0; i--)
                {
                    string layerName = profile.fxController.layers[i].name;
                    if (IsGeneratedLayerForControl(profile, layerName, control))
                    {
                        profile.fxController.RemoveLayer(i);
                    }
                }

                foreach (string parameterName in parameterNames)
                {
                    AnimatorControllerParameter parameter = profile.fxController.parameters.FirstOrDefault(existing => existing.name == parameterName);
                    if (parameter != null)
                    {
                        profile.fxController.RemoveParameter(parameter);
                    }
                }

                EditorUtility.SetDirty(profile.fxController);
            }

            if (profile.expressionParameters != null && profile.expressionParameters.parameters != null)
            {
                profile.expressionParameters.parameters = profile.expressionParameters.parameters
                    .Where(parameter => parameter == null || !parameterNames.Contains(parameter.name, StringComparer.OrdinalIgnoreCase))
                    .ToArray();
                EditorUtility.SetDirty(profile.expressionParameters);
            }

            if (profile.rootMenu != null)
            {
                foreach (string parameterName in parameterNames)
                {
                    RemoveMenuControlByParameter(profile.rootMenu, parameterName);
                }
            }

            string controlFolder = Path.Combine(GetProfileGenerationFolder(profile), control.id).Replace("\\", "/");
            if (AssetDatabase.IsValidFolder(controlFolder))
            {
                AssetDatabase.DeleteAsset(controlFolder);
            }
        }

        internal static bool RemoveSubmenuEntry(VRCExpressionsMenu parent, VRCExpressionsMenu submenu)
        {
            if (parent == null)
            {
                return false;
            }

            EnsureMenuControlList(parent);
            int removed = parent.controls.RemoveAll(control =>
                control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                && control.subMenu == submenu);
            if (removed > 0)
            {
                EditorUtility.SetDirty(parent);
                return true;
            }

            return false;
        }

        private static string BuildParameterName(PuddlesAvatarActionProfile profile, PuddlesAvatarActionControl control)
        {
            string prefix = string.IsNullOrWhiteSpace(profile.parameterPrefix) ? DefaultParameterPrefix : profile.parameterPrefix.Trim().Trim('/');
            return AvatarActionBuilderWindow.BuildReadableParameterName(prefix, control);
        }

        private static string BuildLegacyParameterName(PuddlesAvatarActionProfile profile, PuddlesAvatarActionControl control)
        {
            string prefix = string.IsNullOrWhiteSpace(profile.parameterPrefix) ? DefaultParameterPrefix : profile.parameterPrefix.Trim().Trim('/');
            return $"{prefix}/{control.id}";
        }

        internal static IEnumerable<string> BuildParameterNames(PuddlesAvatarActionProfile profile, PuddlesAvatarActionControl control)
        {
            if (profile == null || control == null)
            {
                yield break;
            }

            yield return BuildParameterName(profile, control);
            yield return BuildLegacyParameterName(profile, control);

            string suffix = $"_{control.id}";
            if (profile.expressionParameters != null && profile.expressionParameters.parameters != null)
            {
                foreach (VRCExpressionParameters.Parameter parameter in profile.expressionParameters.parameters)
                {
                    if (parameter != null && !string.IsNullOrWhiteSpace(parameter.name) && parameter.name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
                    {
                        yield return parameter.name;
                    }
                }
            }

            if (profile.fxController != null)
            {
                foreach (AnimatorControllerParameter parameter in profile.fxController.parameters)
                {
                    if (parameter != null && !string.IsNullOrWhiteSpace(parameter.name) && parameter.name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
                    {
                        yield return parameter.name;
                    }
                }
            }
        }

        private static string BuildLayerName(PuddlesAvatarActionProfile profile, PuddlesAvatarActionControl control)
        {
            string label = SanitizeLayerLabel(control.displayName);
            return $"Puddles Action {label} [{control.id}]";
        }

        private static string BuildLegacyLayerName(PuddlesAvatarActionControl control)
        {
            return $"Puddles Action {control.id}";
        }

        private static bool IsGeneratedLayerForControl(PuddlesAvatarActionProfile profile, string layerName, PuddlesAvatarActionControl control)
        {
            if (string.IsNullOrWhiteSpace(layerName) || control == null)
            {
                return false;
            }

            return layerName == BuildLayerName(profile, control)
                || layerName == BuildLegacyLayerName(control)
                || (layerName.StartsWith("Puddles Action ", StringComparison.OrdinalIgnoreCase)
                    && layerName.EndsWith($"[{control.id}]", StringComparison.OrdinalIgnoreCase));
        }

        private static string GetProfileGenerationFolder(PuddlesAvatarActionProfile profile)
        {
            string outputFolder = string.IsNullOrWhiteSpace(profile.outputFolder) ? DefaultOutputFolder : profile.outputFolder.Trim();
            return Path.Combine(outputFolder, SanitizeAssetName(profile.name)).Replace("\\", "/");
        }

        private static string SanitizeAssetName(string value)
        {
            string cleaned = string.Join("_", (value ?? "Asset").Split(Path.GetInvalidFileNameChars()));
            return string.IsNullOrWhiteSpace(cleaned) ? "Asset" : cleaned;
        }

        private static string SanitizeLayerLabel(string value)
        {
            string cleaned = string.Join(" ", (value ?? "Toggle").Split(Path.GetInvalidFileNameChars())).Trim();
            if (string.IsNullOrWhiteSpace(cleaned))
            {
                cleaned = "Toggle";
            }

            return cleaned.Length <= 36 ? cleaned : cleaned.Substring(0, 36);
        }

        private static string TruncateMenuName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "Menu";
            }

            return value.Length <= 32 ? value : value.Substring(0, 32);
        }

        private static void EnsureFolder(string folder)
        {
            string normalized = folder.Replace("\\", "/").Trim('/');
            if (AssetDatabase.IsValidFolder(normalized))
            {
                return;
            }

            string[] parts = normalized.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = $"{current}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                current = next;
            }
        }

        private static void EnsureMenuControlList(VRCExpressionsMenu menu)
        {
            if (menu != null && menu.controls == null)
            {
                menu.controls = new List<VRCExpressionsMenu.Control>();
            }
        }

        private static bool RemoveMenuControlByParameter(VRCExpressionsMenu menu, string parameterName)
        {
            return RemoveMenuControlByParameter(menu, parameterName, new HashSet<VRCExpressionsMenu>());
        }

        private static bool RemoveMenuControlByParameter(VRCExpressionsMenu menu, string parameterName, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return false;
            }

            bool removed = false;
            EnsureMenuControlList(menu);
            for (int i = menu.controls.Count - 1; i >= 0; i--)
            {
                VRCExpressionsMenu.Control control = menu.controls[i];
                if (MenuControlUsesParameter(control, parameterName))
                {
                    menu.controls.RemoveAt(i);
                    removed = true;
                    continue;
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                    && RemoveMenuControlByParameter(control.subMenu, parameterName, visited))
                {
                    removed = true;
                }
            }

            if (removed)
            {
                EditorUtility.SetDirty(menu);
            }

            return removed;
        }

        private static string CreateStableId()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 12);
        }

        private sealed class MenuCleanupItem
        {
            public string Name;
            public VRCExpressionsMenu.Control.ControlType Type;
            public string TypeLabel;
            public string ParameterName;
            public string Confidence;
            public string Location;
            public string RowLabel;
            public string BlockReason;
            public VRCExpressionsMenu ParentMenu;
            public VRCExpressionsMenu.Control MenuControl;
            public int ControlIndex;
            public VRCExpressionsMenu Submenu;
            public PuddlesAvatarActionControl ActionBuilderControl;
            public bool IsSubmenu;
            public bool IsActionBuilderOwned;
            public bool HasExpressionParameter;
            public bool HasAnimatorParameter;
            public bool CanRemoveFromAvatar;
            public List<AnimatorControllerLayer> MatchedLayers = new List<AnimatorControllerLayer>();
            public List<AnimationClip> Clips = new List<AnimationClip>();
        }

    }

#if PUDDLES_EXPERIMENTAL_TOOLS
    public sealed class AvatarActionControlInspectorWindow : EditorWindow
    {
        private const string DefaultParameterPrefix = "Puddles/Action";
        private const string DefaultInspectorOutputFolder = "Assets/PuddlesVrcTools/Generated/AvatarActions";
        private const float MinControlListWidth = 260f;
        private const float DefaultControlListWidth = 390f;
        private const float MinDetailWidth = 360f;

        private PuddlesAvatarActionProfile profile;
        private VRCExpressionsMenu rootMenu;
        private AnimatorController fxController;
        private VRCExpressionParameters expressionParameters;
        private Vector2 listScroll;
        private Vector2 detailScroll;
        private float controlListWidth = DefaultControlListWidth;
        private bool resizingControlList;
        private bool showConflictsOnly;
        private int selectedIndex = -1;
        private readonly List<InspectedControl> controls = new List<InspectedControl>();
        private readonly Dictionary<string, int> controlIndexByPath = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> expandedInspectorPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        [MenuItem("Tools/Puddles/Avatar Control Inspector")]
        public static void OpenStandalone()
        {
            GetWindow<AvatarActionControlInspectorWindow>("Control Inspector");
        }

        public static void Open(PuddlesAvatarActionProfile profile)
        {
            AvatarActionControlInspectorWindow window = GetWindow<AvatarActionControlInspectorWindow>("Control Inspector");
            window.profile = profile;
            window.UseProfileAssets();
            window.Scan();
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Avatar Control Inspector", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("View existing/manual avatar controls without changing them. Use this to inspect or import old toggles and expressions into the Action Builder profile. The inspector traces menu entries to expression parameters, FX parameters, FX layers, clips, and animated properties.", MessageType.Info);

            DrawHeader();
            controlListWidth = Mathf.Clamp(controlListWidth, MinControlListWidth, Mathf.Max(MinControlListWidth, position.width - MinDetailWidth));
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawControlList();
                DrawControlListSplitter();
                DrawDetails();
            }
        }

        private void DrawHeader()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.BeginChangeCheck();
                profile = (PuddlesAvatarActionProfile)EditorGUILayout.ObjectField("Action Profile", profile, typeof(PuddlesAvatarActionProfile), false);
                using (new EditorGUI.DisabledScope(profile == null))
                {
                    if (GUILayout.Button("Use Assets From Profile"))
                    {
                        UseProfileAssets();
                    }
                }

                rootMenu = (VRCExpressionsMenu)EditorGUILayout.ObjectField("Root Menu", rootMenu, typeof(VRCExpressionsMenu), false);
                expressionParameters = (VRCExpressionParameters)EditorGUILayout.ObjectField("Expression Parameters", expressionParameters, typeof(VRCExpressionParameters), false);
                fxController = (AnimatorController)EditorGUILayout.ObjectField("FX Controller", fxController, typeof(AnimatorController), false);
                if (EditorGUI.EndChangeCheck())
                {
                    selectedIndex = -1;
                }

                using (new EditorGUI.DisabledScope(rootMenu == null))
                {
                    if (GUILayout.Button("Scan Controls", GUILayout.Height(24)))
                    {
                        Scan();
                    }
                }

                using (new EditorGUI.DisabledScope(profile == null || controls.Count == 0))
                {
                    if (GUILayout.Button("Auto Import Readable Controls", GUILayout.Height(26)))
                    {
                        AutoImportReadableControls();
                    }
                }
            }
        }

        private void DrawControlList()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(controlListWidth)))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField($"Controls ({controls.Count})", EditorStyles.boldLabel);
                    using (new EditorGUI.DisabledScope(rootMenu == null))
                    {
                        if (GUILayout.Button("Refresh", GUILayout.Width(70)))
                        {
                            Scan();
                        }
                    }
                }

                DrawControlListModeSwitch();
                listScroll = EditorGUILayout.BeginScrollView(listScroll, EditorStyles.helpBox);
                if (controls.Count == 0)
                {
                    EditorGUILayout.LabelField("Click Scan Controls to inspect the root expression menu.", EditorStyles.wordWrappedMiniLabel);
                }
                else
                {
                    DrawInspectorMenuTree();
                }

                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawControlListModeSwitch()
        {
            int conflictCount = controls.Count(control => control.Conflicts.Count > 0);
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                bool showAll = GUILayout.Toggle(!showConflictsOnly, "All", EditorStyles.toolbarButton);
                bool showConflicts = GUILayout.Toggle(showConflictsOnly, $"Conflicts ({conflictCount})", EditorStyles.toolbarButton);
                if (showAll && showConflictsOnly)
                {
                    showConflictsOnly = false;
                }
                else if (showConflicts && !showConflictsOnly)
                {
                    showConflictsOnly = true;
                    ExpandConflictInspectorMenus(rootMenu, "Root", new HashSet<VRCExpressionsMenu>());
                    SelectFirstVisibleConflict();
                }
            }
        }

        private void DrawControlListSplitter()
        {
            Rect splitterRect = GUILayoutUtility.GetRect(5f, 5f, GUILayout.ExpandHeight(true));
            EditorGUI.DrawRect(new Rect(splitterRect.x + 2f, splitterRect.y, 1f, splitterRect.height), new Color(0.28f, 0.28f, 0.28f, 1f));
            EditorGUIUtility.AddCursorRect(splitterRect, MouseCursor.ResizeHorizontal);

            Event current = Event.current;
            if (current.type == EventType.MouseDown && splitterRect.Contains(current.mousePosition))
            {
                resizingControlList = true;
                current.Use();
            }

            if (resizingControlList)
            {
                controlListWidth = Mathf.Clamp(current.mousePosition.x, MinControlListWidth, Mathf.Max(MinControlListWidth, position.width - MinDetailWidth));
                Repaint();

                if (current.type == EventType.MouseDrag)
                {
                    current.Use();
                }

                if (current.type == EventType.MouseUp || current.rawType == EventType.MouseUp)
                {
                    resizingControlList = false;
                    current.Use();
                }
            }
        }

        private void DrawInspectorMenuTree()
        {
            expandedInspectorPaths.Add("Root");
            if (showConflictsOnly && controls.All(control => control.Conflicts.Count == 0))
            {
                EditorGUILayout.LabelField("No conflicts found in the current scan.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Expand All"))
                {
                    if (showConflictsOnly)
                    {
                        ExpandConflictInspectorMenus(rootMenu, "Root", new HashSet<VRCExpressionsMenu>());
                    }
                    else
                    {
                        ExpandAllInspectorMenus(rootMenu, "Root", new HashSet<VRCExpressionsMenu>());
                    }
                }

                if (GUILayout.Button("Collapse All"))
                {
                    expandedInspectorPaths.Clear();
                    expandedInspectorPaths.Add("Root");
                }
            }

            DrawInspectorMenuHeader("Root", rootMenu, 0);
            if (expandedInspectorPaths.Contains("Root"))
            {
                DrawInspectorMenuContents(rootMenu, "Root", 1, new HashSet<VRCExpressionsMenu>());
            }
        }

        private void DrawInspectorMenuContents(VRCExpressionsMenu menu, string path, int depth, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                string controlName = string.IsNullOrWhiteSpace(control.name) ? "(Unnamed)" : control.name;
                string controlPath = $"{path}/{controlName}";
                bool isSubmenu = control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null;
                if (showConflictsOnly && !ControlOrSubtreeHasConflict(controlPath, control, new HashSet<VRCExpressionsMenu>()))
                {
                    continue;
                }

                bool expanded = expandedInspectorPaths.Contains(controlPath);
                int itemIndex = controlIndexByPath.TryGetValue(controlPath, out int mappedIndex) ? mappedIndex : -1;
                InspectedControl item = itemIndex >= 0 && itemIndex < controls.Count ? controls[itemIndex] : null;

                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Space(depth * 16);
                    using (new EditorGUI.DisabledScope(!isSubmenu))
                    {
                        if (GUILayout.Button(isSubmenu ? (expanded ? "v" : ">") : " ", GUILayout.Width(24)))
                        {
                            if (expanded)
                            {
                                expandedInspectorPaths.Remove(controlPath);
                            }
                            else
                            {
                                expandedInspectorPaths.Add(controlPath);
                            }
                        }
                    }

                    GUIStyle style = itemIndex == selectedIndex ? EditorStyles.toolbarButton : GUI.skin.button;
                    if (GUILayout.Button(item != null ? BuildTreeRowLabel(item) : controlName, style))
                    {
                        selectedIndex = itemIndex;
                    }
                }

                if (isSubmenu && expanded)
                {
                    DrawInspectorMenuContents(control.subMenu, controlPath, depth + 1, visited);
                }
            }
        }

        private void DrawInspectorMenuHeader(string path, VRCExpressionsMenu menu, int depth)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(depth * 16);
                bool expanded = expandedInspectorPaths.Contains(path);
                if (GUILayout.Button(expanded ? "v" : ">", GUILayout.Width(24)))
                {
                    if (expanded)
                    {
                        expandedInspectorPaths.Remove(path);
                    }
                    else
                    {
                        expandedInspectorPaths.Add(path);
                    }
                }

                EditorGUILayout.LabelField($"{path} ({(menu != null && menu.controls != null ? menu.controls.Count : 0)} controls)", EditorStyles.boldLabel);
            }
        }

        private void DrawDetails()
        {
            using (new EditorGUILayout.VerticalScope())
            {
                detailScroll = EditorGUILayout.BeginScrollView(detailScroll);
                InspectedControl item = selectedIndex >= 0 && selectedIndex < controls.Count ? controls[selectedIndex] : null;
                if (item == null)
                {
                    EditorGUILayout.HelpBox("Select a control to see traced details.", MessageType.Info);
                    EditorGUILayout.EndScrollView();
                    return;
                }

                EditorGUILayout.LabelField("Selected Control", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("Menu Label", item.Name);
                EditorGUILayout.LabelField("Type", item.TypeLabel);
                if (!string.IsNullOrWhiteSpace(item.RadialModeLabel))
                {
                    EditorGUILayout.LabelField("Radial Mode", item.RadialModeLabel);
                }

                EditorGUILayout.LabelField("Menu Path", item.MenuPath);
                EditorGUILayout.ObjectField("Parent Menu", item.ParentMenu, typeof(VRCExpressionsMenu), false);
                if (item.Submenu != null)
                {
                    EditorGUILayout.ObjectField("Submenu Asset", item.Submenu, typeof(VRCExpressionsMenu), false);
                    EditorGUILayout.LabelField("Child Controls", item.Submenu.controls != null ? item.Submenu.controls.Count.ToString() : "0");
                }

                EditorGUILayout.LabelField("Confidence", item.Confidence);
                DrawStringList("Menu Parameter(s)", item.ParameterNames, "No menu parameter.");
                DrawExpressionParameters(item);
                DrawAnimatorParameters(item);
                DrawMatchedLayers(item);
                DrawConflicts(item);
                DrawImportPreview(item);
                DrawClips(item);
                DrawAnimatedProperties(item);
                EditorGUILayout.EndScrollView();
            }
        }

        private static void DrawStringList(string label, List<string> values, string emptyText)
        {
            EditorGUILayout.LabelField(label, EditorStyles.boldLabel);
            if (values == null || values.Count == 0)
            {
                EditorGUILayout.LabelField(emptyText, EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (string value in values)
            {
                EditorGUILayout.LabelField(value, EditorStyles.wordWrappedMiniLabel);
            }
        }

        private static void DrawExpressionParameters(InspectedControl item)
        {
            EditorGUILayout.LabelField("Expression Parameter(s)", EditorStyles.boldLabel);
            if (item.ExpressionParameters.Count == 0)
            {
                EditorGUILayout.LabelField("Not found.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (VRCExpressionParameters.Parameter parameter in item.ExpressionParameters)
            {
                EditorGUILayout.LabelField($"{parameter.name} - {parameter.valueType}, default {parameter.defaultValue}, saved {parameter.saved}, synced {parameter.networkSynced}", EditorStyles.wordWrappedMiniLabel);
            }
        }

        private static void DrawAnimatorParameters(InspectedControl item)
        {
            EditorGUILayout.LabelField("FX Parameter(s)", EditorStyles.boldLabel);
            if (item.AnimatorParameters.Count == 0)
            {
                EditorGUILayout.LabelField("Not found.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (AnimatorControllerParameter parameter in item.AnimatorParameters)
            {
                EditorGUILayout.LabelField($"{parameter.name} - {parameter.type}", EditorStyles.wordWrappedMiniLabel);
            }
        }

        private static void DrawMatchedLayers(InspectedControl item)
        {
            EditorGUILayout.LabelField("Matched FX Layer(s)", EditorStyles.boldLabel);
            if (item.MatchedLayers.Count == 0)
            {
                EditorGUILayout.LabelField("No FX layers found using the menu parameter.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (AnimatorControllerLayer layer in item.MatchedLayers)
            {
                string reason = item.LayerMatchReasons.TryGetValue(layer, out string matchReason) ? $" - {matchReason}" : string.Empty;
                EditorGUILayout.LabelField($"{layer.name}{reason}", EditorStyles.wordWrappedMiniLabel);
            }
        }

        private static string GetRadialModeLabel(VRCExpressionsMenu.Control control, Dictionary<AnimatorControllerLayer, string> layerMatchReasons)
        {
            if (control == null || control.type != VRCExpressionsMenu.Control.ControlType.RadialPuppet)
            {
                return string.Empty;
            }

            if (layerMatchReasons != null && layerMatchReasons.Values.Any(reason => string.Equals(reason, "state parameter", StringComparison.OrdinalIgnoreCase)))
            {
                return "Time Parameter";
            }

            if (layerMatchReasons != null && layerMatchReasons.Values.Any(reason => string.Equals(reason, "blend tree", StringComparison.OrdinalIgnoreCase)))
            {
                return "Blend Tree";
            }

            return layerMatchReasons != null && layerMatchReasons.Count > 0 ? "Transition/Other" : "Untraced";
        }

        private static void DrawConflicts(InspectedControl item)
        {
            EditorGUILayout.LabelField("Conflicts", EditorStyles.boldLabel);
            if (item.Conflicts.Count == 0)
            {
                EditorGUILayout.LabelField("No shared animated bindings found for this control.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (BindingConflictInfo conflict in item.Conflicts)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField(conflict.Binding.Label, EditorStyles.wordWrappedMiniLabel);
                    foreach (InspectedControl other in conflict.OtherControls)
                    {
                        string parameter = other.ParameterNames.Count == 0 ? "no parameter" : string.Join(", ", other.ParameterNames);
                        EditorGUILayout.LabelField($"{other.MenuPath} ({other.TypeLabel}) - {parameter}", EditorStyles.wordWrappedMiniLabel);
                        foreach (AnimatorControllerLayer layer in other.MatchedLayers)
                        {
                            string reason = other.LayerMatchReasons.TryGetValue(layer, out string matchReason) ? $" - {matchReason}" : string.Empty;
                            EditorGUILayout.LabelField($"  FX: {layer.name}{reason}", EditorStyles.wordWrappedMiniLabel);
                        }
                    }
                }
            }
        }

        private void DrawImportPreview(InspectedControl item)
        {
            ImportPreview preview = BuildImportPreview(item);
            EditorGUILayout.LabelField("Import Preview", EditorStyles.boldLabel);
            if (preview == null)
            {
                EditorGUILayout.LabelField("No import preview available.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            if (!preview.Supported)
            {
                EditorGUILayout.HelpBox(preview.BlockReason, MessageType.Info);
            }

            foreach (string warning in preview.Warnings)
            {
                EditorGUILayout.LabelField(warning, EditorStyles.wordWrappedMiniLabel);
            }

            if (preview.Actions.Count > 0)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    foreach (ImportedActionPreview action in preview.Actions)
                    {
                        EditorGUILayout.LabelField(action.Summary, EditorStyles.wordWrappedMiniLabel);
                    }
                }
            }

            if (preview.UnsupportedBindings.Count > 0)
            {
                EditorGUILayout.LabelField("Unsupported Binding(s)", EditorStyles.boldLabel);
                foreach (string unsupported in preview.UnsupportedBindings)
                {
                    EditorGUILayout.LabelField(unsupported, EditorStyles.wordWrappedMiniLabel);
                }
            }

            using (new EditorGUI.DisabledScope(!preview.CanImport))
            {
                if (GUILayout.Button("Import To Action Builder Profile", GUILayout.Height(26)))
                {
                    PuddlesAvatarActionControl imported = ImportPreviewToProfile(preview);
                    if (imported != null)
                    {
                        AssetDatabase.SaveAssets();
                        AvatarActionBuilderWindow.OpenWithProfile(profile, imported.id);
                        EditorUtility.DisplayDialog("Import To Action Builder", $"Imported '{preview.Source.Name}' as an editable Action Builder control. The original control was not changed.", "OK");
                    }
                }
            }
        }

        private void AutoImportReadableControls()
        {
            if (profile == null)
            {
                EditorUtility.DisplayDialog("Auto Import Readable Controls", "Assign an Action Builder profile before importing.", "OK");
                return;
            }

            if (controls.Count == 0)
            {
                Scan();
            }

            List<ImportPreview> importable = controls
                .Where(item => item != null && !string.Equals(item.Confidence, "Action Builder", StringComparison.OrdinalIgnoreCase))
                .Select(BuildImportPreview)
                .Where(preview => preview != null && preview.CanImport)
                .Where(preview => !ProfileAlreadyHasImportedControl(preview))
                .ToList();

            int actionBuilderSkipped = controls.Count(item => item != null && string.Equals(item.Confidence, "Action Builder", StringComparison.OrdinalIgnoreCase));
            int duplicateSkipped = controls
                .Where(item => item != null && !string.Equals(item.Confidence, "Action Builder", StringComparison.OrdinalIgnoreCase))
                .Select(BuildImportPreview)
                .Count(preview => preview != null && preview.CanImport && ProfileAlreadyHasImportedControl(preview));
            int unreadableSkipped = Mathf.Max(0, controls.Count - importable.Count - actionBuilderSkipped - duplicateSkipped);

            if (importable.Count == 0)
            {
                EditorUtility.DisplayDialog(
                    "Auto Import Readable Controls",
                    $"No readable old controls were available to import.\n\nSkipped Action Builder controls: {actionBuilderSkipped}\nSkipped duplicates already in this profile: {duplicateSkipped}\nUnreadable or unsupported controls: {unreadableSkipped}",
                    "OK");
                return;
            }

            int choice = EditorUtility.DisplayDialogComplex(
                "Auto Import Readable Controls",
                "Before running this, copy or duplicate your avatar/component so you can roll back if anything looks wrong.\n\n"
                + $"This will import {importable.Count} readable old control(s) into the Action Builder profile.\n"
                + "Import only will not delete old controls and will not generate new avatar assets yet.\n"
                + "Import, generate, then delete old will generate the new Action Builder controls first. Old controls are removed only if generation succeeds. Project assets and clips are not deleted automatically.\n\n"
                + $"Skipped Action Builder controls: {actionBuilderSkipped}\n"
                + $"Skipped duplicates already in this profile: {duplicateSkipped}\n"
                + $"Unreadable or unsupported controls: {unreadableSkipped}",
                "Import Only",
                "Cancel",
                "Import, Generate, Then Delete Old");

            if (choice == 1)
            {
                return;
            }

            bool replaceOldControls = choice == 2;
            if (replaceOldControls && !EditorUtility.DisplayDialog(
                "Generate Replacements And Delete Old",
                "Last safety check: this will generate replacement Action Builder controls, then remove the old/manual controls only if generation succeeds.\n\nMake sure you copied or duplicated the avatar/component first.",
                "I Made A Copy, Replace",
                "Cancel"))
            {
                return;
            }

            List<PuddlesAvatarActionControl> importedControls = new List<PuddlesAvatarActionControl>();
            List<InspectedControl> sourcesToReplace = new List<InspectedControl>();
            foreach (ImportPreview preview in importable)
            {
                PuddlesAvatarActionControl imported = ImportPreviewToProfile(preview);
                if (imported != null)
                {
                    importedControls.Add(imported);
                    if (replaceOldControls)
                    {
                        sourcesToReplace.Add(preview.Source);
                    }
                }
            }

            int removedCount = 0;
            bool generatedSuccessfully = true;
            if (replaceOldControls)
            {
                generatedSuccessfully = AvatarActionBuilderWindow.GenerateControlsForProfile(profile, importedControls, false);
                if (!generatedSuccessfully)
                {
                    AssetDatabase.SaveAssets();
                    AvatarActionBuilderWindow.OpenWithProfile(profile, importedControls.Count > 0 ? importedControls[0].id : null);
                    EditorUtility.DisplayDialog(
                        "Replacement Generation Failed",
                        "The readable controls were imported into the Action Builder profile, but generation did not complete successfully.\n\nOld controls were not deleted.",
                        "OK");
                    return;
                }

                foreach (InspectedControl source in sourcesToReplace)
                {
                    if (RemoveImportedSourceFromAvatar(source))
                    {
                        removedCount++;
                    }
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            if (importedControls.Count > 0)
            {
                AvatarActionBuilderWindow.OpenWithProfile(profile, importedControls[0].id);
            }

            if (replaceOldControls)
            {
                Scan();
            }

            EditorUtility.DisplayDialog(
                "Auto Import Readable Controls",
                replaceOldControls
                    ? $"Imported and generated {importedControls.Count} readable control(s), then removed {removedCount} old control(s) from the avatar.\n\nProject assets and clips were not deleted automatically."
                    : $"Imported {importedControls.Count} readable control(s) into the Action Builder profile.\n\nThe original menu items, parameters, FX controller, clips, and generated assets were not changed.",
                "OK");

            if (replaceOldControls)
            {
                PromptDeleteTracedOldProjectAssets(sourcesToReplace);
            }
        }

        private bool RemoveImportedSourceFromAvatar(InspectedControl source)
        {
            if (source == null || source.ParentMenu == null || source.MenuControl == null)
            {
                return false;
            }

            EnsureMenuControlList(source.ParentMenu);
            bool removedMenuControl = source.ParentMenu.controls.Remove(source.MenuControl);
            if (removedMenuControl)
            {
                EditorUtility.SetDirty(source.ParentMenu);
            }

            foreach (string parameterName in source.ParameterNames.Where(name => !string.IsNullOrWhiteSpace(name)).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                RemoveInspectorExpressionParameter(parameterName);
                RemoveInspectorAnimatorParameter(parameterName);
            }

            RemoveInspectorMatchedLayers(source.MatchedLayers);
            return removedMenuControl;
        }

        private void RemoveInspectorExpressionParameter(string parameterName)
        {
            if (expressionParameters == null || expressionParameters.parameters == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return;
            }

            int beforeCount = expressionParameters.parameters.Length;
            expressionParameters.parameters = expressionParameters.parameters
                .Where(parameter => parameter == null || !string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))
                .ToArray();
            if (expressionParameters.parameters.Length != beforeCount)
            {
                EditorUtility.SetDirty(expressionParameters);
            }
        }

        private void RemoveInspectorAnimatorParameter(string parameterName)
        {
            if (fxController == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return;
            }

            AnimatorControllerParameter parameter = fxController.parameters.FirstOrDefault(existing => string.Equals(existing.name, parameterName, StringComparison.OrdinalIgnoreCase));
            if (parameter != null)
            {
                fxController.RemoveParameter(parameter);
                EditorUtility.SetDirty(fxController);
            }
        }

        private void RemoveInspectorMatchedLayers(IEnumerable<AnimatorControllerLayer> matchedLayers)
        {
            if (fxController == null || matchedLayers == null)
            {
                return;
            }

            HashSet<string> layerNames = new HashSet<string>(
                matchedLayers.Where(layer => layer != null).Select(layer => layer.name),
                StringComparer.Ordinal);
            if (layerNames.Count == 0)
            {
                return;
            }

            for (int i = fxController.layers.Length - 1; i >= 0; i--)
            {
                if (layerNames.Contains(fxController.layers[i].name))
                {
                    fxController.RemoveLayer(i);
                }
            }

            EditorUtility.SetDirty(fxController);
        }

        private void PromptDeleteTracedOldProjectAssets(List<InspectedControl> sources)
        {
            List<CleanupAssetCandidate> candidates = BuildBatchOldAssetCandidates(sources);
            if (candidates.Count == 0)
            {
                return;
            }

            if (!EditorUtility.DisplayDialog(
                "Delete Traced Old Project Assets",
                $"Found {candidates.Count} traced old project asset(s), mostly animation clips.\n\nReview them before deleting? Shared/manual-looking assets are unchecked by default.",
                "Review Assets...",
                "Skip"))
            {
                return;
            }

            AvatarActionCleanupDeleteWindow.Open("Old imported controls", candidates, paths =>
            {
                foreach (string path in paths)
                {
                    if (!string.IsNullOrWhiteSpace(path))
                    {
                        AssetDatabase.DeleteAsset(path);
                    }
                }

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            });
        }

        private List<CleanupAssetCandidate> BuildBatchOldAssetCandidates(List<InspectedControl> sources)
        {
            Dictionary<string, CleanupAssetCandidate> candidates = new Dictionary<string, CleanupAssetCandidate>(StringComparer.OrdinalIgnoreCase);
            if (sources == null)
            {
                return candidates.Values.ToList();
            }

            foreach (InspectedControl source in sources)
            {
                if (source == null)
                {
                    continue;
                }

                foreach (AnimationClip clip in source.Clips.Where(clip => clip != null))
                {
                    string path = AssetDatabase.GetAssetPath(clip);
                    if (string.IsNullOrWhiteSpace(path) || IsInspectorProtectedAsset(path) || candidates.ContainsKey(path))
                    {
                        continue;
                    }

                    bool shared = IsClipReferencedByRemainingLayer(clip);
                    bool generatedLooking = IsInspectorGeneratedPath(path);
                    candidates[path] = new CleanupAssetCandidate
                    {
                        Path = path,
                        Kind = "Old Animation Clip",
                        DefaultSelected = generatedLooking && !shared,
                        Selected = generatedLooking && !shared,
                        Shared = shared
                    };
                }
            }

            return candidates.Values
                .OrderByDescending(candidate => candidate.DefaultSelected)
                .ThenBy(candidate => candidate.Path, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private bool IsClipReferencedByRemainingLayer(AnimationClip clip)
        {
            if (clip == null || fxController == null)
            {
                return false;
            }

            return fxController.layers.Any(layer => CollectLayerClips(layer).Any(layerClip => layerClip == clip));
        }

        private bool IsInspectorGeneratedPath(string path)
        {
            string normalized = (path ?? string.Empty).Replace("\\", "/");
            string outputFolder = profile == null || string.IsNullOrWhiteSpace(profile.outputFolder)
                ? DefaultInspectorOutputFolder
                : profile.outputFolder.Replace("\\", "/").TrimEnd('/');
            string profileFolder = GetInspectorProfileGenerationFolder().Replace("\\", "/").TrimEnd('/');
            return normalized.StartsWith("Assets/PuddlesVrcTools/Generated/", StringComparison.OrdinalIgnoreCase)
                || normalized.StartsWith($"{outputFolder}/", StringComparison.OrdinalIgnoreCase)
                || (!string.IsNullOrWhiteSpace(profileFolder) && normalized.StartsWith($"{profileFolder}/", StringComparison.OrdinalIgnoreCase));
        }

        private string GetInspectorProfileGenerationFolder()
        {
            if (profile == null)
            {
                return string.Empty;
            }

            string outputFolder = string.IsNullOrWhiteSpace(profile.outputFolder) ? DefaultInspectorOutputFolder : profile.outputFolder;
            string profileName = string.IsNullOrWhiteSpace(profile.name) ? "Profile" : SanitizeInspectorAssetName(profile.name);
            return Path.Combine(outputFolder, profileName).Replace("\\", "/");
        }

        private static string SanitizeInspectorAssetName(string value)
        {
            string cleaned = string.Join("_", (value ?? "Asset").Split(Path.GetInvalidFileNameChars()));
            return string.IsNullOrWhiteSpace(cleaned) ? "Asset" : cleaned;
        }

        private bool IsInspectorProtectedAsset(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return true;
            }

            return path == AssetDatabase.GetAssetPath(fxController)
                || path == AssetDatabase.GetAssetPath(expressionParameters)
                || path == AssetDatabase.GetAssetPath(rootMenu);
        }

        private bool ProfileAlreadyHasImportedControl(ImportPreview preview)
        {
            if (profile == null || profile.controls == null || preview == null || preview.Source == null)
            {
                return false;
            }

            string importedName = BuildImportedControlName(preview);
            string destinationPath = GetParentPath(preview.Source.MenuPath);
            return profile.controls.Any(control =>
                control != null
                && control.controlType == preview.ControlType
                && string.Equals(control.displayName, importedName, StringComparison.OrdinalIgnoreCase)
                && string.Equals(control.destinationPath, destinationPath, StringComparison.OrdinalIgnoreCase));
        }

        private static void DrawClips(InspectedControl item)
        {
            EditorGUILayout.LabelField("Referenced Clip(s)", EditorStyles.boldLabel);
            if (item.Clips.Count == 0)
            {
                EditorGUILayout.LabelField("No clips traced from matched FX layers.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (AnimationClip clip in item.Clips)
            {
                EditorGUILayout.ObjectField(clip, typeof(AnimationClip), false);
            }
        }

        private static void DrawAnimatedProperties(InspectedControl item)
        {
            EditorGUILayout.LabelField("Animated Properties", EditorStyles.boldLabel);
            if (item.AnimatedProperties.Count == 0)
            {
                EditorGUILayout.LabelField("No animated properties traced from matched clips.", EditorStyles.wordWrappedMiniLabel);
                return;
            }

            foreach (string property in item.AnimatedProperties)
            {
                EditorGUILayout.LabelField(property, EditorStyles.wordWrappedMiniLabel);
            }
        }

        private void UseProfileAssets()
        {
            if (profile == null)
            {
                return;
            }

            rootMenu = profile.rootMenu;
            expressionParameters = profile.expressionParameters;
            fxController = profile.fxController;
        }

        private void Scan()
        {
            string selectedPath = selectedIndex >= 0 && selectedIndex < controls.Count ? controls[selectedIndex].MenuPath : string.Empty;
            controls.Clear();
            controlIndexByPath.Clear();
            selectedIndex = -1;
            if (rootMenu == null)
            {
                return;
            }

            HashSet<string> actionBuilderParameters = BuildActionBuilderParameterSet();
            expandedInspectorPaths.Add("Root");
            ScanMenu(rootMenu, "Root", rootMenu, actionBuilderParameters, new HashSet<VRCExpressionsMenu>());
            BuildConflictIndex();
            if (!string.IsNullOrWhiteSpace(selectedPath) && controlIndexByPath.TryGetValue(selectedPath, out int existingIndex))
            {
                selectedIndex = existingIndex;
            }
            else if (controls.Count > 0)
            {
                selectedIndex = 0;
            }

            if (showConflictsOnly)
            {
                ExpandConflictInspectorMenus(rootMenu, "Root", new HashSet<VRCExpressionsMenu>());
                SelectFirstVisibleConflict();
            }
        }

        private void ScanMenu(VRCExpressionsMenu menu, string path, VRCExpressionsMenu parentMenu, HashSet<string> actionBuilderParameters, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            for (int i = 0; i < menu.controls.Count; i++)
            {
                VRCExpressionsMenu.Control control = menu.controls[i];
                string controlName = string.IsNullOrWhiteSpace(control.name) ? "(Unnamed)" : control.name;
                string controlPath = $"{path}/{controlName}";
                InspectedControl item = BuildInspectedControl(control, menu, controlPath, actionBuilderParameters);
                controlIndexByPath[controlPath] = controls.Count;
                controls.Add(item);

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                {
                    ScanMenu(control.subMenu, controlPath, control.subMenu, actionBuilderParameters, visited);
                }
            }
        }

        private InspectedControl BuildInspectedControl(VRCExpressionsMenu.Control control, VRCExpressionsMenu parentMenu, string path, HashSet<string> actionBuilderParameters)
        {
            List<string> parameterNames = GetMenuControlParameterNames(control).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            List<AnimatorControllerLayer> matchedLayers = parameterNames
                .SelectMany(FindLayersUsingParameter)
                .Distinct()
                .ToList();
            Dictionary<AnimatorControllerLayer, string> layerMatchReasons = matchedLayers.ToDictionary(
                layer => layer,
                layer => GetLayerMatchReason(layer, parameterNames));
            List<AnimationClip> clips = matchedLayers
                .SelectMany(CollectLayerClips)
                .Where(clip => clip != null)
                .Distinct()
                .ToList();
            List<AnimatedBindingInfo> animatedBindings = clips
                .SelectMany(CollectClipAnimatedBindings)
                .GroupBy(binding => binding.Key, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.First())
                .OrderBy(binding => binding.Label, StringComparer.OrdinalIgnoreCase)
                .ToList();
            List<string> animatedProperties = animatedBindings
                .Select(binding => binding.Label)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            List<VRCExpressionParameters.Parameter> expressionMatches = FindExpressionParameters(parameterNames).ToList();
            List<AnimatorControllerParameter> animatorMatches = FindAnimatorParameters(parameterNames).ToList();

            InspectedControl item = new InspectedControl
            {
                Name = string.IsNullOrWhiteSpace(control.name) ? "(Unnamed)" : control.name,
                Type = control.type,
                TypeLabel = control.type.ToString(),
                RadialModeLabel = GetRadialModeLabel(control, layerMatchReasons),
                MenuPath = path,
                ParentMenu = parentMenu,
                MenuControl = control,
                Submenu = control.subMenu,
                ParameterNames = parameterNames,
                ExpressionParameters = expressionMatches,
                AnimatorParameters = animatorMatches,
                MatchedLayers = matchedLayers,
                LayerMatchReasons = layerMatchReasons,
                Clips = clips,
                AnimatedBindings = animatedBindings,
                AnimatedProperties = animatedProperties
            };
            item.Confidence = GetConfidence(item, actionBuilderParameters);
            return item;
        }

        private ImportPreview BuildImportPreview(InspectedControl item)
        {
            ImportPreview preview = new ImportPreview
            {
                Source = item,
                Supported = false,
                BlockReason = "Only simple toggles and radials can be imported in this version."
            };

            if (item == null)
            {
                return preview;
            }

            if (profile == null)
            {
                preview.BlockReason = "Assign an Action Builder profile before importing.";
                return preview;
            }

            if (string.Equals(item.Confidence, "Action Builder", StringComparison.OrdinalIgnoreCase))
            {
                preview.BlockReason = "This control already looks like an Action Builder-generated control. Use Action Builder to edit or regenerate it instead of importing it again.";
                return preview;
            }

            if (item.Type == VRCExpressionsMenu.Control.ControlType.RadialPuppet)
            {
                return BuildRadialImportPreview(item, preview);
            }

            if (item.Type != VRCExpressionsMenu.Control.ControlType.Toggle)
            {
                preview.BlockReason = "Import V1 supports expression menu toggles and radial puppets.";
                return preview;
            }

            string parameterName = GetImportParameterName(item);
            if (string.IsNullOrWhiteSpace(parameterName))
            {
                preview.BlockReason = "This toggle has no bool parameter to import.";
                return preview;
            }

            if (!TryFindToggleClips(parameterName, item.MatchedLayers, out List<AnimationClip> offClips, out List<AnimationClip> onClips, out bool hasOffExit, out string clipError))
            {
                preview.BlockReason = clipError;
                return preview;
            }

            if (offClips.Count == 0 && hasOffExit)
            {
                preview.Warnings.Add("No explicit Toggle Off clip was found. Imported rows will use Toggle Off = No Change for values only written by the On state.");
            }

            List<string> unsupported = new List<string>();
            Dictionary<string, ImportedBindingValue> offValues = DecodeClipValues(offClips, "Toggle Off", unsupported);
            Dictionary<string, ImportedBindingValue> onValues = DecodeClipValues(onClips, "Toggle On", unsupported);
            preview.UnsupportedBindings.AddRange(unsupported);

            List<PuddlesAvatarActionRow> importedRows = BuildImportedActionRows(offValues, onValues);
            preview.Actions.AddRange(importedRows.Select(row => BuildImportedActionPreview(row, "Off", "On")));
            preview.ImportedRows = importedRows;
            preview.ParameterName = parameterName;
            if (importedRows.Any(row => row.kind == PuddlesAvatarActionKind.RawBinding))
            {
                preview.Warnings.Add("This import includes raw preserved bindings. They will regenerate faithfully, but friendly editing for those properties comes later.");
            }

            VRCExpressionParameters.Parameter expressionParameter = item.ExpressionParameters.FirstOrDefault(parameter => parameter != null && string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
            preview.Saved = expressionParameter == null || expressionParameter.saved;
            preview.Synced = expressionParameter == null || expressionParameter.networkSynced;
            preview.DefaultValue = expressionParameter != null && expressionParameter.defaultValue > 0.5f;
            preview.Supported = preview.UnsupportedBindings.Count == 0 && preview.ImportedRows.Count > 0;
            preview.BlockReason = preview.Supported
                ? string.Empty
                : preview.UnsupportedBindings.Count > 0
                    ? "Unsupported or non-constant animation bindings were found. Import is disabled so nothing gets silently dropped."
                    : "No supported toggle actions were found in the traced Off/On clips.";
            return preview;
        }

        private ImportPreview BuildRadialImportPreview(InspectedControl item, ImportPreview preview)
        {
            string parameterName = GetRadialImportParameterName(item);
            if (string.IsNullOrWhiteSpace(parameterName))
            {
                preview.BlockReason = "This radial has no float parameter to import.";
                return preview;
            }

            VRCExpressionParameters.Parameter expressionParameter = item.ExpressionParameters.FirstOrDefault(parameter => parameter != null && string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
            preview.ParameterName = parameterName;
            preview.ControlType = PuddlesAvatarControlType.Radial;
            preview.Saved = expressionParameter == null || expressionParameter.saved;
            preview.Synced = expressionParameter == null || expressionParameter.networkSynced;
            preview.RadialDefaultValue = expressionParameter != null ? Mathf.Clamp01(expressionParameter.defaultValue) : 0f;

            List<string> unsupported = new List<string>();
            List<PuddlesAvatarActionRow> importedRows = new List<PuddlesAvatarActionRow>();

            if (string.Equals(item.RadialModeLabel, "Time Parameter", StringComparison.OrdinalIgnoreCase))
            {
                if (!TryFindRadialTimeParameterClips(parameterName, item.MatchedLayers, out List<AnimationClip> clips, out string error))
                {
                    preview.BlockReason = error;
                    return preview;
                }

                Dictionary<string, ImportedBindingValue> radial0Values = DecodeRadialTimeParameterValues(clips, "Radial 0", false, unsupported);
                Dictionary<string, ImportedBindingValue> radial1Values = DecodeRadialTimeParameterValues(clips, "Radial 1", true, unsupported);
                importedRows = BuildRadialImportedActionRows(radial0Values, radial1Values, unsupported);
                preview.RadialMode = PuddlesAvatarRadialMode.TimeParameter;
                preview.Warnings.Add("Radial time-parameter import copies curve endpoints into editable Radial 0 and Radial 1 values.");
            }
            else if (string.Equals(item.RadialModeLabel, "Blend Tree", StringComparison.OrdinalIgnoreCase))
            {
                if (!TryFindRadialBlendTreeClips(parameterName, item.MatchedLayers, out List<AnimationClip> radial0Clips, out List<AnimationClip> radial1Clips, out string error))
                {
                    preview.BlockReason = error;
                    return preview;
                }

                Dictionary<string, ImportedBindingValue> radial0Values = DecodeClipValues(radial0Clips, "Radial 0", unsupported);
                Dictionary<string, ImportedBindingValue> radial1Values = DecodeClipValues(radial1Clips, "Radial 1", unsupported);
                importedRows = BuildRadialImportedActionRows(radial0Values, radial1Values, unsupported);
                preview.RadialMode = PuddlesAvatarRadialMode.BlendTree;
            }
            else
            {
                preview.BlockReason = "This radial is not traced as a Time Parameter or Blend Tree setup.";
                return preview;
            }

            preview.UnsupportedBindings.AddRange(unsupported);
            preview.Actions.AddRange(importedRows.Select(row => BuildImportedActionPreview(row, "Radial 0", "Radial 1")));
            preview.ImportedRows = importedRows;
            preview.Supported = preview.UnsupportedBindings.Count == 0 && preview.ImportedRows.Count > 0;
            preview.BlockReason = preview.Supported
                ? string.Empty
                : preview.UnsupportedBindings.Count > 0
                    ? "Unsupported or non-importable radial bindings were found. Import is disabled so nothing gets silently dropped."
                    : "No supported radial actions were found. V1 imports blendshape and shader-float radial bindings.";
            return preview;
        }

        private string GetImportParameterName(InspectedControl item)
        {
            foreach (VRCExpressionParameters.Parameter parameter in item.ExpressionParameters)
            {
                if (parameter != null && parameter.valueType == VRCExpressionParameters.ValueType.Bool)
                {
                    return parameter.name;
                }
            }

            foreach (AnimatorControllerParameter parameter in item.AnimatorParameters)
            {
                if (parameter != null && parameter.type == AnimatorControllerParameterType.Bool)
                {
                    return parameter.name;
                }
            }

            return string.Empty;
        }

        private string GetRadialImportParameterName(InspectedControl item)
        {
            foreach (VRCExpressionParameters.Parameter parameter in item.ExpressionParameters)
            {
                if (parameter != null && parameter.valueType == VRCExpressionParameters.ValueType.Float)
                {
                    return parameter.name;
                }
            }

            foreach (AnimatorControllerParameter parameter in item.AnimatorParameters)
            {
                if (parameter != null && parameter.type == AnimatorControllerParameterType.Float)
                {
                    return parameter.name;
                }
            }

            return string.Empty;
        }

        private static bool TryFindRadialTimeParameterClips(string parameterName, List<AnimatorControllerLayer> layers, out List<AnimationClip> clips, out string error)
        {
            clips = new List<AnimationClip>();
            error = string.Empty;
            if (string.IsNullOrWhiteSpace(parameterName) || layers == null || layers.Count == 0)
            {
                error = "No matched FX layers were found for this radial parameter.";
                return false;
            }

            foreach (AnimatorControllerLayer layer in layers)
            {
                CollectTimeParameterClips(layer.stateMachine, parameterName, clips, new HashSet<AnimatorStateMachine>());
            }

            clips = clips.Where(clip => clip != null).Distinct().ToList();
            if (clips.Count == 0)
            {
                error = "Could not find a time-parameter animation clip for this radial.";
                return false;
            }

            return true;
        }

        private static void CollectTimeParameterClips(AnimatorStateMachine stateMachine, string parameterName, List<AnimationClip> clips, HashSet<AnimatorStateMachine> visited)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                AnimatorState state = childState.state;
                if (state == null || !state.timeParameterActive || !string.Equals(state.timeParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                clips.AddRange(CollectMotionClips(state.motion, new HashSet<Motion>()));
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                CollectTimeParameterClips(childMachine.stateMachine, parameterName, clips, visited);
            }
        }

        private static bool TryFindRadialBlendTreeClips(string parameterName, List<AnimatorControllerLayer> layers, out List<AnimationClip> radial0Clips, out List<AnimationClip> radial1Clips, out string error)
        {
            radial0Clips = new List<AnimationClip>();
            radial1Clips = new List<AnimationClip>();
            error = string.Empty;
            if (string.IsNullOrWhiteSpace(parameterName) || layers == null || layers.Count == 0)
            {
                error = "No matched FX layers were found for this radial parameter.";
                return false;
            }

            foreach (AnimatorControllerLayer layer in layers)
            {
                CollectBlendTreeEndpointClips(layer.stateMachine, parameterName, radial0Clips, radial1Clips, new HashSet<AnimatorStateMachine>(), new HashSet<Motion>());
            }

            radial0Clips = radial0Clips.Where(clip => clip != null).Distinct().ToList();
            radial1Clips = radial1Clips.Where(clip => clip != null).Distinct().ToList();
            if (radial0Clips.Count == 0 || radial1Clips.Count == 0)
            {
                error = "Could not find clear Radial 0 and Radial 1 clips from a blend tree.";
                return false;
            }

            return true;
        }

        private static void CollectBlendTreeEndpointClips(AnimatorStateMachine stateMachine, string parameterName, List<AnimationClip> radial0Clips, List<AnimationClip> radial1Clips, HashSet<AnimatorStateMachine> visitedMachines, HashSet<Motion> visitedMotions)
        {
            if (stateMachine == null || !visitedMachines.Add(stateMachine))
            {
                return;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                CollectBlendTreeEndpointClips(childState.state != null ? childState.state.motion : null, parameterName, radial0Clips, radial1Clips, visitedMotions);
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                CollectBlendTreeEndpointClips(childMachine.stateMachine, parameterName, radial0Clips, radial1Clips, visitedMachines, visitedMotions);
            }
        }

        private static void CollectBlendTreeEndpointClips(Motion motion, string parameterName, List<AnimationClip> radial0Clips, List<AnimationClip> radial1Clips, HashSet<Motion> visited)
        {
            if (motion == null || !visited.Add(motion))
            {
                return;
            }

            if (!(motion is BlendTree blendTree))
            {
                return;
            }

            if (string.Equals(blendTree.blendParameter, parameterName, StringComparison.OrdinalIgnoreCase))
            {
                ChildMotion[] children = blendTree.children.OrderBy(child => child.threshold).ToArray();
                if (children.Length >= 2)
                {
                    radial0Clips.AddRange(CollectMotionClips(children[0].motion, new HashSet<Motion>()));
                    radial1Clips.AddRange(CollectMotionClips(children[children.Length - 1].motion, new HashSet<Motion>()));
                }
            }

            foreach (ChildMotion child in blendTree.children)
            {
                CollectBlendTreeEndpointClips(child.motion, parameterName, radial0Clips, radial1Clips, visited);
            }
        }

        private static bool TryFindToggleClips(string parameterName, List<AnimatorControllerLayer> layers, out List<AnimationClip> offClips, out List<AnimationClip> onClips, out bool hasOffExit, out string error)
        {
            offClips = new List<AnimationClip>();
            onClips = new List<AnimationClip>();
            hasOffExit = false;
            error = string.Empty;

            if (string.IsNullOrWhiteSpace(parameterName) || layers == null || layers.Count == 0)
            {
                error = "No matched FX layers were found for this toggle parameter.";
                return false;
            }

            foreach (AnimatorControllerLayer layer in layers)
            {
                CollectToggleClipsFromStateMachine(layer.stateMachine, parameterName, offClips, onClips, ref hasOffExit, new HashSet<AnimatorStateMachine>());
            }

            offClips = offClips.Where(clip => clip != null).Distinct().ToList();
            onClips = onClips.Where(clip => clip != null).Distinct().ToList();
            if (onClips.Count == 0)
            {
                error = "Could not find a clear Toggle On animation clip from an If transition.";
                return false;
            }

            if (offClips.Count == 0 && !hasOffExit)
            {
                error = "Could not find a clear Toggle Off animation clip or an IfNot exit transition.";
                return false;
            }

            return true;
        }

        private static void CollectToggleClipsFromStateMachine(AnimatorStateMachine stateMachine, string parameterName, List<AnimationClip> offClips, List<AnimationClip> onClips, ref bool hasOffExit, HashSet<AnimatorStateMachine> visited)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return;
            }

            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
            {
                CollectToggleClipFromTransition(transition, parameterName, offClips, onClips, ref hasOffExit);
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state == null)
                {
                    continue;
                }

                foreach (AnimatorStateTransition transition in childState.state.transitions)
                {
                    CollectToggleClipFromTransition(transition, parameterName, offClips, onClips, ref hasOffExit);
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                CollectToggleClipsFromStateMachine(childMachine.stateMachine, parameterName, offClips, onClips, ref hasOffExit, visited);
            }
        }

        private static void CollectToggleClipFromTransition(AnimatorStateTransition transition, string parameterName, List<AnimationClip> offClips, List<AnimationClip> onClips, ref bool hasOffExit)
        {
            if (transition == null || transition.conditions == null || transition.conditions.Length != 1)
            {
                return;
            }

            foreach (AnimatorCondition condition in transition.conditions)
            {
                if (!string.Equals(condition.parameter, parameterName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (condition.mode == AnimatorConditionMode.If)
                {
                    AnimationClip clip = transition.destinationState != null ? transition.destinationState.motion as AnimationClip : null;
                    if (clip != null)
                    {
                        onClips.Add(clip);
                    }
                }
                else if (condition.mode == AnimatorConditionMode.IfNot)
                {
                    AnimationClip clip = transition.destinationState != null ? transition.destinationState.motion as AnimationClip : null;
                    if (clip != null)
                    {
                        offClips.Add(clip);
                    }
                    else
                    {
                        hasOffExit = true;
                    }
                }
            }
        }

        private Dictionary<string, ImportedBindingValue> DecodeClipValues(List<AnimationClip> clips, string stateLabel, List<string> unsupported)
        {
            Dictionary<string, ImportedBindingValue> values = new Dictionary<string, ImportedBindingValue>(StringComparer.OrdinalIgnoreCase);
            foreach (AnimationClip clip in clips)
            {
                foreach (EditorCurveBinding binding in AnimationUtility.GetCurveBindings(clip))
                {
                    if (!TryDecodeFloatBinding(clip, binding, stateLabel, out ImportedBindingValue value, out string reason))
                    {
                        unsupported.Add($"{stateLabel}: {FormatBindingForImport(binding)} - {reason}");
                        continue;
                    }

                    AddImportedBindingValue(values, value, stateLabel, unsupported);
                }

                foreach (EditorCurveBinding binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    if (!TryDecodeObjectReferenceBinding(clip, binding, stateLabel, out ImportedBindingValue value, out string reason))
                    {
                        unsupported.Add($"{stateLabel}: {FormatBindingForImport(binding)} - {reason}");
                        continue;
                    }

                    AddImportedBindingValue(values, value, stateLabel, unsupported);
                }
            }

            return values;
        }

        private Dictionary<string, ImportedBindingValue> DecodeRadialTimeParameterValues(List<AnimationClip> clips, string stateLabel, bool useEndValue, List<string> unsupported)
        {
            Dictionary<string, ImportedBindingValue> values = new Dictionary<string, ImportedBindingValue>(StringComparer.OrdinalIgnoreCase);
            foreach (AnimationClip clip in clips)
            {
                foreach (EditorCurveBinding binding in AnimationUtility.GetCurveBindings(clip))
                {
                    if (!TryDecodeRadialFloatBinding(clip, binding, useEndValue, out ImportedBindingValue value, out string reason))
                    {
                        unsupported.Add($"{stateLabel}: {FormatBindingForImport(binding)} - {reason}");
                        continue;
                    }

                    AddImportedBindingValue(values, value, stateLabel, unsupported);
                }

                foreach (EditorCurveBinding binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    unsupported.Add($"{stateLabel}: {FormatBindingForImport(binding)} - object reference radial bindings are not supported in V1.");
                }
            }

            return values;
        }

        private static void AddImportedBindingValue(Dictionary<string, ImportedBindingValue> values, ImportedBindingValue value, string stateLabel, List<string> unsupported)
        {
            if (value == null)
            {
                return;
            }

            if (!values.TryGetValue(value.Key, out ImportedBindingValue existing))
            {
                values[value.Key] = value;
                return;
            }

            if (!existing.HasSameValue(value))
            {
                unsupported.Add($"{stateLabel}: {value.Label} has multiple different values across matched clips.");
            }
        }

        private bool TryDecodeFloatBinding(AnimationClip clip, EditorCurveBinding binding, string stateLabel, out ImportedBindingValue value, out string reason)
        {
            value = null;
            reason = string.Empty;
            AnimationCurve curve = AnimationUtility.GetEditorCurve(clip, binding);
            if (!TryGetConstantFloat(curve, out float floatValue))
            {
                reason = "animated curve is not constant";
                return false;
            }

            string propertyName = binding.propertyName ?? string.Empty;
            if (binding.type == typeof(GameObject) && propertyName == "m_IsActive")
            {
                value = ImportedBindingValue.ForFloat(ImportedBindingKind.ObjectState, binding, floatValue);
                return true;
            }

            if (typeof(Component).IsAssignableFrom(binding.type) && propertyName == "m_Enabled")
            {
                value = ImportedBindingValue.ForFloat(ImportedBindingKind.ComponentEnabled, binding, floatValue);
                value.ComponentTypeName = binding.type.AssemblyQualifiedName;
                value.ComponentTypeDisplayName = binding.type.Name;
                return true;
            }

            if (binding.type == typeof(SkinnedMeshRenderer) && propertyName.StartsWith("blendShape.", StringComparison.Ordinal))
            {
                value = ImportedBindingValue.ForFloat(ImportedBindingKind.Blendshape, binding, floatValue);
                value.BlendshapeName = propertyName.Substring("blendShape.".Length);
                return true;
            }

            if (IsRendererBinding(binding) && TryParseShaderFloatProperty(propertyName, out int materialSlot, out string shaderPropertyName))
            {
                value = ImportedBindingValue.ForFloat(ImportedBindingKind.ShaderFloat, binding, floatValue);
                value.MaterialSlot = materialSlot;
                value.ShaderPropertyName = shaderPropertyName;
                return true;
            }

            if (!TryValidateRawBinding(binding, out reason))
            {
                return false;
            }

            value = ImportedBindingValue.ForRawFloat(binding, floatValue);
            return true;
        }

        private static bool TryDecodeRadialFloatBinding(AnimationClip clip, EditorCurveBinding binding, bool useEndValue, out ImportedBindingValue value, out string reason)
        {
            value = null;
            reason = string.Empty;
            AnimationCurve curve = AnimationUtility.GetEditorCurve(clip, binding);
            if (curve == null || curve.keys == null || curve.keys.Length == 0)
            {
                reason = "animated curve has no keys";
                return false;
            }

            float floatValue = curve.Evaluate(useEndValue ? 1f : 0f);
            string propertyName = binding.propertyName ?? string.Empty;
            if (binding.type == typeof(SkinnedMeshRenderer) && propertyName.StartsWith("blendShape.", StringComparison.Ordinal))
            {
                value = ImportedBindingValue.ForFloat(ImportedBindingKind.Blendshape, binding, floatValue);
                value.BlendshapeName = propertyName.Substring("blendShape.".Length);
                return true;
            }

            if (IsRendererBinding(binding) && TryParseShaderFloatProperty(propertyName, out int materialSlot, out string shaderPropertyName))
            {
                value = ImportedBindingValue.ForFloat(ImportedBindingKind.ShaderFloat, binding, floatValue);
                value.MaterialSlot = materialSlot;
                value.ShaderPropertyName = shaderPropertyName;
                return true;
            }

            reason = "radial import V1 supports blendshape and shader-float curves only";
            return false;
        }

        private static bool TryDecodeObjectReferenceBinding(AnimationClip clip, EditorCurveBinding binding, string stateLabel, out ImportedBindingValue value, out string reason)
        {
            value = null;
            reason = string.Empty;

            ObjectReferenceKeyframe[] keyframes = AnimationUtility.GetObjectReferenceCurve(clip, binding);
            if (!TryGetConstantObjectReference(keyframes, out UnityEngine.Object objectValue))
            {
                reason = "object reference curve is not constant";
                return false;
            }

            if (IsRendererBinding(binding) && TryParseMaterialSlotProperty(binding.propertyName ?? string.Empty, out int materialSlot) && (objectValue == null || objectValue is Material))
            {
                value = ImportedBindingValue.ForMaterial(binding, objectValue as Material);
                value.MaterialSlot = materialSlot;
                return true;
            }

            if (!TryValidateRawBinding(binding, out reason))
            {
                return false;
            }

            value = ImportedBindingValue.ForRawObjectReference(binding, objectValue);
            return true;
        }

        private static bool TryValidateRawBinding(EditorCurveBinding binding, out string reason)
        {
            reason = string.Empty;
            if (binding.type == null || string.IsNullOrWhiteSpace(binding.type.AssemblyQualifiedName) || Type.GetType(binding.type.AssemblyQualifiedName) == null)
            {
                reason = "binding target type could not be resolved";
                return false;
            }

            if (string.IsNullOrWhiteSpace(binding.propertyName))
            {
                reason = "binding property name is missing";
                return false;
            }

            return true;
        }

        private List<PuddlesAvatarActionRow> BuildImportedActionRows(Dictionary<string, ImportedBindingValue> offValues, Dictionary<string, ImportedBindingValue> onValues)
        {
            List<PuddlesAvatarActionRow> rows = new List<PuddlesAvatarActionRow>();
            HashSet<string> keys = new HashSet<string>(offValues.Keys, StringComparer.OrdinalIgnoreCase);
            keys.UnionWith(onValues.Keys);
            foreach (string key in keys.OrderBy(value => value, StringComparer.OrdinalIgnoreCase))
            {
                ImportedBindingValue offValue = offValues.TryGetValue(key, out ImportedBindingValue off) ? off : null;
                ImportedBindingValue onValue = onValues.TryGetValue(key, out ImportedBindingValue on) ? on : null;
                ImportedBindingValue sample = offValue ?? onValue;
                if (sample == null)
                {
                    continue;
                }

                PuddlesAvatarActionRow row = CreateImportedActionRow(sample);
                row.offWriteMode = offValue == null ? PuddlesAvatarWriteMode.NoChange : PuddlesAvatarWriteMode.Set;
                row.onWriteMode = onValue == null ? PuddlesAvatarWriteMode.NoChange : PuddlesAvatarWriteMode.Set;
                ApplyImportedValue(row, offValue, false);
                ApplyImportedValue(row, onValue, true);
                rows.Add(row);
            }

            return rows;
        }

        private List<PuddlesAvatarActionRow> BuildRadialImportedActionRows(Dictionary<string, ImportedBindingValue> radial0Values, Dictionary<string, ImportedBindingValue> radial1Values, List<string> unsupported)
        {
            List<PuddlesAvatarActionRow> rows = BuildImportedActionRows(radial0Values, radial1Values);
            List<PuddlesAvatarActionRow> supportedRows = new List<PuddlesAvatarActionRow>();
            foreach (PuddlesAvatarActionRow row in rows)
            {
                if (IsRadialImportRowSupported(row))
                {
                    supportedRows.Add(row);
                }
                else
                {
                    unsupported.Add($"Radial: {GetImportedRowTarget(row)} - {row.kind} rows are not supported by radial import V1.");
                }
            }

            return supportedRows;
        }

        private static bool IsRadialImportRowSupported(PuddlesAvatarActionRow row)
        {
            return row != null && (row.kind == PuddlesAvatarActionKind.Blendshape || row.kind == PuddlesAvatarActionKind.ShaderFloat);
        }

        private PuddlesAvatarActionRow CreateImportedActionRow(ImportedBindingValue sample)
        {
            PuddlesAvatarActionRow row = new PuddlesAvatarActionRow();
            string relativePath = sample.Path == "(Avatar Root)" ? string.Empty : sample.Path;
            Transform target = FindImportTarget(relativePath);
            switch (sample.Kind)
            {
                case ImportedBindingKind.ObjectState:
                    row.kind = PuddlesAvatarActionKind.ObjectState;
                    row.targetObjectPath = relativePath;
                    row.targetObject = target != null ? target.gameObject : null;
                    break;
                case ImportedBindingKind.Blendshape:
                    row.kind = PuddlesAvatarActionKind.Blendshape;
                    row.skinnedRendererPath = relativePath;
                    row.skinnedRenderer = target != null ? target.GetComponent<SkinnedMeshRenderer>() : null;
                    row.blendshapeName = sample.BlendshapeName;
                    break;
                case ImportedBindingKind.MaterialSwap:
                    row.kind = PuddlesAvatarActionKind.MaterialSwap;
                    row.rendererPath = relativePath;
                    row.renderer = target != null ? target.GetComponent<Renderer>() : null;
                    row.materialSlot = sample.MaterialSlot;
                    break;
                case ImportedBindingKind.ComponentEnabled:
                    row.kind = PuddlesAvatarActionKind.ComponentEnabled;
                    row.componentPath = relativePath;
                    row.componentTypeName = sample.ComponentTypeName;
                    row.component = FindComponentOnTransform(target, sample.ComponentTypeName);
                    break;
                case ImportedBindingKind.RawBinding:
                    row.kind = PuddlesAvatarActionKind.RawBinding;
                    row.rawBindingPath = relativePath;
                    row.rawBindingTypeName = sample.RawBindingTypeName;
                    row.rawBindingPropertyName = sample.RawBindingPropertyName;
                    row.rawBindingValueKind = sample.RawBindingValueKind;
                    break;
                case ImportedBindingKind.ShaderFloat:
                    row.kind = PuddlesAvatarActionKind.ShaderFloat;
                    row.rendererPath = relativePath;
                    row.renderer = target != null ? target.GetComponent<Renderer>() : null;
                    row.materialSlot = sample.MaterialSlot;
                    row.shaderPropertyName = sample.ShaderPropertyName;
                    row.shaderPropertyPaste = sample.MaterialSlot == 0 ? $"material.{sample.ShaderPropertyName}" : $"material.[{sample.MaterialSlot}].{sample.ShaderPropertyName}";
                    break;
            }

            return row;
        }

        private void ApplyImportedValue(PuddlesAvatarActionRow row, ImportedBindingValue value, bool onState)
        {
            if (row == null || value == null)
            {
                return;
            }

            switch (value.Kind)
            {
                case ImportedBindingKind.ObjectState:
                case ImportedBindingKind.ComponentEnabled:
                    if (onState)
                    {
                        row.onBool = value.FloatValue > 0.5f;
                    }
                    else
                    {
                        row.offBool = value.FloatValue > 0.5f;
                    }
                    break;
                case ImportedBindingKind.Blendshape:
                case ImportedBindingKind.ShaderFloat:
                    if (onState)
                    {
                        row.onFloat = value.FloatValue;
                    }
                    else
                    {
                        row.offFloat = value.FloatValue;
                    }
                    break;
                case ImportedBindingKind.MaterialSwap:
                    if (onState)
                    {
                        row.onMaterial = value.MaterialValue;
                    }
                    else
                    {
                        row.offMaterial = value.MaterialValue;
                    }
                    break;
                case ImportedBindingKind.RawBinding:
                    if (value.RawBindingValueKind == PuddlesAvatarRawBindingValueKind.ObjectReference)
                    {
                        if (onState)
                        {
                            row.onObjectReference = value.ObjectReferenceValue;
                        }
                        else
                        {
                            row.offObjectReference = value.ObjectReferenceValue;
                        }
                    }
                    else if (onState)
                    {
                        row.onFloat = value.FloatValue;
                    }
                    else
                    {
                        row.offFloat = value.FloatValue;
                    }
                    break;
            }
        }

        private static ImportedActionPreview BuildImportedActionPreview(PuddlesAvatarActionRow row, string lowLabel, string highLabel)
        {
            string offValue = row.offWriteMode == PuddlesAvatarWriteMode.NoChange ? "No Change" : FormatImportedRowValue(row, false);
            string onValue = row.onWriteMode == PuddlesAvatarWriteMode.NoChange ? "No Change" : FormatImportedRowValue(row, true);
            string kind = row.kind == PuddlesAvatarActionKind.RawBinding ? "Raw Preserved Binding" : row.kind.ToString();
            return new ImportedActionPreview
            {
                Summary = $"{kind}: {GetImportedRowTarget(row)} | {lowLabel}: {offValue} | {highLabel}: {onValue}"
            };
        }

        private static string GetImportedRowTarget(PuddlesAvatarActionRow row)
        {
            switch (row.kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    return string.IsNullOrWhiteSpace(row.targetObjectPath) ? "(Avatar Root)" : row.targetObjectPath;
                case PuddlesAvatarActionKind.Blendshape:
                    return $"{(string.IsNullOrWhiteSpace(row.skinnedRendererPath) ? "(Avatar Root)" : row.skinnedRendererPath)} / {row.blendshapeName}";
                case PuddlesAvatarActionKind.MaterialSwap:
                    return $"{(string.IsNullOrWhiteSpace(row.rendererPath) ? "(Avatar Root)" : row.rendererPath)} / material slot {row.materialSlot}";
                case PuddlesAvatarActionKind.ComponentEnabled:
                    return $"{(string.IsNullOrWhiteSpace(row.componentPath) ? "(Avatar Root)" : row.componentPath)} / {GetComponentTypeDisplayName(row.componentTypeName)}";
                case PuddlesAvatarActionKind.RawBinding:
                    return $"{(string.IsNullOrWhiteSpace(row.rawBindingPath) ? "(Avatar Root)" : row.rawBindingPath)} / {GetComponentTypeDisplayName(row.rawBindingTypeName)}.{row.rawBindingPropertyName}";
                case PuddlesAvatarActionKind.ShaderFloat:
                    return $"{(string.IsNullOrWhiteSpace(row.rendererPath) ? "(Avatar Root)" : row.rendererPath)} / material slot {row.materialSlot} / {row.shaderPropertyName}";
                default:
                    return "(Unknown)";
            }
        }

        private static string FormatImportedRowValue(PuddlesAvatarActionRow row, bool onState)
        {
            switch (row.kind)
            {
                case PuddlesAvatarActionKind.ObjectState:
                    return onState ? (row.onBool ? "Active" : "Inactive") : (row.offBool ? "Active" : "Inactive");
                case PuddlesAvatarActionKind.ComponentEnabled:
                    return onState ? (row.onBool ? "Enabled" : "Disabled") : (row.offBool ? "Enabled" : "Disabled");
                case PuddlesAvatarActionKind.Blendshape:
                case PuddlesAvatarActionKind.ShaderFloat:
                    return (onState ? row.onFloat : row.offFloat).ToString("0.###");
                case PuddlesAvatarActionKind.MaterialSwap:
                    Material material = onState ? row.onMaterial : row.offMaterial;
                    return material != null ? material.name : "None";
                case PuddlesAvatarActionKind.RawBinding:
                    if (row.rawBindingValueKind == PuddlesAvatarRawBindingValueKind.ObjectReference)
                    {
                        UnityEngine.Object objectReference = onState ? row.onObjectReference : row.offObjectReference;
                        return objectReference != null ? objectReference.name : "None";
                    }

                    return (onState ? row.onFloat : row.offFloat).ToString("0.###");
                default:
                    return string.Empty;
            }
        }

        private PuddlesAvatarActionControl ImportPreviewToProfile(ImportPreview preview)
        {
            if (profile == null || preview == null || !preview.CanImport)
            {
                return null;
            }

            if (profile.controls == null)
            {
                profile.controls = new List<PuddlesAvatarActionControl>();
            }

            PuddlesAvatarActionControl control = new PuddlesAvatarActionControl
            {
                id = Guid.NewGuid().ToString("N").Substring(0, 12),
                displayName = BuildImportedControlName(preview),
                controlType = preview.ControlType,
                radialMode = preview.RadialMode,
                destinationMenu = preview.Source.ParentMenu != null ? preview.Source.ParentMenu : profile.rootMenu,
                destinationPath = GetParentPath(preview.Source.MenuPath),
                saved = preview.Saved,
                synced = preview.Synced,
                defaultValue = preview.DefaultValue,
                radialDefaultValue = preview.RadialDefaultValue,
                actions = preview.ImportedRows
            };

            profile.controls.Add(control);
            EditorUtility.SetDirty(profile);
            return control;
        }

        private static string BuildImportedControlName(ImportPreview preview)
        {
            if (preview == null || preview.Source == null || string.IsNullOrWhiteSpace(preview.Source.Name))
            {
                return $"Imported {preview?.ControlType ?? PuddlesAvatarControlType.Toggle}";
            }

            return $"{preview.Source.Name} Imported";
        }

        private Transform FindImportTarget(string relativePath)
        {
            if (profile == null || profile.avatarRoot == null)
            {
                return null;
            }

            return string.IsNullOrWhiteSpace(relativePath)
                ? profile.avatarRoot.transform
                : FindTransformByFlexiblePath(profile.avatarRoot.transform, relativePath);
        }

        private static Type GetComponentType(string componentTypeName)
        {
            if (string.IsNullOrWhiteSpace(componentTypeName))
            {
                return null;
            }

            Type direct = Type.GetType(componentTypeName);
            if (direct != null)
            {
                return direct;
            }

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = assembly.GetType(componentTypeName, false);
                if (type != null)
                {
                    return type;
                }
            }

            string shortName = componentTypeName.Split(',')[0].Trim();
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = GetLoadableTypes(assembly).FirstOrDefault(candidate =>
                    string.Equals(candidate.FullName, shortName, StringComparison.Ordinal)
                    || string.Equals(candidate.Name, shortName, StringComparison.Ordinal));
                if (type != null)
                {
                    return type;
                }
            }

            return null;
        }

        private static IEnumerable<Type> GetLoadableTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException exception)
            {
                return exception.Types.Where(type => type != null);
            }
        }

        private static string GetComponentTypeDisplayName(string componentTypeName)
        {
            Type type = GetComponentType(componentTypeName);
            return type != null ? type.Name : string.IsNullOrWhiteSpace(componentTypeName) ? "(Unknown Type)" : componentTypeName;
        }

        private static Transform FindTransformByFlexiblePath(Transform root, string relativePath)
        {
            if (root == null)
            {
                return null;
            }

            string normalized = NormalizeAvatarPath(relativePath);
            Transform exact = root.Find(normalized);
            if (exact != null)
            {
                return exact;
            }

            string rootPrefix = $"{root.name}/";
            if (normalized.StartsWith(rootPrefix, StringComparison.Ordinal))
            {
                exact = root.Find(normalized.Substring(rootPrefix.Length));
                if (exact != null)
                {
                    return exact;
                }
            }

            Transform[] descendants = root.GetComponentsInChildren<Transform>(true);
            Transform match = null;
            int bestLength = int.MaxValue;
            foreach (Transform candidate in descendants)
            {
                string candidatePath = NormalizeAvatarPath(AnimationUtility.CalculateTransformPath(candidate, root));
                if (!string.Equals(candidatePath, normalized, StringComparison.Ordinal)
                    && !candidatePath.EndsWith($"/{normalized}", StringComparison.Ordinal)
                    && !normalized.EndsWith($"/{candidatePath}", StringComparison.Ordinal))
                {
                    continue;
                }

                if (candidatePath.Length < bestLength)
                {
                    match = candidate;
                    bestLength = candidatePath.Length;
                }
            }

            return match;
        }

        private static string NormalizeAvatarPath(string path)
        {
            return (path ?? string.Empty).Replace("\\", "/").Trim('/');
        }

        private static Component FindComponentOnTransform(Transform target, string componentTypeName)
        {
            if (target == null)
            {
                return null;
            }

            Type componentType = GetComponentType(componentTypeName);
            if (componentType != null)
            {
                Component component = target.GetComponent(componentType);
                if (component != null)
                {
                    return component;
                }
            }

            string fullName = componentType != null ? componentType.FullName : GetFullTypeNameWithoutAssembly(componentTypeName);
            string shortName = componentType != null ? componentType.Name : GetShortTypeName(componentTypeName);
            foreach (Component component in target.GetComponents<Component>())
            {
                if (component == null)
                {
                    continue;
                }

                Type actualType = component.GetType();
                if (string.Equals(actualType.AssemblyQualifiedName, componentTypeName, StringComparison.Ordinal)
                    || string.Equals(actualType.FullName, fullName, StringComparison.Ordinal)
                    || string.Equals(actualType.Name, shortName, StringComparison.Ordinal))
                {
                    return component;
                }
            }

            return null;
        }

        private static string GetFullTypeNameWithoutAssembly(string typeName)
        {
            return string.IsNullOrWhiteSpace(typeName) ? string.Empty : typeName.Split(',')[0].Trim();
        }

        private static string GetShortTypeName(string typeName)
        {
            string fullName = GetFullTypeNameWithoutAssembly(typeName);
            int dot = fullName.LastIndexOf('.');
            return dot >= 0 ? fullName.Substring(dot + 1) : fullName;
        }

        private static string GetParentPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !path.Contains("/"))
            {
                return "Root";
            }

            int slash = path.LastIndexOf("/", StringComparison.Ordinal);
            return slash <= 0 ? "Root" : path.Substring(0, slash);
        }

        private static bool TryGetConstantFloat(AnimationCurve curve, out float value)
        {
            value = 0f;
            if (curve == null || curve.keys == null || curve.keys.Length == 0)
            {
                return false;
            }

            value = curve.keys[0].value;
            float firstValue = value;
            foreach (Keyframe key in curve.keys)
            {
                if (!Mathf.Approximately(key.value, firstValue))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool TryGetConstantObjectReference(ObjectReferenceKeyframe[] keyframes, out UnityEngine.Object value)
        {
            value = null;
            if (keyframes == null || keyframes.Length == 0)
            {
                return false;
            }

            value = keyframes[0].value;
            UnityEngine.Object firstValue = value;
            foreach (ObjectReferenceKeyframe keyframe in keyframes)
            {
                if (keyframe.value != firstValue)
                {
                    return false;
                }
            }

            return true;
        }

        private static bool IsRendererBinding(EditorCurveBinding binding)
        {
            return binding.type != null && typeof(Renderer).IsAssignableFrom(binding.type);
        }

        private static bool TryParseMaterialSlotProperty(string propertyName, out int materialSlot)
        {
            materialSlot = 0;
            const string prefix = "m_Materials.Array.data[";
            if (string.IsNullOrWhiteSpace(propertyName) || !propertyName.StartsWith(prefix, StringComparison.Ordinal) || !propertyName.EndsWith("]", StringComparison.Ordinal))
            {
                return false;
            }

            string indexText = propertyName.Substring(prefix.Length, propertyName.Length - prefix.Length - 1);
            return int.TryParse(indexText, out materialSlot);
        }

        private static bool TryParseShaderFloatProperty(string propertyName, out int materialSlot, out string shaderPropertyName)
        {
            materialSlot = 0;
            shaderPropertyName = string.Empty;
            const string prefix = "material.";
            if (string.IsNullOrWhiteSpace(propertyName) || !propertyName.StartsWith(prefix, StringComparison.Ordinal))
            {
                return false;
            }

            string rest = propertyName.Substring(prefix.Length);
            if (rest.StartsWith("[", StringComparison.Ordinal))
            {
                int closeIndex = rest.IndexOf("].", StringComparison.Ordinal);
                if (closeIndex <= 1 || !int.TryParse(rest.Substring(1, closeIndex - 1), out materialSlot))
                {
                    return false;
                }

                shaderPropertyName = rest.Substring(closeIndex + 2);
            }
            else
            {
                shaderPropertyName = rest;
            }

            return !string.IsNullOrWhiteSpace(shaderPropertyName) && !shaderPropertyName.Contains(".");
        }

        private static bool TryParseShaderPropertyPaste(string pastedText, out string rendererPath, out int materialSlot, out string shaderPropertyName)
        {
            rendererPath = string.Empty;
            materialSlot = 0;
            shaderPropertyName = string.Empty;
            string text = (pastedText ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            int colonIndex = text.IndexOf(':');
            if (colonIndex >= 0)
            {
                rendererPath = text.Substring(0, colonIndex).Trim();
                text = text.Substring(colonIndex + 1).Trim();
            }

            int materialIndex = text.IndexOf("material.", StringComparison.Ordinal);
            if (materialIndex >= 0)
            {
                text = text.Substring(materialIndex);
                return TryParseShaderFloatProperty(text, out materialSlot, out shaderPropertyName);
            }

            int lastDot = text.LastIndexOf('.');
            if (lastDot >= 0)
            {
                string maybePath = text.Substring(0, lastDot).Trim();
                string maybeProperty = text.Substring(lastDot + 1).Trim();
                if (LooksLikeShaderProperty(maybeProperty))
                {
                    if (string.IsNullOrWhiteSpace(rendererPath) && !string.IsNullOrWhiteSpace(maybePath))
                    {
                        rendererPath = maybePath;
                    }

                    shaderPropertyName = maybeProperty;
                    return true;
                }
            }

            shaderPropertyName = text;
            return LooksLikeShaderProperty(shaderPropertyName);
        }

        private static bool LooksLikeShaderProperty(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Contains("/") || value.Contains("\\") || value.Contains(" "))
            {
                return false;
            }

            return value.StartsWith("_", StringComparison.Ordinal) || value.All(character => char.IsLetterOrDigit(character) || character == '_');
        }

        private static string FormatBindingForImport(EditorCurveBinding binding)
        {
            string path = string.IsNullOrWhiteSpace(binding.path) ? "(Avatar Root)" : binding.path;
            string type = binding.type != null ? binding.type.Name : "Unknown";
            return $"{path} : {type}.{binding.propertyName}";
        }

        private HashSet<string> BuildActionBuilderParameterSet()
        {
            HashSet<string> parameters = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (profile == null || profile.controls == null)
            {
                return parameters;
            }

            string prefix = string.IsNullOrWhiteSpace(profile.parameterPrefix) ? DefaultParameterPrefix : profile.parameterPrefix.Trim().Trim('/');
            foreach (PuddlesAvatarActionControl control in profile.controls)
            {
                if (control == null || string.IsNullOrWhiteSpace(control.id))
                {
                    continue;
                }

                parameters.Add(AvatarActionBuilderWindow.BuildReadableParameterName(prefix, control));
                parameters.Add($"{prefix}/{control.id}");
            }

            return parameters;
        }

        private static string BuildControlRowLabel(InspectedControl item)
        {
            string parameter = item.ParameterNames.Count == 0 ? "no parameter" : string.Join(", ", item.ParameterNames);
            return $"{item.MenuPath} ({item.TypeLabel}) - {parameter} - {item.Confidence}";
        }

        private static string BuildTreeRowLabel(InspectedControl item)
        {
            string parameter = item.ParameterNames.Count == 0 ? "no parameter" : string.Join(", ", item.ParameterNames);
            string conflicts = item.Conflicts.Count > 0 ? $" - Conflict x{item.Conflicts.Count}" : string.Empty;
            return $"{item.Name} ({item.TypeLabel}) - {parameter} - {item.Confidence}{conflicts}";
        }

        private void BuildConflictIndex()
        {
            foreach (InspectedControl control in controls)
            {
                control.Conflicts.Clear();
            }

            Dictionary<string, Dictionary<string, BindingConflictMember>> byBinding = new Dictionary<string, Dictionary<string, BindingConflictMember>>(StringComparer.OrdinalIgnoreCase);
            foreach (InspectedControl control in controls)
            {
                foreach (AnimatedBindingInfo binding in control.AnimatedBindings)
                {
                    if (binding == null || string.IsNullOrWhiteSpace(binding.Key))
                    {
                        continue;
                    }

                    if (!byBinding.TryGetValue(binding.Key, out Dictionary<string, BindingConflictMember> members))
                    {
                        members = new Dictionary<string, BindingConflictMember>(StringComparer.OrdinalIgnoreCase);
                        byBinding[binding.Key] = members;
                    }

                    if (!members.ContainsKey(control.MenuPath))
                    {
                        members[control.MenuPath] = new BindingConflictMember
                        {
                            Control = control,
                            Binding = binding
                        };
                    }
                }
            }

            foreach (Dictionary<string, BindingConflictMember> members in byBinding.Values)
            {
                if (members.Count < 2)
                {
                    continue;
                }

                List<BindingConflictMember> memberList = members.Values.ToList();
                foreach (BindingConflictMember member in memberList)
                {
                    member.Control.Conflicts.Add(new BindingConflictInfo
                    {
                        Binding = member.Binding,
                        OtherControls = memberList
                            .Where(other => other.Control != member.Control)
                            .Select(other => other.Control)
                            .OrderBy(other => other.MenuPath, StringComparer.OrdinalIgnoreCase)
                            .ToList()
                    });
                }
            }

            foreach (InspectedControl control in controls)
            {
                control.Conflicts = control.Conflicts
                    .OrderBy(conflict => conflict.Binding.Label, StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
        }

        private void ExpandAllInspectorMenus(VRCExpressionsMenu menu, string path, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            expandedInspectorPaths.Add(path);
            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null)
                {
                    continue;
                }

                string controlName = string.IsNullOrWhiteSpace(control.name) ? "(Unnamed)" : control.name;
                ExpandAllInspectorMenus(control.subMenu, $"{path}/{controlName}", visited);
            }
        }

        private void ExpandConflictInspectorMenus(VRCExpressionsMenu menu, string path, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            bool subtreeHasConflict = path == "Root" || controls.Any(control => control.MenuPath.StartsWith($"{path}/", StringComparison.OrdinalIgnoreCase) && control.Conflicts.Count > 0);
            if (subtreeHasConflict)
            {
                expandedInspectorPaths.Add(path);
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null)
                {
                    continue;
                }

                string controlName = string.IsNullOrWhiteSpace(control.name) ? "(Unnamed)" : control.name;
                string controlPath = $"{path}/{controlName}";
                if (ControlOrSubtreeHasConflict(controlPath, control, new HashSet<VRCExpressionsMenu>()))
                {
                    ExpandConflictInspectorMenus(control.subMenu, controlPath, visited);
                }
            }
        }

        private bool ControlOrSubtreeHasConflict(string controlPath, VRCExpressionsMenu.Control control, HashSet<VRCExpressionsMenu> visited)
        {
            if (controlIndexByPath.TryGetValue(controlPath, out int itemIndex)
                && itemIndex >= 0
                && itemIndex < controls.Count
                && controls[itemIndex].Conflicts.Count > 0)
            {
                return true;
            }

            if (control == null || control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null || !visited.Add(control.subMenu))
            {
                return false;
            }

            EnsureMenuControlList(control.subMenu);
            foreach (VRCExpressionsMenu.Control child in control.subMenu.controls)
            {
                string childName = string.IsNullOrWhiteSpace(child.name) ? "(Unnamed)" : child.name;
                if (ControlOrSubtreeHasConflict($"{controlPath}/{childName}", child, visited))
                {
                    return true;
                }
            }

            return false;
        }

        private void SelectFirstVisibleConflict()
        {
            if (selectedIndex >= 0 && selectedIndex < controls.Count && controls[selectedIndex].Conflicts.Count > 0)
            {
                return;
            }

            selectedIndex = controls.FindIndex(control => control.Conflicts.Count > 0);
        }

        private static string GetConfidence(InspectedControl item, HashSet<string> actionBuilderParameters)
        {
            if (item.Type == VRCExpressionsMenu.Control.ControlType.SubMenu && item.Submenu == null)
            {
                return "Missing Asset";
            }

            if (item.ParameterNames.Count == 0)
            {
                return "No Parameter";
            }

            if (item.ParameterNames.Any(actionBuilderParameters.Contains)
                || item.ParameterNames.Any(IsLikelyActionBuilderGeneratedParameter))
            {
                return "Action Builder";
            }

            if (item.ParameterNames.Count > 1)
            {
                return "Complex";
            }

            return item.MatchedLayers.Count > 0 ? "Likely Manual" : "Untraced";
        }

        private static bool IsLikelyActionBuilderGeneratedParameter(string parameterName)
        {
            if (string.IsNullOrWhiteSpace(parameterName)
                || !parameterName.StartsWith("Puddles/Action/", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            int underscoreIndex = parameterName.LastIndexOf('_');
            if (underscoreIndex < 0 || underscoreIndex + 13 != parameterName.Length)
            {
                return false;
            }

            for (int i = underscoreIndex + 1; i < parameterName.Length; i++)
            {
                char c = parameterName[i];
                bool hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
                if (!hex)
                {
                    return false;
                }
            }

            return true;
        }

        private IEnumerable<VRCExpressionParameters.Parameter> FindExpressionParameters(IEnumerable<string> parameterNames)
        {
            if (expressionParameters == null || expressionParameters.parameters == null)
            {
                yield break;
            }

            HashSet<string> names = new HashSet<string>(parameterNames, StringComparer.OrdinalIgnoreCase);
            foreach (VRCExpressionParameters.Parameter parameter in expressionParameters.parameters)
            {
                if (parameter != null && names.Contains(parameter.name))
                {
                    yield return parameter;
                }
            }
        }

        private IEnumerable<AnimatorControllerParameter> FindAnimatorParameters(IEnumerable<string> parameterNames)
        {
            if (fxController == null)
            {
                yield break;
            }

            HashSet<string> names = new HashSet<string>(parameterNames, StringComparer.OrdinalIgnoreCase);
            foreach (AnimatorControllerParameter parameter in fxController.parameters)
            {
                if (parameter != null && names.Contains(parameter.name))
                {
                    yield return parameter;
                }
            }
        }

        private IEnumerable<AnimatorControllerLayer> FindLayersUsingParameter(string parameterName)
        {
            if (string.IsNullOrWhiteSpace(parameterName) || fxController == null)
            {
                yield break;
            }

            foreach (AnimatorControllerLayer layer in fxController.layers)
            {
                if (LayerUsesParameter(layer, parameterName))
                {
                    yield return layer;
                }
            }
        }

        private static string GetLayerMatchReason(AnimatorControllerLayer layer, List<string> parameterNames)
        {
            if (layer == null || layer.stateMachine == null || parameterNames == null)
            {
                return "unknown";
            }

            foreach (string parameterName in parameterNames)
            {
                if (StateMachineUsesTransitionParameter(layer.stateMachine, parameterName, new HashSet<AnimatorStateMachine>()))
                {
                    return "transition condition";
                }

                if (StateMachineUsesStateParameter(layer.stateMachine, parameterName, new HashSet<AnimatorStateMachine>()))
                {
                    return "state parameter";
                }

                if (StateMachineUsesMotionParameter(layer.stateMachine, parameterName, new HashSet<AnimatorStateMachine>(), new HashSet<Motion>()))
                {
                    return "blend tree";
                }
            }

            return "parameter reference";
        }

        private static bool LayerUsesParameter(AnimatorControllerLayer layer, string parameterName)
        {
            return layer != null
                && layer.stateMachine != null
                && StateMachineUsesParameter(layer.stateMachine, parameterName, new HashSet<AnimatorStateMachine>(), new HashSet<Motion>());
        }

        private static bool StateMachineUsesParameter(AnimatorStateMachine stateMachine, string parameterName, HashSet<AnimatorStateMachine> visited, HashSet<Motion> visitedMotions)
        {
            return StateMachineUsesTransitionParameter(stateMachine, parameterName, visited)
                || StateMachineUsesStateParameter(stateMachine, parameterName, new HashSet<AnimatorStateMachine>())
                || StateMachineUsesMotionParameter(stateMachine, parameterName, new HashSet<AnimatorStateMachine>(), visitedMotions);
        }

        private static bool StateMachineUsesTransitionParameter(AnimatorStateMachine stateMachine, string parameterName, HashSet<AnimatorStateMachine> visited)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return false;
            }

            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
            {
                if (TransitionUsesParameter(transition, parameterName))
                {
                    return true;
                }
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state == null)
                {
                    continue;
                }

                foreach (AnimatorStateTransition transition in childState.state.transitions)
                {
                    if (TransitionUsesParameter(transition, parameterName))
                    {
                        return true;
                    }
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                if (StateMachineUsesTransitionParameter(childMachine.stateMachine, parameterName, visited))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool StateMachineUsesStateParameter(AnimatorStateMachine stateMachine, string parameterName, HashSet<AnimatorStateMachine> visited)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return false;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (AnimatorStateUsesParameter(childState.state, parameterName))
                {
                    return true;
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                if (StateMachineUsesStateParameter(childMachine.stateMachine, parameterName, visited))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool StateMachineUsesMotionParameter(AnimatorStateMachine stateMachine, string parameterName, HashSet<AnimatorStateMachine> visited, HashSet<Motion> visitedMotions)
        {
            if (stateMachine == null || !visited.Add(stateMachine))
            {
                return false;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state != null && MotionUsesParameter(childState.state.motion, parameterName, visitedMotions))
                {
                    return true;
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                if (StateMachineUsesMotionParameter(childMachine.stateMachine, parameterName, visited, visitedMotions))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool TransitionUsesParameter(AnimatorStateTransition transition, string parameterName)
        {
            return transition != null
                && transition.conditions.Any(condition => string.Equals(condition.parameter, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private static bool AnimatorStateUsesParameter(AnimatorState state, string parameterName)
        {
            if (state == null || string.IsNullOrWhiteSpace(parameterName))
            {
                return false;
            }

            return (state.timeParameterActive && string.Equals(state.timeParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                || (state.speedParameterActive && string.Equals(state.speedParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                || (state.cycleOffsetParameterActive && string.Equals(state.cycleOffsetParameter, parameterName, StringComparison.OrdinalIgnoreCase))
                || (state.mirrorParameterActive && string.Equals(state.mirrorParameter, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private static bool MotionUsesParameter(Motion motion, string parameterName, HashSet<Motion> visited)
        {
            if (motion == null || !visited.Add(motion))
            {
                return false;
            }

            if (motion is BlendTree blendTree)
            {
                if (string.Equals(blendTree.blendParameter, parameterName, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(blendTree.blendParameterY, parameterName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                foreach (ChildMotion child in blendTree.children)
                {
                    if (MotionUsesParameter(child.motion, parameterName, visited))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static IEnumerable<AnimationClip> CollectLayerClips(AnimatorControllerLayer layer)
        {
            if (layer == null || layer.stateMachine == null)
            {
                yield break;
            }

            foreach (AnimationClip clip in CollectStateMachineClips(layer.stateMachine, new HashSet<AnimatorStateMachine>(), new HashSet<Motion>()))
            {
                yield return clip;
            }
        }

        private static IEnumerable<AnimationClip> CollectStateMachineClips(AnimatorStateMachine stateMachine, HashSet<AnimatorStateMachine> visitedMachines, HashSet<Motion> visitedMotions)
        {
            if (stateMachine == null || !visitedMachines.Add(stateMachine))
            {
                yield break;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state == null || childState.state.motion == null)
                {
                    continue;
                }

                foreach (AnimationClip clip in CollectMotionClips(childState.state.motion, visitedMotions))
                {
                    yield return clip;
                }
            }

            foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
            {
                foreach (AnimationClip clip in CollectStateMachineClips(childMachine.stateMachine, visitedMachines, visitedMotions))
                {
                    yield return clip;
                }
            }
        }

        private static IEnumerable<AnimationClip> CollectMotionClips(Motion motion, HashSet<Motion> visited)
        {
            if (motion == null || !visited.Add(motion))
            {
                yield break;
            }

            if (motion is AnimationClip clip)
            {
                yield return clip;
                yield break;
            }

            if (motion is BlendTree blendTree)
            {
                foreach (ChildMotion child in blendTree.children)
                {
                    foreach (AnimationClip childClip in CollectMotionClips(child.motion, visited))
                    {
                        yield return childClip;
                    }
                }
            }
        }

        private static IEnumerable<AnimatedBindingInfo> CollectClipAnimatedBindings(AnimationClip clip)
        {
            if (clip == null)
            {
                yield break;
            }

            foreach (EditorCurveBinding binding in AnimationUtility.GetCurveBindings(clip))
            {
                yield return BuildAnimatedBindingInfo(binding);
            }

            foreach (EditorCurveBinding binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
            {
                yield return BuildAnimatedBindingInfo(binding);
            }
        }

        private static AnimatedBindingInfo BuildAnimatedBindingInfo(EditorCurveBinding binding)
        {
            string path = string.IsNullOrWhiteSpace(binding.path) ? "(Avatar Root)" : binding.path;
            string type = binding.type != null ? binding.type.Name : "Unknown";
            string typeKey = binding.type != null ? binding.type.FullName : "Unknown";
            string propertyName = string.IsNullOrWhiteSpace(binding.propertyName) ? "(Unknown Property)" : binding.propertyName.Trim();
            return new AnimatedBindingInfo
            {
                Key = $"{path}|{typeKey}|{propertyName}",
                Label = $"{path} : {type}.{propertyName}"
            };
        }

        private static List<string> GetMenuControlParameterNames(VRCExpressionsMenu.Control control)
        {
            List<string> names = new List<string>();
            if (control == null)
            {
                return names;
            }

            if (control.parameter != null && !string.IsNullOrWhiteSpace(control.parameter.name))
            {
                names.Add(control.parameter.name);
            }

            if (control.subParameters != null)
            {
                foreach (VRCExpressionsMenu.Control.Parameter parameter in control.subParameters)
                {
                    if (parameter != null && !string.IsNullOrWhiteSpace(parameter.name))
                    {
                        names.Add(parameter.name);
                    }
                }
            }

            return names;
        }

        private static void EnsureMenuControlList(VRCExpressionsMenu menu)
        {
            if (menu != null && menu.controls == null)
            {
                menu.controls = new List<VRCExpressionsMenu.Control>();
            }
        }

        private sealed class InspectedControl
        {
            public string Name;
            public VRCExpressionsMenu.Control.ControlType Type;
            public string TypeLabel;
            public string RadialModeLabel;
            public string MenuPath;
            public string Confidence;
            public VRCExpressionsMenu ParentMenu;
            public VRCExpressionsMenu.Control MenuControl;
            public VRCExpressionsMenu Submenu;
            public List<string> ParameterNames = new List<string>();
            public List<VRCExpressionParameters.Parameter> ExpressionParameters = new List<VRCExpressionParameters.Parameter>();
            public List<AnimatorControllerParameter> AnimatorParameters = new List<AnimatorControllerParameter>();
            public List<AnimatorControllerLayer> MatchedLayers = new List<AnimatorControllerLayer>();
            public Dictionary<AnimatorControllerLayer, string> LayerMatchReasons = new Dictionary<AnimatorControllerLayer, string>();
            public List<AnimationClip> Clips = new List<AnimationClip>();
            public List<AnimatedBindingInfo> AnimatedBindings = new List<AnimatedBindingInfo>();
            public List<string> AnimatedProperties = new List<string>();
            public List<BindingConflictInfo> Conflicts = new List<BindingConflictInfo>();
        }

        private sealed class ImportPreview
        {
            public InspectedControl Source;
            public string ParameterName;
            public bool Supported;
            public PuddlesAvatarControlType ControlType = PuddlesAvatarControlType.Toggle;
            public PuddlesAvatarRadialMode RadialMode = PuddlesAvatarRadialMode.TimeParameter;
            public bool Saved = true;
            public bool Synced = true;
            public bool DefaultValue;
            public float RadialDefaultValue;
            public string BlockReason;
            public List<PuddlesAvatarActionRow> ImportedRows = new List<PuddlesAvatarActionRow>();
            public List<ImportedActionPreview> Actions = new List<ImportedActionPreview>();
            public List<string> UnsupportedBindings = new List<string>();
            public List<string> Warnings = new List<string>();

            public bool CanImport => Supported && Source != null && ImportedRows.Count > 0 && UnsupportedBindings.Count == 0;
        }

        private sealed class ImportedActionPreview
        {
            public string Summary;
        }

        private sealed class ImportedBindingValue
        {
            public string Key;
            public string Label;
            public string Path;
            public ImportedBindingKind Kind;
            public float FloatValue;
            public Material MaterialValue;
            public UnityEngine.Object ObjectReferenceValue;
            public int MaterialSlot;
            public string BlendshapeName;
            public string ShaderPropertyName;
            public string ComponentTypeName;
            public string ComponentTypeDisplayName;
            public string RawBindingTypeName;
            public string RawBindingPropertyName;
            public PuddlesAvatarRawBindingValueKind RawBindingValueKind;

            public static ImportedBindingValue ForFloat(ImportedBindingKind kind, EditorCurveBinding binding, float value)
            {
                ImportedBindingValue imported = FromBinding(kind, binding);
                imported.FloatValue = value;
                return imported;
            }

            public static ImportedBindingValue ForMaterial(EditorCurveBinding binding, Material material)
            {
                ImportedBindingValue imported = FromBinding(ImportedBindingKind.MaterialSwap, binding);
                imported.MaterialValue = material;
                return imported;
            }

            public static ImportedBindingValue ForRawFloat(EditorCurveBinding binding, float value)
            {
                ImportedBindingValue imported = FromBinding(ImportedBindingKind.RawBinding, binding);
                imported.RawBindingTypeName = binding.type.AssemblyQualifiedName;
                imported.RawBindingPropertyName = binding.propertyName;
                imported.RawBindingValueKind = PuddlesAvatarRawBindingValueKind.Float;
                imported.FloatValue = value;
                return imported;
            }

            public static ImportedBindingValue ForRawObjectReference(EditorCurveBinding binding, UnityEngine.Object objectReference)
            {
                ImportedBindingValue imported = FromBinding(ImportedBindingKind.RawBinding, binding);
                imported.RawBindingTypeName = binding.type.AssemblyQualifiedName;
                imported.RawBindingPropertyName = binding.propertyName;
                imported.RawBindingValueKind = PuddlesAvatarRawBindingValueKind.ObjectReference;
                imported.ObjectReferenceValue = objectReference;
                return imported;
            }

            public bool HasSameValue(ImportedBindingValue other)
            {
                if (other == null || Kind != other.Kind)
                {
                    return false;
                }

                if (Kind == ImportedBindingKind.MaterialSwap)
                {
                    return MaterialValue == other.MaterialValue;
                }

                if (Kind == ImportedBindingKind.RawBinding && RawBindingValueKind == PuddlesAvatarRawBindingValueKind.ObjectReference)
                {
                    return other.RawBindingValueKind == PuddlesAvatarRawBindingValueKind.ObjectReference
                        && ObjectReferenceValue == other.ObjectReferenceValue;
                }

                if (Kind == ImportedBindingKind.RawBinding && other.RawBindingValueKind != RawBindingValueKind)
                {
                    return false;
                }

                return Mathf.Approximately(FloatValue, other.FloatValue);
            }

            private static ImportedBindingValue FromBinding(ImportedBindingKind kind, EditorCurveBinding binding)
            {
                AnimatedBindingInfo info = AvatarActionControlInspectorWindow.BuildAnimatedBindingInfo(binding);
                return new ImportedBindingValue
                {
                    Kind = kind,
                    Key = info.Key,
                    Label = info.Label,
                    Path = string.IsNullOrWhiteSpace(binding.path) ? "(Avatar Root)" : binding.path
                };
            }
        }

        private enum ImportedBindingKind
        {
            ObjectState,
            Blendshape,
            MaterialSwap,
            ShaderFloat,
            ComponentEnabled,
            RawBinding
        }

        private sealed class AnimatedBindingInfo
        {
            public string Key;
            public string Label;
        }

        private sealed class BindingConflictInfo
        {
            public AnimatedBindingInfo Binding;
            public List<InspectedControl> OtherControls = new List<InspectedControl>();
        }

        private sealed class BindingConflictMember
        {
            public InspectedControl Control;
            public AnimatedBindingInfo Binding;
        }
    }

#endif

    internal sealed class CleanupAssetCandidate
    {
        public string Path;
        public string Kind;
        public bool DefaultSelected;
        public bool Selected;
        public bool Shared;
    }

    internal sealed class AvatarActionCleanupDeleteWindow : EditorWindow
    {
        private string targetName;
        private Action<List<string>> onConfirm;
        private Vector2 scroll;
        private List<CleanupAssetCandidate> candidates = new List<CleanupAssetCandidate>();

        public static void Open(string targetName, List<CleanupAssetCandidate> candidates, Action<List<string>> onConfirm)
        {
            AvatarActionCleanupDeleteWindow window = GetWindow<AvatarActionCleanupDeleteWindow>("Delete Traced Assets");
            window.targetName = targetName;
            window.candidates = candidates != null ? candidates.Select(CloneCandidate).ToList() : new List<CleanupAssetCandidate>();
            window.onConfirm = onConfirm;
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Delete From Project", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(targetName ?? "(Unknown)", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.HelpBox("Checked assets will be deleted from the project after avatar menu/parameter/controller references are removed. Manual or shared assets are left unchecked by default.", MessageType.Warning);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Select Generated"))
                {
                    foreach (CleanupAssetCandidate candidate in candidates)
                    {
                        candidate.Selected = candidate.DefaultSelected;
                    }
                }

                if (GUILayout.Button("Select None"))
                {
                    foreach (CleanupAssetCandidate candidate in candidates)
                    {
                        candidate.Selected = false;
                    }
                }
            }

            scroll = EditorGUILayout.BeginScrollView(scroll, EditorStyles.helpBox);
            foreach (CleanupAssetCandidate candidate in candidates)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    candidate.Selected = EditorGUILayout.Toggle(candidate.Selected, GUILayout.Width(20));
                    string shared = candidate.Shared ? " [Shared]" : string.Empty;
                    EditorGUILayout.LabelField($"{candidate.Kind}{shared}: {candidate.Path}", EditorStyles.wordWrappedMiniLabel);
                }
            }

            EditorGUILayout.EndScrollView();

            int selectedCount = candidates.Count(candidate => candidate.Selected);
            using (new EditorGUI.DisabledScope(selectedCount == 0))
            {
                if (GUILayout.Button($"Delete {selectedCount} Checked Asset(s)", GUILayout.Height(28)))
                {
                    if (EditorUtility.DisplayDialog("Delete From Project", $"Delete {selectedCount} checked project asset(s)?", "Delete", "Cancel"))
                    {
                        onConfirm?.Invoke(candidates.Where(candidate => candidate.Selected).Select(candidate => candidate.Path).ToList());
                        Close();
                    }
                }
            }
        }

        private static CleanupAssetCandidate CloneCandidate(CleanupAssetCandidate candidate)
        {
            return new CleanupAssetCandidate
            {
                Path = candidate.Path,
                Kind = candidate.Kind,
                DefaultSelected = candidate.DefaultSelected,
                Selected = candidate.Selected,
                Shared = candidate.Shared
            };
        }
    }

    public sealed class AvatarActionMenuSelectorWindow : EditorWindow
    {
        private const int MaxControlsPerMenu = 8;

        private PuddlesAvatarActionProfile profile;
        private string selectedControlId;
        private VRCExpressionsMenu selectedMenu;
        private string selectedPath = "Root";
        private string newSubmenuName = "New Submenu";
        private string renameSubmenuName = string.Empty;
        private Vector2 treeScroll;
        private readonly HashSet<string> expandedPaths = new HashSet<string>();

        public static void Open(PuddlesAvatarActionProfile profile, string selectedControlId)
        {
            AvatarActionMenuSelectorWindow window = GetWindow<AvatarActionMenuSelectorWindow>("Choose Toggle Destination");
            window.profile = profile;
            window.selectedControlId = selectedControlId;

            PuddlesAvatarActionControl control = window.GetSelectedControl();
            window.selectedMenu = control != null && control.destinationMenu != null
                ? control.destinationMenu
                : (profile != null ? profile.rootMenu : null);
            window.selectedPath = control != null && !string.IsNullOrWhiteSpace(control.destinationPath) ? control.destinationPath : "Root";
            window.renameSubmenuName = window.GetEditableMenuName(window.selectedMenu, window.selectedPath);
            window.expandedPaths.Clear();
            window.expandedPaths.Add("Root");
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Choose Toggle Destination", EditorStyles.boldLabel);
            if (profile == null || profile.rootMenu == null)
            {
                EditorGUILayout.HelpBox("Assign a profile with a root expression menu first.", MessageType.Warning);
                return;
            }

            if (profile.controls == null)
            {
                profile.controls = new List<PuddlesAvatarActionControl>();
            }

            if (profile.managedSubmenus == null)
            {
                profile.managedSubmenus = new List<PuddlesAvatarManagedSubmenu>();
            }

            expandedPaths.Add("Root");
            EditorGUILayout.LabelField("Selected", selectedPath);
            treeScroll = EditorGUILayout.BeginScrollView(treeScroll, EditorStyles.helpBox);
            DrawMenuNode(profile.rootMenu, "Root", 0, new HashSet<VRCExpressionsMenu>());
            EditorGUILayout.EndScrollView();

            using (new EditorGUI.DisabledScope(selectedMenu == null || GetSelectedControl() == null))
            {
                if (GUILayout.Button("Use This Menu", GUILayout.Height(30)))
                {
                    UseSelectedMenu();
                }
            }

            EditorGUILayout.Space();
            DrawRenameDeleteSubmenu();
            EditorGUILayout.Space();
            DrawCreateSubmenu();
        }

        private void DrawRenameDeleteSubmenu()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Edit Selected Submenu", EditorStyles.boldLabel);
                bool canEdit = IsManaged(selectedMenu);
                using (new EditorGUI.DisabledScope(!canEdit))
                {
                    renameSubmenuName = EditorGUILayout.TextField("Name", string.IsNullOrWhiteSpace(renameSubmenuName) ? GetEditableMenuName(selectedMenu, selectedPath) : renameSubmenuName);
                    if (GUILayout.Button("Rename Submenu"))
                    {
                        RenameSelectedManagedSubmenu();
                    }

                    GUI.backgroundColor = new Color(1f, 0.55f, 0.55f);
                    if (GUILayout.Button("Delete Submenu And Contents"))
                    {
                        DeleteSelectedManagedSubmenu();
                    }

                    GUI.backgroundColor = Color.white;
                }

                if (!canEdit)
                {
                    EditorGUILayout.LabelField("Only Action Builder-managed submenus can be renamed or deleted here.", EditorStyles.wordWrappedMiniLabel);
                }
            }
        }

        private void DrawCreateSubmenu()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Create Submenu Here", EditorStyles.boldLabel);
                newSubmenuName = EditorGUILayout.TextField("Name", newSubmenuName);

                using (new EditorGUI.DisabledScope(selectedMenu == null || string.IsNullOrWhiteSpace(newSubmenuName)))
                {
                    if (GUILayout.Button("Create And Select Submenu"))
                    {
                        CreateAndSelectManagedSubmenu();
                    }
                }
            }
        }

        private void DrawMenuNode(VRCExpressionsMenu menu, string path, int depth, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            List<VRCExpressionsMenu.Control> childMenus = menu.controls
                .Where(control => control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                .ToList();
            bool hasChildren = childMenus.Count > 0;
            bool expanded = expandedPaths.Contains(path);
            bool managed = profile.managedSubmenus.Any(record => record != null && record.menu == menu);

            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(depth * 16);
                using (new EditorGUI.DisabledScope(!hasChildren))
                {
                    if (GUILayout.Button(hasChildren ? (expanded ? "v" : ">") : " ", GUILayout.Width(24)))
                    {
                        if (expanded)
                        {
                            expandedPaths.Remove(path);
                        }
                        else
                        {
                            expandedPaths.Add(path);
                        }
                    }
                }

                GUIStyle style = selectedMenu == menu ? EditorStyles.toolbarButton : GUI.skin.button;
                string label = path.Split('/').Last();
                if (GUILayout.Button($"{label} {BuildMenuFlags(menu, managed)}", style))
                {
                    SelectMenu(menu, path);
                }
            }

            if (!expanded)
            {
                return;
            }

            foreach (VRCExpressionsMenu.Control control in childMenus)
            {
                DrawMenuNode(control.subMenu, $"{path}/{control.name}", depth + 1, visited);
            }
        }

        private void UseSelectedMenu()
        {
            PuddlesAvatarActionControl control = GetSelectedControl();
            if (control == null || selectedMenu == null)
            {
                return;
            }

            control.destinationMenu = selectedMenu;
            control.destinationPath = selectedPath;
            profile.lastDestinationMenu = selectedMenu;
            profile.lastDestinationPath = selectedPath;
            EditorUtility.SetDirty(profile);
            Close();
        }

        private void CreateAndSelectManagedSubmenu()
        {
            if (profile == null || selectedMenu == null)
            {
                return;
            }

            EnsureMenuControlList(selectedMenu);
            if (selectedMenu.controls.Count >= MaxControlsPerMenu)
            {
                EditorUtility.DisplayDialog("Choose Toggle Destination", "The selected menu is full.", "OK");
                return;
            }

            string displayName = TruncateMenuName(newSubmenuName.Trim());
            VRCExpressionsMenu parentMenu = selectedMenu;
            string parentPath = selectedPath;
            EnsureFolder(GetProfileGenerationFolder(profile));
            string assetPath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(GetProfileGenerationFolder(profile), $"{SanitizeAssetName(displayName)} Menu.asset").Replace("\\", "/"));
            VRCExpressionsMenu submenu = CreateInstance<VRCExpressionsMenu>();
            EnsureMenuControlList(submenu);
            AssetDatabase.CreateAsset(submenu, assetPath);

            parentMenu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = displayName,
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = submenu
            });

            string submenuPath = $"{parentPath}/{displayName}";
            profile.managedSubmenus.Add(new PuddlesAvatarManagedSubmenu
            {
                id = CreateStableId(),
                displayName = displayName,
                parentMenu = parentMenu,
                menu = submenu,
                path = submenuPath
            });

            selectedMenu = submenu;
            selectedPath = submenuPath;
            profile.lastDestinationMenu = submenu;
            profile.lastDestinationPath = submenuPath;
            expandedPaths.Add(parentPath);
            expandedPaths.Add(submenuPath);
            newSubmenuName = "New Submenu";
            renameSubmenuName = displayName;

            EditorUtility.SetDirty(profile);
            EditorUtility.SetDirty(parentMenu);
            EditorUtility.SetDirty(submenu);
            AssetDatabase.SaveAssets();
            Repaint();
        }

        private void SelectMenu(VRCExpressionsMenu menu, string path)
        {
            selectedMenu = menu;
            selectedPath = string.IsNullOrWhiteSpace(path) ? "Root" : path;
            renameSubmenuName = GetEditableMenuName(selectedMenu, selectedPath);
        }

        private void RenameSelectedManagedSubmenu()
        {
            PuddlesAvatarManagedSubmenu record = GetManagedRecord(selectedMenu);
            if (record == null || record.parentMenu == null || selectedMenu == null)
            {
                return;
            }

            string displayName = TruncateMenuName(renameSubmenuName.Trim());
            if (string.IsNullOrWhiteSpace(displayName))
            {
                return;
            }

            EnsureMenuControlList(record.parentMenu);
            VRCExpressionsMenu.Control parentControl = record.parentMenu.controls.FirstOrDefault(control =>
                control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                && control.subMenu == selectedMenu);
            if (parentControl != null)
            {
                parentControl.name = displayName;
                EditorUtility.SetDirty(record.parentMenu);
            }

            record.displayName = displayName;
            RefreshMenuPathCaches();
            selectedPath = AvatarActionMenuManagerWindow.FindMenuPath(profile.rootMenu, selectedMenu, "Root", new HashSet<VRCExpressionsMenu>());
            if (string.IsNullOrWhiteSpace(selectedPath))
            {
                selectedPath = "Root";
            }

            renameSubmenuName = displayName;
            expandedPaths.Add(GetParentPath(selectedPath));
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            Repaint();
        }

        private void DeleteSelectedManagedSubmenu()
        {
            PuddlesAvatarManagedSubmenu record = GetManagedRecord(selectedMenu);
            if (record == null || selectedMenu == null)
            {
                return;
            }

            HashSet<VRCExpressionsMenu> subtree = AvatarActionMenuManagerWindow.CollectMenuSubtree(selectedMenu, new HashSet<VRCExpressionsMenu>());
            HashSet<string> ownedParameters = new HashSet<string>(
                profile.controls.SelectMany(control => AvatarActionMenuManagerWindow.BuildParameterNames(profile, control)),
                StringComparer.OrdinalIgnoreCase);

            if (HasNonOwnedControls(selectedMenu, ownedParameters, new HashSet<VRCExpressionsMenu>()))
            {
                EditorUtility.DisplayDialog(
                    "Cannot Safely Delete Submenu",
                    "This submenu contains manual or non-Action-Builder controls. The picker can only delete submenus whose contents are fully managed, because it must also remove the associated avatar pieces like expression parameters and FX layers.",
                    "OK");
                return;
            }

            List<PuddlesAvatarActionControl> controlsToDelete = profile.controls
                .Where(control => control != null && control.destinationMenu != null && subtree.Contains(control.destinationMenu))
                .ToList();
            int totalMenuItems = CountMenuControls(subtree);
            int childSubmenus = Mathf.Max(0, subtree.Count - 1);
            string displayName = string.IsNullOrWhiteSpace(record.displayName) ? GetEditableMenuName(selectedMenu, selectedPath) : record.displayName;

            if (totalMenuItems > 0 || childSubmenus > 0 || controlsToDelete.Count > 0)
            {
                string warning =
                    $"The submenu '{displayName}' contains {totalMenuItems} menu item(s), {childSubmenus} child submenu(s), and {controlsToDelete.Count} Action Builder control(s).\n\n" +
                    "Deleting it will delete the submenu, everything inside it, and associated avatar pieces for those controls, including menu entries, expression parameters, FX parameters/layers, and generated clips/assets.\n\n" +
                    "Continue?";
                if (!EditorUtility.DisplayDialog("Delete Submenu Contents?", warning, "Continue", "Cancel"))
                {
                    return;
                }
            }

            string finalWarning =
                $"FINAL WARNING: Delete '{displayName}'?\n\n" +
                "This action will delete the submenu and all associated avatar pieces for the Action Builder controls inside it. This cannot be undone except from a backup or version control.";
            if (!EditorUtility.DisplayDialog("Delete Submenu And Avatar Pieces", finalWarning, "Delete Everything", "Cancel"))
            {
                return;
            }

            foreach (PuddlesAvatarActionControl control in controlsToDelete)
            {
                AvatarActionMenuManagerWindow.DeleteControlArtifacts(profile, control);
                profile.controls.Remove(control);
            }

            AvatarActionMenuManagerWindow.RemoveSubmenuEntry(record.parentMenu, selectedMenu);
            foreach (PuddlesAvatarManagedSubmenu managed in profile.managedSubmenus
                .Where(menu => menu != null && menu.menu != null && subtree.Contains(menu.menu))
                .ToList())
            {
                string assetPath = AssetDatabase.GetAssetPath(managed.menu);
                if (!string.IsNullOrWhiteSpace(assetPath))
                {
                    AssetDatabase.DeleteAsset(assetPath);
                }

                profile.managedSubmenus.Remove(managed);
            }

            if (profile.lastDestinationMenu != null && subtree.Contains(profile.lastDestinationMenu))
            {
                profile.lastDestinationMenu = profile.rootMenu;
                profile.lastDestinationPath = "Root";
            }

            SelectMenu(profile.rootMenu, "Root");
            RefreshMenuPathCaches();
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Repaint();
        }

        private PuddlesAvatarActionControl GetSelectedControl()
        {
            return profile == null || profile.controls == null
                ? null
                : profile.controls.FirstOrDefault(control => control.id == selectedControlId);
        }

        private bool IsManaged(VRCExpressionsMenu menu)
        {
            return menu != null
                && profile != null
                && profile.managedSubmenus != null
                && profile.managedSubmenus.Any(record => record != null && record.menu == menu);
        }

        private PuddlesAvatarManagedSubmenu GetManagedRecord(VRCExpressionsMenu menu)
        {
            return profile == null || profile.managedSubmenus == null
                ? null
                : profile.managedSubmenus.FirstOrDefault(record => record != null && record.menu == menu);
        }

        private string GetEditableMenuName(VRCExpressionsMenu menu, string path)
        {
            PuddlesAvatarManagedSubmenu record = GetManagedRecord(menu);
            if (record != null && !string.IsNullOrWhiteSpace(record.displayName))
            {
                return record.displayName;
            }

            return string.IsNullOrWhiteSpace(path) ? "Root" : path.Split('/').Last();
        }

        private void RefreshMenuPathCaches()
        {
            if (profile == null)
            {
                return;
            }

            foreach (PuddlesAvatarManagedSubmenu managed in profile.managedSubmenus)
            {
                if (managed == null || managed.menu == null)
                {
                    continue;
                }

                string path = AvatarActionMenuManagerWindow.FindMenuPath(profile.rootMenu, managed.menu, "Root", new HashSet<VRCExpressionsMenu>());
                if (!string.IsNullOrWhiteSpace(path))
                {
                    managed.path = path;
                }
            }

            foreach (PuddlesAvatarActionControl control in profile.controls)
            {
                if (control == null || control.destinationMenu == null)
                {
                    continue;
                }

                string path = AvatarActionMenuManagerWindow.FindMenuPath(profile.rootMenu, control.destinationMenu, "Root", new HashSet<VRCExpressionsMenu>());
                if (!string.IsNullOrWhiteSpace(path))
                {
                    control.destinationPath = path;
                }
            }

            if (profile.lastDestinationMenu != null)
            {
                string path = AvatarActionMenuManagerWindow.FindMenuPath(profile.rootMenu, profile.lastDestinationMenu, "Root", new HashSet<VRCExpressionsMenu>());
                if (!string.IsNullOrWhiteSpace(path))
                {
                    profile.lastDestinationPath = path;
                }
            }
        }

        private bool HasNonOwnedControls(VRCExpressionsMenu menu, HashSet<string> ownedParameters, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu))
            {
                return false;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    if (control.subMenu != null && !IsManaged(control.subMenu) && control.subMenu != selectedMenu)
                    {
                        return true;
                    }

                    if (HasNonOwnedControls(control.subMenu, ownedParameters, visited))
                    {
                        return true;
                    }

                    continue;
                }

                string parameterName = GetMenuControlParameterName(control);
                if (string.IsNullOrWhiteSpace(parameterName) || !ownedParameters.Contains(parameterName))
                {
                    return true;
                }
            }

            return false;
        }

        private static string GetMenuControlParameterName(VRCExpressionsMenu.Control control)
        {
            if (control == null)
            {
                return string.Empty;
            }

            if (control.parameter != null && !string.IsNullOrWhiteSpace(control.parameter.name))
            {
                return control.parameter.name;
            }

            if (control.subParameters != null)
            {
                foreach (VRCExpressionsMenu.Control.Parameter subParameter in control.subParameters)
                {
                    if (subParameter != null && !string.IsNullOrWhiteSpace(subParameter.name))
                    {
                        return subParameter.name;
                    }
                }
            }

            return string.Empty;
        }

        private static int CountMenuControls(HashSet<VRCExpressionsMenu> menus)
        {
            int count = 0;
            foreach (VRCExpressionsMenu menu in menus)
            {
                EnsureMenuControlList(menu);
                count += menu.controls.Count;
            }

            return count;
        }

        private static string GetParentPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !path.Contains("/"))
            {
                return "Root";
            }

            return path.Substring(0, path.LastIndexOf("/", StringComparison.Ordinal));
        }

        private static string BuildMenuFlags(VRCExpressionsMenu menu, bool managed)
        {
            EnsureMenuControlList(menu);
            List<string> flags = new List<string> { managed ? "Managed" : "Existing" };
            if (menu != null && menu.controls.Count >= MaxControlsPerMenu)
            {
                flags.Add("Full");
            }

            return $"[{string.Join(", ", flags)}]";
        }

        private static void EnsureMenuControlList(VRCExpressionsMenu menu)
        {
            if (menu != null && menu.controls == null)
            {
                menu.controls = new List<VRCExpressionsMenu.Control>();
            }
        }

        private static string GetProfileGenerationFolder(PuddlesAvatarActionProfile profile)
        {
            string outputFolder = string.IsNullOrWhiteSpace(profile.outputFolder) ? "Assets/PuddlesVrcTools/Generated/AvatarActions" : profile.outputFolder.Trim();
            return Path.Combine(outputFolder, SanitizeAssetName(profile.name)).Replace("\\", "/");
        }

        private static string SanitizeAssetName(string value)
        {
            string cleaned = string.Join("_", (value ?? "Asset").Split(Path.GetInvalidFileNameChars()));
            return string.IsNullOrWhiteSpace(cleaned) ? "Asset" : cleaned;
        }

        private static string TruncateMenuName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "Menu";
            }

            return value.Length <= 32 ? value : value.Substring(0, 32);
        }

        private static void EnsureFolder(string folder)
        {
            string normalized = folder.Replace("\\", "/").Trim('/');
            if (AssetDatabase.IsValidFolder(normalized))
            {
                return;
            }

            string[] parts = normalized.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = $"{current}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                current = next;
            }
        }

        private static string CreateStableId()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 12);
        }
    }

}
#endif
