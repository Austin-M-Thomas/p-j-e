#if UNITY_EDITOR && PUDDLES_EXPERIMENTAL_TOOLS
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace PuddlesVrcTools.Editor
{
    public sealed class ModularAvatarInspectorWindow : EditorWindow
    {
        private const string AvatarRootToken = "$$$AVATAR_ROOT$$$";

        private GameObject avatarRoot;
        private string searchText = string.Empty;
        private bool showMenus = true;
        private bool showParameters = true;
        private bool showAnimators = true;
        private bool showReactiveObjects = true;
        private bool showMaterials = true;
        private bool showBlendshapes = true;
        private bool showArmatureBones = true;
        private bool showUnknown = true;
        private Vector2 treeScroll;
        private Vector2 listScroll;
        private Vector2 detailScroll;
        private readonly List<ModularAvatarComponentInfo> scanResults = new List<ModularAvatarComponentInfo>();
        private readonly Dictionary<string, bool> treeExpanded = new Dictionary<string, bool>();
        private ModularAvatarTreeNode treeRoot;
        private string selectedPath;
        private string selectedComponentId;
        private string scanMessage = "Assign an avatar root, then refresh the scan.";

        [MenuItem("Tools/Puddles/Modular Avatar Inspector")]
        public static void Open()
        {
            GetWindow<ModularAvatarInspectorWindow>("MA Inspector");
        }

        private void OnEnable()
        {
            if (avatarRoot == null)
            {
                UseSelectedAvatar();
            }
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Modular Avatar Inspector", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Read-only scanner for Modular Avatar components. It explains menu, parameter, animator, object, blendshape, and material setup without baking or modifying the avatar.",
                MessageType.Info);

            DrawHeader();

            EditorGUILayout.Space(4);

            if (avatarRoot == null)
            {
                EditorGUILayout.HelpBox("Assign an avatar root or select an avatar in the hierarchy, then click Use Selected Avatar.", MessageType.Info);
                return;
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                DrawTreePanel();
                DrawComponentListPanel();
                DrawDetailPanel();
            }
        }

        private void DrawHeader()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUI.BeginChangeCheck();
                    avatarRoot = (GameObject)EditorGUILayout.ObjectField("Avatar Root", avatarRoot, typeof(GameObject), true);
                    if (EditorGUI.EndChangeCheck())
                    {
                        RefreshScan();
                    }

                    if (GUILayout.Button("Use Selected Avatar", GUILayout.Width(150)))
                    {
                        UseSelectedAvatar();
                        RefreshScan();
                    }

                    using (new EditorGUI.DisabledScope(avatarRoot == null))
                    {
                        if (GUILayout.Button("Refresh Scan", GUILayout.Width(110)))
                        {
                            RefreshScan();
                        }
                    }
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("Search", GUILayout.Width(EditorGUIUtility.labelWidth - 4));
                    searchText = EditorGUILayout.TextField(searchText);
                    if (GUILayout.Button("Clear", GUILayout.Width(60)))
                    {
                        searchText = string.Empty;
                    }
                }

                DrawFilters();

                string packageState = IsModularAvatarLoaded()
                    ? "Modular Avatar runtime appears loaded."
                    : "No Modular Avatar assemblies detected yet. Scanning still works for loaded scene components if present.";
                EditorGUILayout.LabelField(packageState, EditorStyles.miniLabel);
                EditorGUILayout.LabelField(scanMessage, EditorStyles.miniLabel);
            }
        }

        private void DrawFilters()
        {
            EditorGUILayout.LabelField("Filters", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                showMenus = GUILayout.Toggle(showMenus, "Menus", EditorStyles.toolbarButton);
                showParameters = GUILayout.Toggle(showParameters, "Parameters", EditorStyles.toolbarButton);
                showAnimators = GUILayout.Toggle(showAnimators, "Animators", EditorStyles.toolbarButton);
                showReactiveObjects = GUILayout.Toggle(showReactiveObjects, "Reactive", EditorStyles.toolbarButton);
                showMaterials = GUILayout.Toggle(showMaterials, "Materials", EditorStyles.toolbarButton);
                showBlendshapes = GUILayout.Toggle(showBlendshapes, "Blendshapes", EditorStyles.toolbarButton);
                showArmatureBones = GUILayout.Toggle(showArmatureBones, "Armature/Bones", EditorStyles.toolbarButton);
                showUnknown = GUILayout.Toggle(showUnknown, "Unknown", EditorStyles.toolbarButton);
            }
        }

        private void DrawTreePanel()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox, GUILayout.Width(280)))
            {
                EditorGUILayout.LabelField("Avatar Hierarchy", EditorStyles.boldLabel);
                treeScroll = EditorGUILayout.BeginScrollView(treeScroll);

                if (treeRoot == null)
                {
                    EditorGUILayout.LabelField("No Modular Avatar components found.");
                }
                else
                {
                    DrawTreeNode(treeRoot, 0);
                }

                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawTreeNode(ModularAvatarTreeNode node, int indent)
        {
            if (node == null)
            {
                return;
            }

            bool hasChildren = node.children.Count > 0;
            bool expanded = GetTreeExpanded(node.path, indent == 0);

            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(indent * 14);
                if (hasChildren)
                {
                    bool nextExpanded = GUILayout.Toggle(expanded, expanded ? "v" : ">", EditorStyles.miniButton, GUILayout.Width(22));
                    if (nextExpanded != expanded)
                    {
                        treeExpanded[node.path] = nextExpanded;
                    }
                }
                else
                {
                    GUILayout.Space(24);
                }

                string label = node.displayName;
                if (node.directComponents.Count > 0)
                {
                    label += $" ({node.directComponents.Count})";
                }

                bool isSelected = selectedPath == node.path;
                GUIStyle style = isSelected ? EditorStyles.toolbarButton : EditorStyles.miniButton;
                if (GUILayout.Button(label, style))
                {
                    selectedPath = node.path;
                    if (node.directComponents.Count > 0)
                    {
                        selectedComponentId = node.directComponents[0].id;
                    }
                }
            }

            if (!hasChildren || !GetTreeExpanded(node.path, indent == 0))
            {
                return;
            }

            foreach (ModularAvatarTreeNode child in node.children)
            {
                DrawTreeNode(child, indent + 1);
            }
        }

        private void DrawComponentListPanel()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox, GUILayout.Width(360)))
            {
                EditorGUILayout.LabelField("Components", EditorStyles.boldLabel);
                IEnumerable<ModularAvatarComponentInfo> visible = GetVisibleResults();
                if (!string.IsNullOrEmpty(selectedPath) && selectedPath != "Root")
                {
                    visible = visible.Where(info => info.path == selectedPath || info.path.StartsWith(selectedPath + "/", StringComparison.Ordinal));
                }

                List<ModularAvatarComponentInfo> visibleList = visible.ToList();
                EditorGUILayout.LabelField($"{visibleList.Count} shown / {scanResults.Count} scanned", EditorStyles.miniLabel);

                listScroll = EditorGUILayout.BeginScrollView(listScroll);
                foreach (IGrouping<ModularAvatarComponentGroup, ModularAvatarComponentInfo> group in visibleList.GroupBy(info => info.group).OrderBy(group => GroupSort(group.Key)))
                {
                    EditorGUILayout.LabelField(GetGroupDisplayName(group.Key), EditorStyles.boldLabel);
                    foreach (ModularAvatarComponentInfo info in group.OrderBy(info => info.path).ThenBy(info => info.displayName))
                    {
                        DrawComponentRow(info);
                    }
                    EditorGUILayout.Space(4);
                }
                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawComponentRow(ModularAvatarComponentInfo info)
        {
            string badgeText = info.badges.Count > 0 ? "  [" + string.Join(", ", info.badges) + "]" : string.Empty;
            string label = $"{info.displayName}{badgeText}\n{info.path}";
            GUIStyle labelStyle = new GUIStyle(EditorStyles.wordWrappedMiniLabel)
            {
                alignment = TextAnchor.UpperLeft,
                wordWrap = true,
                clipping = TextClipping.Clip,
                padding = new RectOffset(6, 6, 4, 4),
                fontSize = 11
            };
            float contentWidth = Mathf.Max(120f, EditorGUIUtility.currentViewWidth - 320f);
            float rowHeight = Mathf.Max(34f, labelStyle.CalcHeight(new GUIContent(label), contentWidth) + 4f);
            Rect rowRect = GUILayoutUtility.GetRect(1f, rowHeight, GUILayout.ExpandWidth(true));
            bool isSelected = selectedComponentId == info.id;
            Color background = isSelected
                ? new Color(0.30f, 0.43f, 0.62f, 0.95f)
                : new Color(0.25f, 0.25f, 0.25f, 0.95f);
            EditorGUI.DrawRect(rowRect, background);
            GUI.Label(rowRect, label, labelStyle);
            EditorGUIUtility.AddCursorRect(rowRect, MouseCursor.Link);
            if (Event.current.type == EventType.MouseDown && rowRect.Contains(Event.current.mousePosition))
            {
                selectedComponentId = info.id;
                selectedPath = info.path;
                Event.current.Use();
            }
        }

        private void DrawDetailPanel()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Selected Component", EditorStyles.boldLabel);
                detailScroll = EditorGUILayout.BeginScrollView(detailScroll);

                ModularAvatarComponentInfo selected = scanResults.FirstOrDefault(info => info.id == selectedComponentId);
                if (selected == null)
                {
                    EditorGUILayout.LabelField("Select a Modular Avatar component to inspect it.");
                    EditorGUILayout.EndScrollView();
                    return;
                }

                DrawReadOnlyLine("Display Name", selected.displayName);
                DrawReadOnlyLine("Type", selected.typeName);
                DrawReadOnlyLine("Group", GetGroupDisplayName(selected.group));
                DrawReadOnlyLine("Path", selected.path);
                DrawReadOnlyLine("Full Type", selected.fullTypeName);
                DrawReadOnlyLine("Badges", selected.badges.Count == 0 ? "None" : string.Join(", ", selected.badges));
                EditorGUILayout.ObjectField("Component", selected.component, typeof(Component), true);

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Decoded Summary", EditorStyles.boldLabel);
                if (selected.summary.Count == 0)
                {
                    EditorGUILayout.LabelField("No friendly decoder yet. Generic serialized fields are shown below.", EditorStyles.wordWrappedMiniLabel);
                }
                else
                {
                    foreach (string line in selected.summary)
                    {
                        EditorGUILayout.LabelField(line, EditorStyles.wordWrappedLabel);
                    }
                }

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Action Builder-Shaped Effects", EditorStyles.boldLabel);
                if (selected.effects.Count == 0)
                {
                    EditorGUILayout.LabelField("No direct control effect was normalized from this component.", EditorStyles.wordWrappedMiniLabel);
                }
                else
                {
                    foreach (ModularAvatarEffectInfo effect in selected.effects)
                    {
                        EditorGUILayout.LabelField(effect.ToDisplayString(), EditorStyles.wordWrappedMiniLabel);
                    }
                }

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Serialized Fields", EditorStyles.boldLabel);
                foreach (string line in selected.serializedFields)
                {
                    EditorGUILayout.LabelField(line, EditorStyles.wordWrappedMiniLabel);
                }

                EditorGUILayout.EndScrollView();
            }
        }

        private void RefreshScan()
        {
            scanResults.Clear();
            treeRoot = null;
            selectedComponentId = null;
            selectedPath = null;

            if (avatarRoot == null)
            {
                scanMessage = "Assign an avatar root, then refresh the scan.";
                return;
            }

            Component[] components = avatarRoot.GetComponentsInChildren<Component>(true);
            foreach (Component component in components)
            {
                if (!IsModularAvatarComponent(component))
                {
                    continue;
                }

                ModularAvatarComponentInfo info = DecodeComponent(component);
                scanResults.Add(info);
            }

            treeRoot = BuildTree();
            if (treeRoot != null)
            {
                selectedPath = treeRoot.path;
            }

            scanMessage = scanResults.Count == 0
                ? "No Modular Avatar components found under this avatar root."
                : $"Found {scanResults.Count} Modular Avatar component(s). Scan is read-only.";
        }

        private ModularAvatarComponentInfo DecodeComponent(Component component)
        {
            Type type = component.GetType();
            string typeName = type.Name;
            ModularAvatarComponentInfo info = new ModularAvatarComponentInfo
            {
                id = component.GetInstanceID().ToString(),
                component = component,
                displayName = GetFriendlyTypeName(typeName),
                typeName = typeName,
                fullTypeName = type.FullName,
                path = GetAvatarPath(component.gameObject),
                group = GuessGroup(typeName),
            };

            SerializedObject serializedObject = new SerializedObject(component);
            DecodeKnownComponent(info, serializedObject);
            AddGenericSerializedFields(info, serializedObject);

            if (info.summary.Count == 0)
            {
                info.badges.Add("Unsupported / Inspect Only");
            }

            if (info.effects.Count > 0 || IsLikelySimpleMenuControl(info))
            {
                info.badges.Add("Conversion Candidate");
            }

            return info;
        }

        private void DecodeKnownComponent(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            string typeName = info.typeName;
            switch (typeName)
            {
                case "ModularAvatarMenuInstaller":
                    DecodeMenuInstaller(info, serializedObject);
                    break;
                case "ModularAvatarMenuItem":
                    DecodeMenuItem(info, serializedObject);
                    break;
                case "ModularAvatarParameters":
                    DecodeParameters(info, serializedObject);
                    break;
                case "ModularAvatarMergeAnimator":
                    DecodeMergeAnimator(info, serializedObject);
                    break;
                case "ModularAvatarObjectToggle":
                    DecodeObjectToggle(info, serializedObject);
                    break;
                case "ModularAvatarShapeChanger":
                    DecodeShapeChanger(info, serializedObject);
                    break;
                case "ModularAvatarMaterialSetter":
                    DecodeMaterialSetter(info, serializedObject);
                    break;
                case "ModularAvatarMaterialSwap":
                    DecodeMaterialSwap(info, serializedObject);
                    break;
                case "ModularAvatarBlendshapeSync":
                    DecodeBlendshapeSync(info, serializedObject);
                    break;
                default:
                    DecodeCommonInspectOnly(info, serializedObject);
                    break;
            }
        }

        private void DecodeMenuInstaller(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            UnityEngine.Object menuToAppend = GetObject(serializedObject, "menuToAppend");
            UnityEngine.Object installTargetMenu = GetObject(serializedObject, "installTargetMenu");
            info.summary.Add($"Appends menu: {ObjectName(menuToAppend)}");
            info.summary.Add($"Install target: {ObjectName(installTargetMenu, "avatar root menu")}");
            info.effects.Add(new ModularAvatarEffectInfo("Menu install", info.path, "menuToAppend", ObjectName(menuToAppend)));
        }

        private void DecodeMenuItem(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            string label = GetString(serializedObject, "label");
            SerializedProperty control = serializedObject.FindProperty("Control");
            string menuLabel = string.IsNullOrWhiteSpace(label) ? info.component.gameObject.name : label;
            string type = ReadEnumDisplay(control?.FindPropertyRelative("type"));
            string parameter = ReadControlParameter(control);
            float value = control?.FindPropertyRelative("value")?.floatValue ?? 0f;
            UnityEngine.Object submenu = control?.FindPropertyRelative("subMenu")?.objectReferenceValue;
            string menuSource = ReadEnumDisplay(serializedObject.FindProperty("MenuSource"));

            info.displayName = $"MA Menu Item: {menuLabel}";
            info.summary.Add($"Menu label: {menuLabel}");
            info.summary.Add($"Control type: {Fallback(type, "Unknown")}");
            info.summary.Add($"Parameter: {Fallback(parameter, "None")}");
            info.summary.Add($"Value: {value:0.###}");
            info.summary.Add($"Submenu source: {Fallback(menuSource, "None")}");
            if (submenu != null)
            {
                info.summary.Add($"Submenu asset: {submenu.name}");
            }
            info.summary.Add($"Saved: {GetBool(serializedObject, "isSaved")}, synced: {GetBool(serializedObject, "isSynced")}, default: {GetBool(serializedObject, "isDefault")}, auto value: {GetBool(serializedObject, "automaticValue")}");

            info.effects.Add(new ModularAvatarEffectInfo("Menu control", info.path, Fallback(parameter, "(no parameter)"), $"{type} value {value:0.###}"));
        }

        private void DecodeParameters(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            SerializedProperty parameters = serializedObject.FindProperty("parameters");
            int count = parameters?.isArray == true ? parameters.arraySize : 0;
            info.summary.Add($"Defines or remaps {count} parameter(s).");
            for (int i = 0; i < count; i++)
            {
                SerializedProperty entry = parameters.GetArrayElementAtIndex(i);
                string nameOrPrefix = GetRelativeString(entry, "nameOrPrefix");
                string remapTo = GetRelativeString(entry, "remapTo");
                string syncType = ReadEnumDisplay(entry.FindPropertyRelative("syncType"));
                bool saved = GetRelativeBool(entry, "saved");
                bool localOnly = GetRelativeBool(entry, "localOnly");
                bool hasDefault = GetRelativeBool(entry, "hasExplicitDefaultValue");
                float defaultValue = GetRelativeFloat(entry, "defaultValue");
                string remap = string.IsNullOrWhiteSpace(remapTo) ? string.Empty : $" -> {remapTo}";
                string defaultText = hasDefault || Mathf.Abs(defaultValue) > 0.000001f ? $", default {defaultValue:0.###}" : string.Empty;
                info.summary.Add($"{nameOrPrefix}{remap}: {syncType}, saved {saved}, local {localOnly}{defaultText}");
                info.effects.Add(new ModularAvatarEffectInfo("Parameter", info.path, nameOrPrefix, $"{syncType}{remap}"));
            }
        }

        private void DecodeMergeAnimator(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            UnityEngine.Object animator = GetObject(serializedObject, "animator");
            string layerType = ReadEnumDisplay(serializedObject.FindProperty("layerType"));
            string pathMode = ReadEnumDisplay(serializedObject.FindProperty("pathMode"));
            string mergeMode = ReadEnumDisplay(serializedObject.FindProperty("mergeAnimatorMode"));
            int priority = GetInt(serializedObject, "layerPriority");
            info.summary.Add($"Animator: {ObjectName(animator)}");
            info.summary.Add($"Layer: {Fallback(layerType, "FX")}, mode: {Fallback(mergeMode, "Append")}, priority: {priority}");
            info.summary.Add($"Path mode: {Fallback(pathMode, "Relative")}, match write defaults: {GetBool(serializedObject, "matchAvatarWriteDefaults")}");
            info.effects.Add(new ModularAvatarEffectInfo("Animator merge", info.path, Fallback(layerType, "FX"), ObjectName(animator)));
        }

        private void DecodeObjectToggle(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            AddControllingMenuSummary(info);
            SerializedProperty objects = serializedObject.FindProperty("m_objects");
            int count = objects?.isArray == true ? objects.arraySize : 0;
            info.summary.Add($"Changes active state for {count} object(s). Inverted: {GetBool(serializedObject, "m_inverted")}");
            for (int i = 0; i < count; i++)
            {
                SerializedProperty entry = objects.GetArrayElementAtIndex(i);
                AvatarReference target = ReadAvatarReference(entry.FindPropertyRelative("Object"));
                bool active = GetRelativeBool(entry, "Active");
                info.summary.Add($"{target.DisplayName}: {(active ? "Active" : "Inactive")}");
                info.effects.Add(new ModularAvatarEffectInfo("Object state", target.Path, "m_IsActive", active ? "Active" : "Inactive"));
            }
        }

        private void DecodeShapeChanger(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            AddControllingMenuSummary(info);
            SerializedProperty shapes = serializedObject.FindProperty("m_shapes");
            int count = shapes?.isArray == true ? shapes.arraySize : 0;
            float threshold = GetFloat(serializedObject, "m_threshold");
            info.summary.Add($"Changes {count} blendshape entry/entries. Delete threshold: {threshold:0.###}. Inverted: {GetBool(serializedObject, "m_inverted")}");
            for (int i = 0; i < count; i++)
            {
                SerializedProperty entry = shapes.GetArrayElementAtIndex(i);
                AvatarReference target = ReadAvatarReference(entry.FindPropertyRelative("Object"));
                string shape = GetRelativeString(entry, "ShapeName");
                string changeType = ReadEnumDisplay(entry.FindPropertyRelative("ChangeType"));
                float value = GetRelativeFloat(entry, "Value");
                string valueText = changeType == "Delete" ? "Delete" : $"Set {value:0.###}";
                info.summary.Add($"{target.DisplayName}: {shape} = {valueText}");
                info.effects.Add(new ModularAvatarEffectInfo("Blendshape", target.Path, shape, valueText));
            }
        }

        private void DecodeMaterialSetter(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            AddControllingMenuSummary(info);
            SerializedProperty objects = serializedObject.FindProperty("m_objects");
            int count = objects?.isArray == true ? objects.arraySize : 0;
            info.summary.Add($"Sets {count} material slot(s). Inverted: {GetBool(serializedObject, "m_inverted")}");
            for (int i = 0; i < count; i++)
            {
                SerializedProperty entry = objects.GetArrayElementAtIndex(i);
                AvatarReference target = ReadAvatarReference(entry.FindPropertyRelative("Object"));
                UnityEngine.Object material = entry.FindPropertyRelative("Material")?.objectReferenceValue;
                int slot = GetRelativeInt(entry, "MaterialIndex");
                info.summary.Add($"{target.DisplayName}: slot {slot} -> {ObjectName(material)}");
                info.effects.Add(new ModularAvatarEffectInfo("Material slot", target.Path, $"slot {slot}", ObjectName(material)));
            }
        }

        private void DecodeMaterialSwap(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            AddControllingMenuSummary(info);
            AvatarReference root = ReadAvatarReference(serializedObject.FindProperty("m_root"));
            SerializedProperty swaps = serializedObject.FindProperty("m_swaps");
            int count = swaps?.isArray == true ? swaps.arraySize : 0;
            string quickSwap = ReadEnumDisplay(serializedObject.FindProperty("m_quickSwapMode"));
            info.summary.Add($"Swaps {count} material pair(s) under {root.DisplayName}. Quick swap: {Fallback(quickSwap, "None")}. Inverted: {GetBool(serializedObject, "m_inverted")}");
            for (int i = 0; i < count; i++)
            {
                SerializedProperty entry = swaps.GetArrayElementAtIndex(i);
                UnityEngine.Object from = entry.FindPropertyRelative("From")?.objectReferenceValue;
                UnityEngine.Object to = entry.FindPropertyRelative("To")?.objectReferenceValue;
                info.summary.Add($"{ObjectName(from)} -> {ObjectName(to)}");
                info.effects.Add(new ModularAvatarEffectInfo("Material swap", root.Path, ObjectName(from), ObjectName(to)));
            }
        }

        private void DecodeBlendshapeSync(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            SkinnedMeshRenderer localRenderer = info.component.GetComponent<SkinnedMeshRenderer>();
            string localPath = localRenderer != null ? GetAvatarPath(localRenderer.gameObject) : info.path;
            SerializedProperty bindings = serializedObject.FindProperty("Bindings");
            int count = bindings?.isArray == true ? bindings.arraySize : 0;
            info.summary.Add($"Syncs {count} blendshape binding(s) into local renderer {localPath}.");
            for (int i = 0; i < count; i++)
            {
                SerializedProperty entry = bindings.GetArrayElementAtIndex(i);
                AvatarReference referenceMesh = ReadAvatarReference(entry.FindPropertyRelative("ReferenceMesh"));
                string sourceShape = GetRelativeString(entry, "Blendshape");
                string localShape = GetRelativeString(entry, "LocalBlendshape");
                if (string.IsNullOrWhiteSpace(localShape))
                {
                    localShape = sourceShape;
                }
                info.summary.Add($"{referenceMesh.DisplayName}.{sourceShape} -> {localPath}.{localShape}");
                info.effects.Add(new ModularAvatarEffectInfo("Blendshape sync", referenceMesh.Path, sourceShape, $"{localPath}.{localShape}"));
            }
        }

        private void DecodeCommonInspectOnly(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            string typeName = info.typeName;
            if (typeName.Contains("BoneProxy") || typeName.Contains("MergeArmature") || typeName.Contains("MoveIndependently") || typeName.Contains("WorldFixed") || typeName.Contains("WorldScale") || typeName.Contains("GlobalCollider"))
            {
                info.summary.Add("Armature/bone helper component. V1 shows it as inspect-only because it affects build-time hierarchy or tracking behavior rather than a simple expression control.");
            }
            else if (typeName.Contains("Mesh") || typeName.Contains("Vertex") || typeName.Contains("Scale"))
            {
                info.summary.Add("Mesh/scale helper component. V1 shows it as inspect-only because it may bake geometry or mesh behavior during Modular Avatar processing.");
            }
        }

        private void AddControllingMenuSummary(ModularAvatarComponentInfo info)
        {
            Component menuItem = FindNearestMenuItem(info.component.transform);
            if (menuItem == null)
            {
                info.summary.Add("Controlling menu item: none found on this object or parents.");
                return;
            }

            SerializedObject menuObject = new SerializedObject(menuItem);
            SerializedProperty control = menuObject.FindProperty("Control");
            string label = GetString(menuObject, "label");
            if (string.IsNullOrWhiteSpace(label))
            {
                label = menuItem.gameObject.name;
            }
            string parameter = ReadControlParameter(control);
            string type = ReadEnumDisplay(control?.FindPropertyRelative("type"));
            info.summary.Add($"Controlled by menu item: {label} ({type}, {Fallback(parameter, "no parameter")})");
        }

        private Component FindNearestMenuItem(Transform transform)
        {
            Transform cursor = transform;
            while (cursor != null)
            {
                Component menuItem = cursor.GetComponents<Component>()
                    .FirstOrDefault(component => component != null && component.GetType().Name == "ModularAvatarMenuItem");
                if (menuItem != null)
                {
                    return menuItem;
                }
                if (cursor.gameObject == avatarRoot)
                {
                    break;
                }
                cursor = cursor.parent;
            }
            return null;
        }

        private void AddGenericSerializedFields(ModularAvatarComponentInfo info, SerializedObject serializedObject)
        {
            SerializedProperty iterator = serializedObject.GetIterator();
            bool enterChildren = true;
            int lineCount = 0;
            while (iterator.NextVisible(enterChildren))
            {
                enterChildren = false;
                if (iterator.propertyPath == "m_Script")
                {
                    continue;
                }

                info.serializedFields.Add($"{iterator.propertyPath}: {PropertyValueToString(iterator)}");
                lineCount++;
                if (lineCount >= 80)
                {
                    info.serializedFields.Add("... more fields hidden in V1 detail view");
                    break;
                }
            }
        }

        private ModularAvatarTreeNode BuildTree()
        {
            if (avatarRoot == null || scanResults.Count == 0)
            {
                return null;
            }

            return BuildTreeNode(avatarRoot.transform);
        }

        private ModularAvatarTreeNode BuildTreeNode(Transform transform)
        {
            string path = GetAvatarPath(transform.gameObject);
            List<ModularAvatarComponentInfo> direct = scanResults.Where(info => info.path == path).ToList();
            List<ModularAvatarTreeNode> children = new List<ModularAvatarTreeNode>();
            foreach (Transform child in transform)
            {
                ModularAvatarTreeNode childNode = BuildTreeNode(child);
                if (childNode != null)
                {
                    children.Add(childNode);
                }
            }

            if (direct.Count == 0 && children.Count == 0)
            {
                return null;
            }

            return new ModularAvatarTreeNode
            {
                path = path,
                displayName = transform == avatarRoot.transform ? "Root" : transform.name,
                directComponents = direct,
                children = children
            };
        }

        private IEnumerable<ModularAvatarComponentInfo> GetVisibleResults()
        {
            return scanResults.Where(PassesFilter).Where(PassesSearch);
        }

        private bool PassesFilter(ModularAvatarComponentInfo info)
        {
            switch (info.group)
            {
                case ModularAvatarComponentGroup.Menu:
                    return showMenus;
                case ModularAvatarComponentGroup.Parameter:
                    return showParameters;
                case ModularAvatarComponentGroup.Animator:
                    return showAnimators;
                case ModularAvatarComponentGroup.Reactive:
                    return showReactiveObjects;
                case ModularAvatarComponentGroup.Material:
                    return showMaterials;
                case ModularAvatarComponentGroup.Blendshape:
                    return showBlendshapes;
                case ModularAvatarComponentGroup.ArmatureBone:
                    return showArmatureBones;
                default:
                    return showUnknown;
            }
        }

        private bool PassesSearch(ModularAvatarComponentInfo info)
        {
            if (string.IsNullOrWhiteSpace(searchText))
            {
                return true;
            }

            string needle = searchText.Trim();
            return Contains(info.displayName, needle)
                || Contains(info.typeName, needle)
                || Contains(info.path, needle)
                || info.badges.Any(badge => Contains(badge, needle))
                || info.summary.Any(line => Contains(line, needle))
                || info.effects.Any(effect => Contains(effect.ToDisplayString(), needle));
        }

        private bool IsLikelySimpleMenuControl(ModularAvatarComponentInfo info)
        {
            if (info.typeName != "ModularAvatarMenuItem")
            {
                return false;
            }

            return info.effects.Any(effect => effect.kind == "Menu control");
        }

        private ModularAvatarComponentGroup GuessGroup(string typeName)
        {
            if (typeName.Contains("Menu"))
            {
                return ModularAvatarComponentGroup.Menu;
            }
            if (typeName.Contains("Parameter"))
            {
                return ModularAvatarComponentGroup.Parameter;
            }
            if (typeName.Contains("Animator") || typeName.Contains("BlendTree") || typeName.Contains("MMDLayer"))
            {
                return ModularAvatarComponentGroup.Animator;
            }
            if (typeName.Contains("Material"))
            {
                return ModularAvatarComponentGroup.Material;
            }
            if (typeName.Contains("Blendshape") || typeName.Contains("Shape"))
            {
                return ModularAvatarComponentGroup.Blendshape;
            }
            if (typeName.Contains("Bone") || typeName.Contains("Armature") || typeName.Contains("World") || typeName.Contains("Collider") || typeName.Contains("MoveIndependently"))
            {
                return ModularAvatarComponentGroup.ArmatureBone;
            }
            if (typeName.Contains("Toggle") || typeName.Contains("Reactive") || typeName.Contains("Mesh") || typeName.Contains("Scale"))
            {
                return ModularAvatarComponentGroup.Reactive;
            }
            return ModularAvatarComponentGroup.Unknown;
        }

        private static int GroupSort(ModularAvatarComponentGroup group)
        {
            return (int)group;
        }

        private static string GetGroupDisplayName(ModularAvatarComponentGroup group)
        {
            switch (group)
            {
                case ModularAvatarComponentGroup.Menu:
                    return "Menus";
                case ModularAvatarComponentGroup.Parameter:
                    return "Parameters";
                case ModularAvatarComponentGroup.Animator:
                    return "Animators";
                case ModularAvatarComponentGroup.Reactive:
                    return "Reactive Objects";
                case ModularAvatarComponentGroup.Material:
                    return "Materials";
                case ModularAvatarComponentGroup.Blendshape:
                    return "Blendshapes";
                case ModularAvatarComponentGroup.ArmatureBone:
                    return "Armature / Bones";
                default:
                    return "Unknown / Inspect Only";
            }
        }

        private static string GetFriendlyTypeName(string typeName)
        {
            if (typeName.StartsWith("ModularAvatar", StringComparison.Ordinal))
            {
                typeName = typeName.Substring("ModularAvatar".Length);
            }
            if (typeName.StartsWith("MA", StringComparison.Ordinal))
            {
                typeName = typeName.Substring(2);
            }

            return "MA " + SplitCamelCase(typeName);
        }

        private string GetAvatarPath(GameObject obj)
        {
            if (obj == null)
            {
                return "(missing)";
            }
            if (avatarRoot == null || obj == avatarRoot)
            {
                return "Root";
            }

            string path = AnimationUtility.CalculateTransformPath(obj.transform, avatarRoot.transform);
            return string.IsNullOrWhiteSpace(path) ? "Root" : path;
        }

        private AvatarReference ReadAvatarReference(SerializedProperty property)
        {
            if (property == null)
            {
                return new AvatarReference("(missing)", null, "(missing)");
            }

            string referencePath = property.FindPropertyRelative("referencePath")?.stringValue;
            GameObject target = property.FindPropertyRelative("targetObject")?.objectReferenceValue as GameObject;
            GameObject resolved = ResolveAvatarReference(referencePath, target);
            string path = resolved != null ? GetAvatarPath(resolved) : Fallback(referencePath, "(unresolved)");
            string display = resolved != null ? $"{resolved.name} ({path})" : path;
            return new AvatarReference(display, resolved, path);
        }

        private GameObject ResolveAvatarReference(string referencePath, GameObject target)
        {
            if (avatarRoot == null)
            {
                return target;
            }
            if (target != null && target.transform.IsChildOf(avatarRoot.transform))
            {
                return target;
            }
            if (referencePath == AvatarRootToken)
            {
                return avatarRoot;
            }
            if (!string.IsNullOrWhiteSpace(referencePath))
            {
                Transform resolved = avatarRoot.transform.Find(referencePath);
                if (resolved != null)
                {
                    return resolved.gameObject;
                }
            }
            return target;
        }

        private void UseSelectedAvatar()
        {
            GameObject selected = Selection.activeGameObject;
            if (selected == null)
            {
                return;
            }

            VRCAvatarDescriptor descriptor = selected.GetComponentsInParent<VRCAvatarDescriptor>(true).FirstOrDefault();
            if (descriptor == null)
            {
                descriptor = selected.GetComponentInChildren<VRCAvatarDescriptor>(true);
            }

            avatarRoot = descriptor != null ? descriptor.gameObject : selected;
        }

        private static bool IsModularAvatarComponent(Component component)
        {
            if (component == null)
            {
                return false;
            }

            Type type = component.GetType();
            string fullName = type.FullName ?? string.Empty;
            return fullName.StartsWith("nadena.dev.modular_avatar.", StringComparison.Ordinal)
                || type.Name.StartsWith("ModularAvatar", StringComparison.Ordinal)
                || type.Name.StartsWith("MA", StringComparison.Ordinal);
        }

        private static bool IsModularAvatarLoaded()
        {
            foreach (System.Reflection.Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                if ((assembly.GetName().Name ?? string.Empty).IndexOf("modular-avatar", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }
            return false;
        }

        private bool GetTreeExpanded(string path, bool defaultValue)
        {
            if (!treeExpanded.TryGetValue(path, out bool expanded))
            {
                expanded = defaultValue;
                treeExpanded[path] = expanded;
            }
            return expanded;
        }

        private static void DrawReadOnlyLine(string label, string value)
        {
            EditorGUILayout.LabelField(label, string.IsNullOrWhiteSpace(value) ? "(none)" : value);
        }

        private static string ReadControlParameter(SerializedProperty control)
        {
            SerializedProperty parameter = control?.FindPropertyRelative("parameter");
            string name = parameter?.FindPropertyRelative("name")?.stringValue;
            if (!string.IsNullOrWhiteSpace(name))
            {
                return name;
            }

            SerializedProperty portableParameter = control?.FindPropertyRelative("parameter.name");
            return portableParameter?.stringValue;
        }

        private static string ReadEnumDisplay(SerializedProperty property)
        {
            if (property == null)
            {
                return string.Empty;
            }

            if (property.propertyType == SerializedPropertyType.Enum)
            {
                return property.enumDisplayNames != null && property.enumValueIndex >= 0 && property.enumValueIndex < property.enumDisplayNames.Length
                    ? property.enumDisplayNames[property.enumValueIndex]
                    : property.enumValueIndex.ToString();
            }

            return PropertyValueToString(property);
        }

        private static string PropertyValueToString(SerializedProperty property)
        {
            if (property == null)
            {
                return "(missing)";
            }

            switch (property.propertyType)
            {
                case SerializedPropertyType.Integer:
                    return property.intValue.ToString();
                case SerializedPropertyType.Boolean:
                    return property.boolValue.ToString();
                case SerializedPropertyType.Float:
                    return property.floatValue.ToString("0.###");
                case SerializedPropertyType.String:
                    return property.stringValue;
                case SerializedPropertyType.Color:
                    return property.colorValue.ToString();
                case SerializedPropertyType.ObjectReference:
                    return ObjectName(property.objectReferenceValue);
                case SerializedPropertyType.Enum:
                    return ReadEnumDisplay(property);
                case SerializedPropertyType.Vector2:
                    return property.vector2Value.ToString();
                case SerializedPropertyType.Vector3:
                    return property.vector3Value.ToString();
                case SerializedPropertyType.Vector4:
                    return property.vector4Value.ToString();
                case SerializedPropertyType.Rect:
                    return property.rectValue.ToString();
                case SerializedPropertyType.Bounds:
                    return property.boundsValue.ToString();
                case SerializedPropertyType.Quaternion:
                    return property.quaternionValue.eulerAngles.ToString();
                default:
                    if (property.isArray)
                    {
                        return $"Array[{property.arraySize}]";
                    }
                    return property.propertyType.ToString();
            }
        }

        private static UnityEngine.Object GetObject(SerializedObject serializedObject, string propertyName)
        {
            return serializedObject.FindProperty(propertyName)?.objectReferenceValue;
        }

        private static string GetString(SerializedObject serializedObject, string propertyName)
        {
            return serializedObject.FindProperty(propertyName)?.stringValue ?? string.Empty;
        }

        private static bool GetBool(SerializedObject serializedObject, string propertyName)
        {
            return serializedObject.FindProperty(propertyName)?.boolValue ?? false;
        }

        private static int GetInt(SerializedObject serializedObject, string propertyName)
        {
            return serializedObject.FindProperty(propertyName)?.intValue ?? 0;
        }

        private static float GetFloat(SerializedObject serializedObject, string propertyName)
        {
            return serializedObject.FindProperty(propertyName)?.floatValue ?? 0f;
        }

        private static string GetRelativeString(SerializedProperty property, string propertyName)
        {
            return property.FindPropertyRelative(propertyName)?.stringValue ?? string.Empty;
        }

        private static bool GetRelativeBool(SerializedProperty property, string propertyName)
        {
            return property.FindPropertyRelative(propertyName)?.boolValue ?? false;
        }

        private static int GetRelativeInt(SerializedProperty property, string propertyName)
        {
            return property.FindPropertyRelative(propertyName)?.intValue ?? 0;
        }

        private static float GetRelativeFloat(SerializedProperty property, string propertyName)
        {
            return property.FindPropertyRelative(propertyName)?.floatValue ?? 0f;
        }

        private static string ObjectName(UnityEngine.Object obj, string fallback = "None")
        {
            return obj == null ? fallback : obj.name;
        }

        private static string Fallback(string value, string fallback)
        {
            return string.IsNullOrWhiteSpace(value) ? fallback : value;
        }

        private static bool Contains(string haystack, string needle)
        {
            return !string.IsNullOrEmpty(haystack)
                && haystack.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string SplitCamelCase(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return value;
            }

            List<char> chars = new List<char>();
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (i > 0 && char.IsUpper(c) && !char.IsWhiteSpace(value[i - 1]))
                {
                    chars.Add(' ');
                }
                chars.Add(c);
            }
            return new string(chars.ToArray()).Trim();
        }

        private enum ModularAvatarComponentGroup
        {
            Menu,
            Parameter,
            Animator,
            Reactive,
            Material,
            Blendshape,
            ArmatureBone,
            Unknown
        }

        private sealed class ModularAvatarComponentInfo
        {
            public string id;
            public Component component;
            public string displayName;
            public string typeName;
            public string fullTypeName;
            public string path;
            public ModularAvatarComponentGroup group;
            public readonly List<string> badges = new List<string>();
            public readonly List<string> summary = new List<string>();
            public readonly List<ModularAvatarEffectInfo> effects = new List<ModularAvatarEffectInfo>();
            public readonly List<string> serializedFields = new List<string>();
        }

        private sealed class ModularAvatarEffectInfo
        {
            public readonly string kind;
            public readonly string targetPath;
            public readonly string propertyName;
            public readonly string value;

            public ModularAvatarEffectInfo(string kind, string targetPath, string propertyName, string value)
            {
                this.kind = kind;
                this.targetPath = targetPath;
                this.propertyName = propertyName;
                this.value = value;
            }

            public string ToDisplayString()
            {
                return $"{kind}: {targetPath} | {propertyName} | {value}";
            }
        }

        private sealed class ModularAvatarTreeNode
        {
            public string path;
            public string displayName;
            public List<ModularAvatarComponentInfo> directComponents;
            public List<ModularAvatarTreeNode> children;
        }

        private readonly struct AvatarReference
        {
            public readonly string DisplayName;
            public readonly GameObject GameObject;
            public readonly string Path;

            public AvatarReference(string displayName, GameObject gameObject, string path)
            {
                DisplayName = displayName;
                GameObject = gameObject;
                Path = path;
            }
        }
    }
}
#endif
