#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PuddlesVrcTools.Editor
{
    public sealed class PuddlesAvatarActionProfile : ScriptableObject
    {
        public GameObject avatarRoot;
        public AnimatorController fxController;
        public VRCExpressionParameters expressionParameters;
        public VRCExpressionsMenu rootMenu;
        public bool appendMenuToRoot = true;
        public string outputFolder = "Assets/PuddlesVrcTools/Generated/AvatarActions";
        public string parameterPrefix = "Puddles/Action";
        public string generatedMenuName = "Avatar Actions";
        public List<PuddlesAvatarActionControl> controls = new List<PuddlesAvatarActionControl>();
        public List<PuddlesAvatarManagedSubmenu> managedSubmenus = new List<PuddlesAvatarManagedSubmenu>();
        public VRCExpressionsMenu lastDestinationMenu;
        public string lastDestinationPath = "Root";
    }

    [Serializable]
    public sealed class PuddlesAvatarManagedSubmenu
    {
        public string id;
        public string displayName;
        public VRCExpressionsMenu parentMenu;
        public VRCExpressionsMenu menu;
        public string path;
    }

    [Serializable]
    public sealed class PuddlesAvatarActionControl
    {
        public string id;
        public string displayName;
        public PuddlesAvatarControlType controlType = PuddlesAvatarControlType.Toggle;
        public string menuPath;
        public VRCExpressionsMenu destinationMenu;
        public string destinationPath;
        public bool saved = true;
        public bool synced = true;
        public bool defaultValue;
        public float radialDefaultValue;
        public PuddlesAvatarRadialMode radialMode = PuddlesAvatarRadialMode.BlendTree;
        public int selectorDefaultIndex;
        public List<PuddlesAvatarSelectorOption> selectorOptions = new List<PuddlesAvatarSelectorOption>();
        public List<PuddlesAvatarActionRow> actions = new List<PuddlesAvatarActionRow>();
    }

    [Serializable]
    public sealed class PuddlesAvatarSelectorOption
    {
        public string id;
        public string displayName;
    }

    [Serializable]
    public sealed class PuddlesAvatarActionRow
    {
        public PuddlesAvatarActionKind kind;
        public GameObject targetObject;
        public string targetObjectPath;
        public PuddlesAvatarWriteMode offWriteMode = PuddlesAvatarWriteMode.Set;
        public PuddlesAvatarWriteMode onWriteMode = PuddlesAvatarWriteMode.Set;
        public bool offBool;
        public bool onBool;
        public SkinnedMeshRenderer skinnedRenderer;
        public string skinnedRendererPath;
        public string blendshapeName;
        public Renderer renderer;
        public string rendererPath;
        public int materialSlot;
        public Material offMaterial;
        public Material onMaterial;
        public Component component;
        public string componentPath;
        public string componentTypeName;
        public string shaderPropertyName;
        public string shaderPropertyPaste;
        public string rawBindingPath;
        public string rawBindingTypeName;
        public string rawBindingPropertyName;
        public PuddlesAvatarRawBindingValueKind rawBindingValueKind;
        public string targetControlId;
        public string targetControlLabel;
        public string offTargetOptionId;
        public string onTargetOptionId;
        public float offFloat;
        public float onFloat;
        public UnityEngine.Object offObjectReference;
        public UnityEngine.Object onObjectReference;
        public List<PuddlesAvatarActionOptionValue> optionValues = new List<PuddlesAvatarActionOptionValue>();
    }

    [Serializable]
    public sealed class PuddlesAvatarActionOptionValue
    {
        public string optionId;
        public PuddlesAvatarWriteMode writeMode = PuddlesAvatarWriteMode.Set;
        public bool boolValue;
        public float floatValue;
        public Material materialValue;
    }

    public enum PuddlesAvatarControlType
    {
        Toggle,
        Radial,
        Selector
    }

    public enum PuddlesAvatarRadialMode
    {
        BlendTree,
        TimeParameter
    }

    public enum PuddlesAvatarActionKind
    {
        ObjectState,
        Blendshape,
        MaterialSwap,
        ShaderFloat,
        ComponentEnabled,
        RawBinding,
        SetAnotherToggle
    }

    public enum PuddlesAvatarWriteMode
    {
        Set,
        NoChange
    }

    public enum PuddlesAvatarRawBindingValueKind
    {
        Float,
        ObjectReference
    }
}
#endif
