#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PuddlesVrcTools.Editor
{
    public sealed class PoiyomiLightingMenuBuilder : EditorWindow
    {
        private const string DefaultOutputFolder = "Assets/PuddlesVrcTools/Generated/PoiyomiLighting";
        private const string DefaultParameterPrefix = "Puddles/Lighting";
        private const string DefaultActionParameterPrefix = "Puddles/Action";
        private const string DefaultActionProfileFolder = "Assets/PuddlesVrcTools/Profiles";
        private const string AllMaterialsFilter = "All Materials";
        private const int MaxControlsPerMenu = 8;
        private const int ControlsPerPagedMenu = 8;

        private static readonly string[] LightingNameHints =
        {
            "lighting",
            "light",
            "shadow",
            "ambient",
            "ao",
            "additive",
            "brightness",
            "directional",
            "emissionstrength",
            "grayscale",
            "greyscale",
            "shading",
            "point",
            "unlit",
            "monochromatic",
            "gradient"
        };

        private GameObject avatarRoot;
        private AnimatorController fxController;
        private VRCExpressionsMenu rootMenuToAppendTo;
        private VRCExpressionParameters expressionParameters;
        private PuddlesAvatarActionProfile actionProfile;
        private AnimationClip debugAnimationClip;
        private string outputFolder = DefaultOutputFolder;
        private string runName = "Lighting";
        private string parameterPrefix = DefaultParameterPrefix;
        private bool savedParameters = true;
        private bool syncedParameters = true;
        private bool appendSubMenuToRoot = true;
        private bool scanOnlyActiveShaderFields = true;
        private bool scanOnlyAnimatedFields;
        private bool scanAllFloatRangeProperties;
        private bool useUnityAnimatableBindings = true;
        private bool cleanOutputFolderBeforeGenerate = false;
        private bool mergeWithExistingRun = true;
        private bool organizeMenusByCategory = true;
        private bool groupSelectedBySetting;
        private PoiyomiGenerationMode generationMode = PoiyomiGenerationMode.AddToActionBuilderAndGenerate;
        private bool logGeneratedClipBindings;
        private string searchText = string.Empty;
        private string materialFilter = AllMaterialsFilter;
        private bool showIncludedOnly;
        private bool avatarSetupFoldout = true;
        private bool generationSettingsFoldout = true;
        private bool debugToolsFoldout;
        private bool controlsFoldout = true;
        private Vector2 scroll;
        private readonly List<PropertyControl> controls = new List<PropertyControl>();
        private readonly List<string> generationWarnings = new List<string>();
        private readonly List<string> generationNotes = new List<string>();

        [MenuItem("Tools/Puddles/Poiyomi Lighting Menu Builder")]
        public static void Open()
        {
            GetWindow<PoiyomiLightingMenuBuilder>("Poiyomi Lighting");
        }

        private void OnGUI()
        {
            NormalizeGenerationModeForRelease();

            EditorGUILayout.LabelField("Poiyomi Lighting Menu Builder", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Scans the avatar for Poiyomi material float/range properties that look lighting-related, then creates radial puppet controls, animation clips, FX layers, and expression parameters.",
                MessageType.Info);

            avatarSetupFoldout = EditorGUILayout.Foldout(avatarSetupFoldout, "Avatar Setup", true);
            if (avatarSetupFoldout)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    avatarRoot = (GameObject)EditorGUILayout.ObjectField("Avatar Root", avatarRoot, typeof(GameObject), true);
                    using (new EditorGUI.DisabledScope(avatarRoot == null))
                    {
                        if (GUILayout.Button("Use Assets From Avatar Descriptor"))
                        {
                            AutoFillFromAvatarDescriptor();
                        }
                    }

                    fxController = (AnimatorController)EditorGUILayout.ObjectField("FX Controller", fxController, typeof(AnimatorController), false);
                    expressionParameters = (VRCExpressionParameters)EditorGUILayout.ObjectField("Expression Parameters", expressionParameters, typeof(VRCExpressionParameters), false);
                    rootMenuToAppendTo = (VRCExpressionsMenu)EditorGUILayout.ObjectField("Root Menu", rootMenuToAppendTo, typeof(VRCExpressionsMenu), false);
                    appendSubMenuToRoot = EditorGUILayout.Toggle("Append Submenu To Root", appendSubMenuToRoot);
                }
            }

            EditorGUILayout.Space();
            generationSettingsFoldout = EditorGUILayout.Foldout(generationSettingsFoldout, "Generation Settings", true);
            if (generationSettingsFoldout)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
#if !PUDDLES_EXPERIMENTAL_TOOLS
                    DrawActionProfileField(true);
                    runName = EditorGUILayout.TextField("Run Name", runName);
#else
                    outputFolder = EditorGUILayout.TextField("Output Folder", outputFolder);
                    runName = EditorGUILayout.TextField("Run Name", runName);
                    parameterPrefix = EditorGUILayout.TextField("Parameter Prefix", parameterPrefix);
#endif
                    savedParameters = DrawHelpToggle("Saved Parameters", savedParameters, "Remembers the dial value across worlds and avatar reloads.");
                    syncedParameters = DrawHelpToggle("Synced Parameters", syncedParameters, "Shows the dial result to other users instead of only changing it locally.");
                    scanOnlyActiveShaderFields = DrawHelpToggle("Scan Only Active Fields", scanOnlyActiveShaderFields, "Only shows shader settings whose Poiyomi parent feature appears enabled.");
                    scanOnlyAnimatedFields = DrawHelpToggle("Scan Only Animated Fields", scanOnlyAnimatedFields, "Only shows Poiyomi fields marked animatable on the material.");
                    scanAllFloatRangeProperties = DrawHelpToggle("Scan All Float/Range Properties", scanAllFloatRangeProperties, "Shows all numeric shader sliders, not just lighting-looking settings.");
                    useUnityAnimatableBindings = DrawHelpToggle("Use Unity Animatable Bindings", useUnityAnimatableBindings, "Uses Unity's reported animation paths when possible for better material binding accuracy.");
                    groupSelectedBySetting = DrawHelpToggle("Group Selected By Setting", groupSelectedBySetting, "Combines matching selected settings into one shared radial, such as all Max Brightness.");
#if PUDDLES_EXPERIMENTAL_TOOLS
                    generationMode = (PoiyomiGenerationMode)DrawHelpEnumPopup("Output Mode", generationMode, GetGenerationModeDescription(generationMode));
#else
                    generationMode = DrawReleaseGenerationModePopup(generationMode, GetGenerationModeDescription(generationMode));
#endif
                    bool usesActionBuilder = generationMode != PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly;
#if PUDDLES_EXPERIMENTAL_TOOLS
                    using (new EditorGUI.DisabledScope(!usesActionBuilder))
                    {
                        DrawActionProfileField(usesActionBuilder);
                    }

                    using (new EditorGUI.DisabledScope(generationMode != PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly))
                    {
                        cleanOutputFolderBeforeGenerate = DrawHelpToggle("Clean Output Folder", cleanOutputFolderBeforeGenerate, "Legacy mode only. Deletes this run's old generated Poiyomi assets before rebuilding.");
                        mergeWithExistingRun = DrawHelpToggle("Merge Existing Run", mergeWithExistingRun, "Legacy mode only. Keeps previous controls from the same run when adding new ones.");
                        organizeMenusByCategory = DrawHelpToggle("Organize By Category", organizeMenusByCategory, "Legacy mode only. Sorts generated dials into Lighting, Emission, Matcap, and similar submenus.");
                    }
#endif

                    logGeneratedClipBindings = DrawHelpToggle("Log Clip Bindings", logGeneratedClipBindings, "Prints generated animation curve paths to the Console for troubleshooting.");
                }
            }

            EditorGUILayout.Space();
            debugToolsFoldout = EditorGUILayout.Foldout(debugToolsFoldout, "Debug Tools", true);
            if (debugToolsFoldout)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    debugAnimationClip = (AnimationClip)EditorGUILayout.ObjectField("Debug Animation Clip", debugAnimationClip, typeof(AnimationClip), false);
                    using (new EditorGUI.DisabledScope(debugAnimationClip == null))
                    {
                        if (GUILayout.Button("Log Debug Clip Bindings"))
                        {
                            LogDebugClipBindings();
                        }
                    }
                }
            }

            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Scan Avatar Materials", GUILayout.Height(28)))
                {
                    ScanAvatar();
                }

                using (new EditorGUI.DisabledScope(!CanGenerate()))
                {
                    if (GUILayout.Button(GetGenerateButtonLabel(), GUILayout.Height(28)))
                    {
                        GenerateAssets();
                    }
                }
            }

            DrawControls();
        }

        private static bool DrawHelpToggle(string label, bool value, string tooltip)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(label, GUILayout.Width(EditorGUIUtility.labelWidth - 4f));
                value = EditorGUILayout.Toggle(value, GUILayout.Width(18f));
                DrawHelpText(tooltip);
                GUILayout.FlexibleSpace();
            }

            return value;
        }

        private void DrawActionProfileField(bool usesActionBuilder)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                actionProfile = (PuddlesAvatarActionProfile)EditorGUILayout.ObjectField("Action Profile", actionProfile, typeof(PuddlesAvatarActionProfile), false);
                if (usesActionBuilder && actionProfile == null)
                {
                    GUIStyle warningStyle = new GUIStyle(EditorStyles.boldLabel)
                    {
                        normal = { textColor = Color.red },
                        alignment = TextAnchor.MiddleCenter
                    };
                    GUILayout.Label(new GUIContent("X", "No profile assigned. One will be auto-created when you generate."), warningStyle, GUILayout.Width(20f));
                }
                else
                {
                    GUILayout.Space(20f);
                }

                DrawHelpText("If blank, an Action Builder profile is created under Assets/PuddlesVrcTools/Profiles. Action Builder naming is used for parameters, layers, clips, and menus.");
            }
        }

        private static Enum DrawHelpEnumPopup(string label, Enum value, string tooltip)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                value = EditorGUILayout.EnumPopup(label, value);
                DrawHelpText(tooltip);
            }

            return value;
        }

        private static PoiyomiGenerationMode DrawReleaseGenerationModePopup(PoiyomiGenerationMode value, string tooltip)
        {
            PoiyomiGenerationMode[] modes =
            {
                PoiyomiGenerationMode.AddToActionBuilderAndGenerate,
                PoiyomiGenerationMode.AddToActionBuilderOnly
            };
            string[] labels =
            {
                "Add To Action Builder And Generate",
                "Add To Action Builder"
            };

            int index = Array.IndexOf(modes, value);
            if (index < 0)
            {
                index = 0;
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                index = EditorGUILayout.Popup("Output Mode", index, labels);
                DrawHelpText(tooltip);
            }

            return modes[index];
        }

        private void NormalizeGenerationModeForRelease()
        {
#if !PUDDLES_EXPERIMENTAL_TOOLS
            if (generationMode == PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly)
            {
                generationMode = PoiyomiGenerationMode.AddToActionBuilderAndGenerate;
            }
#endif
        }

        private static void DrawHelpText(string tooltip)
        {
            GUIContent helpContent = new GUIContent("?", tooltip);
            GUILayout.Label(helpContent, EditorStyles.miniButton, GUILayout.Width(20f), GUILayout.Height(EditorGUIUtility.singleLineHeight));
        }

        private static string GetGenerationModeDescription(PoiyomiGenerationMode mode)
        {
            switch (mode)
            {
                case PoiyomiGenerationMode.AddToActionBuilderOnly:
                    return "Creates or updates editable Action Builder controls, but does not generate menu/FX assets yet.";
                case PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly:
                    return "Uses the older standalone Poiyomi generator with Puddles/Lighting assets and menus.";
                default:
                    return "Creates or updates Action Builder controls, then immediately generates them with Action Builder naming.";
            }
        }

        private void DrawControls()
        {
            EditorGUILayout.Space();
            controlsFoldout = EditorGUILayout.Foldout(controlsFoldout, $"Detected Controls ({controls.Count})", true);
            if (!controlsFoldout)
            {
                return;
            }

            if (controls.Count == 0)
            {
                EditorGUILayout.HelpBox("No controls scanned yet. Assign an avatar root, then scan.", MessageType.None);
                return;
            }

            DrawFilters();
            List<PropertyControl> visibleControls = GetVisibleControls().ToList();
            EditorGUILayout.LabelField($"Showing {visibleControls.Count} controls", EditorStyles.miniLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(visibleControls.Count == 0))
                {
                    if (GUILayout.Button("Include Visible"))
                    {
                        foreach (PropertyControl control in visibleControls)
                        {
                            control.include = true;
                        }
                    }

                    if (GUILayout.Button("Exclude Visible"))
                    {
                        foreach (PropertyControl control in visibleControls)
                        {
                            control.include = false;
                        }
                    }
                }
            }

            scroll = EditorGUILayout.BeginScrollView(scroll);
            foreach (PropertyControl control in visibleControls)
            {
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        control.include = EditorGUILayout.Toggle(control.include, GUILayout.Width(20));
                        control.displayName = EditorGUILayout.TextField(control.displayName);
                    }

                    using (new EditorGUI.DisabledScope(true))
                    {
                        EditorGUILayout.ObjectField("Material", control.material, typeof(Material), false);
                    }

                    EditorGUILayout.LabelField("Shader", control.shaderName);
                    EditorGUILayout.LabelField("Category", control.categoryName);
                    EditorGUILayout.LabelField("Shader Property", control.propertyName);
                    EditorGUILayout.LabelField("Original Value", control.originalValue.ToString("0.###"));

                    EditorGUI.BeginChangeCheck();
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        control.minValue = EditorGUILayout.FloatField("Radial 0", control.minValue);
                        control.maxValue = EditorGUILayout.FloatField("Radial 1", control.maxValue);
                    }

                    if (EditorGUI.EndChangeCheck() && control.defaultFromOriginal)
                    {
                        control.defaultValue = Normalize01(control.originalValue, control.minValue, control.maxValue);
                    }

                    control.defaultFromOriginal = EditorGUILayout.Toggle("Default From Original", control.defaultFromOriginal);
                    using (new EditorGUI.DisabledScope(control.defaultFromOriginal))
                    {
                        control.defaultValue = EditorGUILayout.Slider("Default", control.defaultValue, 0f, 1f);
                    }

                    if (control.defaultFromOriginal)
                    {
                        RefreshDefaultValueFromMaterial(control);
                    }

                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button("Preview 0"))
                        {
                            PreviewControlValue(control, control.minValue);
                        }

                        if (GUILayout.Button("Preview 1"))
                        {
                            PreviewControlValue(control, control.maxValue);
                        }

                        if (GUILayout.Button("Restore Original"))
                        {
                            PreviewControlValue(control, control.originalValue);
                        }
                    }
                }
            }

            EditorGUILayout.EndScrollView();
        }

        private void DrawFilters()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Filters", EditorStyles.boldLabel);
            searchText = EditorGUILayout.TextField("Search", searchText);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Min Brightness"))
                {
                    searchText = "min brightness";
                }

                if (GUILayout.Button("Max Brightness"))
                {
                    searchText = "max brightness";
                }

                if (GUILayout.Button("Mono/Gray"))
                {
                    searchText = "mono";
                }
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Directional"))
                {
                    searchText = "direction";
                }

                if (GUILayout.Button("Point"))
                {
                    searchText = "point";
                }

                if (GUILayout.Button("Emission"))
                {
                    searchText = "emission";
                }
            }

            List<string> materialOptions = new List<string> { AllMaterialsFilter };
            materialOptions.AddRange(controls
                .Select(control => control.materialName)
                .Distinct()
                .OrderBy(name => name));

            int currentIndex = Mathf.Max(0, materialOptions.IndexOf(materialFilter));
            int nextIndex = EditorGUILayout.Popup("Material", currentIndex, materialOptions.ToArray());
            materialFilter = materialOptions[nextIndex];
            showIncludedOnly = EditorGUILayout.Toggle("Show Included Only", showIncludedOnly);
        }

        private IEnumerable<PropertyControl> GetVisibleControls()
        {
            string search = searchText.Trim();
            foreach (PropertyControl control in controls)
            {
                if (showIncludedOnly && !control.include)
                {
                    continue;
                }

                if (materialFilter != AllMaterialsFilter && control.materialName != materialFilter)
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(search) && !MatchesSearch(control, search))
                {
                    continue;
                }

                yield return control;
            }
        }

        private static bool MatchesSearch(PropertyControl control, string search)
        {
            return ContainsIgnoreCase(control.displayName, search)
                || ContainsIgnoreCase(control.propertyName, search)
                || ContainsIgnoreCase(control.materialName, search)
                || ContainsIgnoreCase(control.shaderName, search)
                || ContainsIgnoreCase(control.categoryName, search);
        }

        private bool CanGenerate()
        {
            bool usesActionBuilder = generationMode != PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly;
            return avatarRoot != null
                && fxController != null
                && expressionParameters != null
                && (!usesActionBuilder || rootMenuToAppendTo != null)
                && (usesActionBuilder || !string.IsNullOrWhiteSpace(outputFolder))
                && (usesActionBuilder || !string.IsNullOrWhiteSpace(parameterPrefix))
                && controls.Any(control => control.include);
        }

        private string GetGenerateButtonLabel()
        {
            switch (generationMode)
            {
                case PoiyomiGenerationMode.AddToActionBuilderOnly:
                    return "Add To Action Builder";
                case PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly:
                    return "Generate Legacy Poiyomi Assets";
                default:
                    return "Add To Action Builder And Generate";
            }
        }

        private void AutoFillFromAvatarDescriptor()
        {
            VRCAvatarDescriptor descriptor = avatarRoot.GetComponent<VRCAvatarDescriptor>();
            if (descriptor == null)
            {
                EditorUtility.DisplayDialog("Poiyomi Lighting Menu Builder", "No VRCAvatarDescriptor was found on the avatar root.", "OK");
                return;
            }

            expressionParameters = descriptor.expressionParameters;
            rootMenuToAppendTo = descriptor.expressionsMenu;

            if (descriptor.baseAnimationLayers == null)
            {
                return;
            }

            foreach (var layer in descriptor.baseAnimationLayers)
            {
                if (layer.type != VRCAvatarDescriptor.AnimLayerType.FX || layer.animatorController == null)
                {
                    continue;
                }

                fxController = layer.animatorController as AnimatorController;
                break;
            }
        }

        private void ScanAvatar()
        {
            controls.Clear();

            if (avatarRoot == null)
            {
                EditorUtility.DisplayDialog("Poiyomi Lighting Menu Builder", "Assign an avatar root first.", "OK");
                return;
            }

            Renderer[] renderers = avatarRoot.GetComponentsInChildren<Renderer>(true);
            Dictionary<string, PropertyControl> byTarget = new Dictionary<string, PropertyControl>();
            int skippedInactiveFields = 0;

            foreach (Renderer renderer in renderers)
            {
                foreach (Material material in renderer.sharedMaterials)
                {
                    if (material == null || material.shader == null || !LooksLikePoiyomi(material.shader))
                    {
                        continue;
                    }

                    Shader shader = material.shader;
                    int propertyCount = ShaderUtil.GetPropertyCount(shader);
                    string currentCategory = "Other";
                    List<string> sectionStack = new List<string>();
                    for (int i = 0; i < propertyCount; i++)
                    {
                        string propertyName = ShaderUtil.GetPropertyName(shader, i);
                        string description = ShaderUtil.GetPropertyDescription(shader, i);

                        if (TryGetPoiyomiMajorCategory(propertyName, description, out string majorCategory))
                        {
                            currentCategory = majorCategory;
                            sectionStack.Clear();
                            continue;
                        }

                        if (TryGetPoiyomiSectionStart(propertyName, description, out string sectionName))
                        {
                            sectionStack.Add(sectionName);
                            continue;
                        }

                        if (IsPoiyomiSectionEnd(propertyName))
                        {
                            if (sectionStack.Count > 0)
                            {
                                sectionStack.RemoveAt(sectionStack.Count - 1);
                            }

                            continue;
                        }

                        if (IsPoiyomiUiMarkerProperty(propertyName))
                        {
                            continue;
                        }

                        ShaderUtil.ShaderPropertyType type = ShaderUtil.GetPropertyType(shader, i);
                        if (type != ShaderUtil.ShaderPropertyType.Float && type != ShaderUtil.ShaderPropertyType.Range)
                        {
                            continue;
                        }

                        if (scanOnlyActiveShaderFields && !IsShaderFieldActive(material, propertyName, description))
                        {
                            skippedInactiveFields++;
                            continue;
                        }

                        if (!scanAllFloatRangeProperties && !LooksLightingRelated(propertyName, description))
                        {
                            continue;
                        }

                        if (!material.HasProperty(propertyName))
                        {
                            continue;
                        }

                        if (scanOnlyAnimatedFields && !IsPoiyomiAnimatedField(material, propertyName))
                        {
                            continue;
                        }

                        string targetKey = $"{material.GetInstanceID()}:{propertyName}";
                        if (!byTarget.TryGetValue(targetKey, out PropertyControl control))
                        {
                            float currentValue = material.GetFloat(propertyName);
                            float minValue = type == ShaderUtil.ShaderPropertyType.Range ? TryGetRangeLimit(shader, i, 1, 0f) : 0f;
                            float maxValue = type == ShaderUtil.ShaderPropertyType.Range ? TryGetRangeLimit(shader, i, 2, Mathf.Max(1f, currentValue)) : Mathf.Max(1f, currentValue);
                            if (Mathf.Approximately(minValue, maxValue))
                            {
                                minValue = 0f;
                                maxValue = Mathf.Max(1f, currentValue);
                            }

                            control = new PropertyControl
                            {
                                include = false,
                                material = material,
                                materialName = material.name,
                                shaderName = shader.name,
                                propertyName = propertyName,
                                displayName = NicifyControlName(description, propertyName),
                                categoryName = ResolveMenuCategory(propertyName, description, currentCategory, sectionStack),
                                originalValue = currentValue,
                                minValue = minValue,
                                maxValue = maxValue,
                                defaultValue = Normalize01(currentValue, minValue, maxValue),
                                defaultFromOriginal = true
                            };

                            byTarget.Add(targetKey, control);
                        }
                    }
                }
            }

            controls.AddRange(byTarget.Values
                .OrderBy(control => control.materialName)
                .ThenBy(control => control.displayName));

            if (scanOnlyActiveShaderFields && skippedInactiveFields > 0)
            {
                Debug.Log($"Poiyomi Lighting Menu Builder: Skipped {skippedInactiveFields} inactive shader fields during scan.");
            }

            if (controls.Count == 0)
            {
                EditorUtility.DisplayDialog(
                    "Poiyomi Lighting Menu Builder",
                    "No Poiyomi lighting float/range properties were found on the avatar. Make sure the avatar has renderers using Poiyomi materials.",
                    "OK");
            }
        }

        private void LogDebugClipBindings()
        {
            if (debugAnimationClip == null)
            {
                return;
            }

            EditorCurveBinding[] bindings = AnimationUtility.GetCurveBindings(debugAnimationClip);
            Debug.Log($"Poiyomi Lighting Menu Builder: {debugAnimationClip.name} has {bindings.Length} float curve bindings.");
            foreach (EditorCurveBinding binding in bindings)
            {
                Debug.Log($"Poiyomi Lighting Menu Builder Binding: path='{binding.path}', type='{binding.type}', property='{binding.propertyName}'");
            }
        }

        private static void PreviewControlValue(PropertyControl control, float value)
        {
            if (control.material == null || !control.material.HasProperty(control.propertyName))
            {
                Debug.LogWarning($"Poiyomi Lighting Menu Builder: Cannot preview {control.displayName}; material or property is missing.");
                return;
            }

            Undo.RecordObject(control.material, $"Preview {control.displayName}");
            control.material.SetFloat(control.propertyName, value);
            EditorUtility.SetDirty(control.material);
            Debug.LogWarning(
                "Poiyomi Lighting Menu Builder Preview: "
                + $"material='{control.materialName}', display='{control.displayName}', property='{control.propertyName}', value={value}");
        }

        private static void LogSelectedControls(IEnumerable<PropertyControl> includedControls)
        {
            foreach (PropertyControl control in includedControls)
            {
                Debug.LogWarning(
                    "Poiyomi Lighting Menu Builder Selected: "
                    + $"material='{control.materialName}', display='{control.displayName}', property='{control.propertyName}', "
                    + $"original={control.originalValue}, radial0={control.minValue}, radial1={control.maxValue}, default={control.defaultValue}");
            }
        }

        private static void LogClipBindings(AnimationClip clip, GeneratedControl control, string suffix)
        {
            EditorCurveBinding[] bindings = AnimationUtility.GetCurveBindings(clip);
            Debug.LogWarning(
                "Poiyomi Lighting Menu Builder Generated Clip: "
                + $"clip='{clip.name}', suffix='{suffix}', group='{control.menuPrefix}', display='{control.displayName}', "
                + $"targets={control.targets.Count}, bindingCount={bindings.Length}");

            foreach (EditorCurveBinding binding in bindings)
            {
                AnimationCurve curve = AnimationUtility.GetEditorCurve(clip, binding);
                string firstValue = curve != null && curve.keys.Length > 0 ? curve.keys[0].value.ToString("0.###") : "none";
                Debug.LogWarning(
                    "Poiyomi Lighting Menu Builder Generated Binding: "
                    + $"clip='{clip.name}', path='{binding.path}', type='{binding.type}', property='{binding.propertyName}', firstValue={firstValue}");
            }
        }

        private void GenerateAssets()
        {
            NormalizeGenerationModeForRelease();

            generationWarnings.Clear();
            generationNotes.Clear();

            if (generationMode == PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly && !IsProjectAssetFolder(outputFolder))
            {
                EditorUtility.DisplayDialog(
                    "Poiyomi Lighting Menu Builder",
                    "Output Folder must be inside Assets, for example:\nAssets/PuddlesVrcTools/Generated/PoiyomiLighting",
                    "OK");
                return;
            }

            string generationFolder = generationMode == PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly ? GetGenerationFolder() : string.Empty;
            if (generationMode == PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly
                && cleanOutputFolderBeforeGenerate
                && AssetDatabase.IsValidFolder(generationFolder))
            {
                AssetDatabase.DeleteAsset(generationFolder);
            }

            if (generationMode == PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly)
            {
                EnsureFolder(generationFolder);
            }

            List<PropertyControl> includedControls = controls.Where(control => control.include).ToList();
            foreach (PropertyControl control in includedControls.Where(control => control.defaultFromOriginal))
            {
                RefreshDefaultValueFromMaterial(control);
            }

            List<GeneratedControl> generatedControls = BuildGeneratedControls(includedControls);

            if (logGeneratedClipBindings)
            {
                LogSelectedControls(includedControls);
            }

            if (generationMode == PoiyomiGenerationMode.LegacyPoiyomiAssetsOnly)
            {
                Dictionary<GeneratedControl, string> parameterNamesByControl = BuildParameterNames(generatedControls);
                HashSet<string> removedConflictingParameters = RemoveConflictingGeneratedAnimatorLayers(generatedControls, parameterNamesByControl);
                RemoveExpressionParameters(removedConflictingParameters);

                AddExpressionParameters(generatedControls, parameterNamesByControl);
                CreateAnimatorLayers(generatedControls, parameterNamesByControl, generationFolder);
                VRCExpressionsMenu generatedMenu = CreateExpressionMenus(generatedControls, parameterNamesByControl, generationFolder, removedConflictingParameters);

                if (appendSubMenuToRoot && rootMenuToAppendTo != null)
                {
                    AppendSubMenu(rootMenuToAppendTo, generatedMenu);
                }
            }
            else
            {
                List<PuddlesAvatarActionControl> syncedControls = SyncGeneratedControlsToActionProfile(generatedControls);
                if (generationMode == PoiyomiGenerationMode.AddToActionBuilderAndGenerate && syncedControls.Count > 0)
                {
                    bool generatedSuccessfully = AvatarActionBuilderWindow.GenerateControlsForProfile(actionProfile, syncedControls, false);
                    if (generatedSuccessfully)
                    {
                        generationNotes.Add($"Generated {syncedControls.Count} Action Builder radial control(s) using Action Builder naming.");
                    }
                    else
                    {
                        generationWarnings.Add("Action Builder generation failed. The controls were synced to the profile but no generated Action Builder assets were created.");
                    }
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            EditorUtility.DisplayDialog(
                "Poiyomi Lighting Menu Builder",
                BuildGenerationMessage(generatedControls.Count, generationFolder),
                "OK");
        }

        private List<GeneratedControl> BuildGeneratedControls(List<PropertyControl> includedControls)
        {
            if (!groupSelectedBySetting)
            {
                return includedControls
                    .Select(control => new GeneratedControl(control.displayName, control.materialName, control.categoryName, new List<PropertyControl> { control }))
                    .OrderBy(control => control.categoryName)
                    .ThenBy(control => control.menuPrefix)
                    .ThenBy(control => control.displayName)
                    .ToList();
            }

            return includedControls
                .GroupBy(control => SanitizeParameterName(control.displayName), StringComparer.OrdinalIgnoreCase)
                .Select(group =>
                {
                    List<PropertyControl> targets = group.ToList();
                    PropertyControl first = targets[0];
                    WarnIfGroupedRangesDiffer(first.displayName, targets);
                    return new GeneratedControl(first.displayName, "All", ResolveGroupedCategory(targets), targets);
                })
                .OrderBy(control => control.categoryName)
                .ThenBy(control => control.displayName)
                .ToList();
        }

        private Dictionary<GeneratedControl, string> BuildParameterNames(IEnumerable<GeneratedControl> generatedControls)
        {
            Dictionary<GeneratedControl, string> names = new Dictionary<GeneratedControl, string>();
            HashSet<string> usedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string cleanPrefix = parameterPrefix.Trim().Trim('/');

            foreach (GeneratedControl control in generatedControls)
            {
                string baseName = $"{cleanPrefix}/{SanitizeParameterName(GetRunName())}/{SanitizeParameterName(control.menuPrefix)}/{SanitizeParameterName(control.displayName)}";
                string candidate = baseName;
                int suffix = 2;
                while (usedNames.Contains(candidate))
                {
                    candidate = $"{baseName}{suffix}";
                    suffix++;
                }

                usedNames.Add(candidate);
                names.Add(control, candidate);
            }

            return names;
        }

        private void AddExpressionParameters(List<GeneratedControl> generatedControls, Dictionary<GeneratedControl, string> parameterNamesByControl)
        {
            List<VRCExpressionParameters.Parameter> parameters = expressionParameters.parameters != null
                ? expressionParameters.parameters.ToList()
                : new List<VRCExpressionParameters.Parameter>();

            foreach (GeneratedControl control in generatedControls)
            {
                string parameterName = parameterNamesByControl[control];
                VRCExpressionParameters.Parameter existing = parameters.FirstOrDefault(parameter => parameter.name == parameterName);
                if (existing != null)
                {
                    existing.valueType = VRCExpressionParameters.ValueType.Float;
                    existing.defaultValue = control.defaultValue;
                    existing.saved = savedParameters;
                    existing.networkSynced = syncedParameters;
                    continue;
                }

                parameters.Add(new VRCExpressionParameters.Parameter
                {
                    name = parameterName,
                    valueType = VRCExpressionParameters.ValueType.Float,
                    defaultValue = control.defaultValue,
                    saved = savedParameters,
                    networkSynced = syncedParameters
                });
            }

            expressionParameters.parameters = parameters.ToArray();
            EditorUtility.SetDirty(expressionParameters);
        }

        private void RemoveExpressionParameters(HashSet<string> parameterNames)
        {
            if (parameterNames == null || parameterNames.Count == 0 || expressionParameters.parameters == null)
            {
                return;
            }

            int beforeCount = expressionParameters.parameters.Length;
            expressionParameters.parameters = expressionParameters.parameters
                .Where(parameter => parameter == null || !parameterNames.Contains(parameter.name))
                .ToArray();

            if (expressionParameters.parameters.Length != beforeCount)
            {
                EditorUtility.SetDirty(expressionParameters);
            }
        }

        private HashSet<string> RemoveConflictingGeneratedAnimatorLayers(List<GeneratedControl> generatedControls, Dictionary<GeneratedControl, string> parameterNamesByControl)
        {
            HashSet<string> removedParameters = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> targetBindingKeys = BuildGeneratedTargetBindingKeys(generatedControls);
            if (targetBindingKeys.Count == 0)
            {
                return removedParameters;
            }

            HashSet<string> currentLayerNames = new HashSet<string>(
                generatedControls.Select(BuildAnimatorLayerName),
                StringComparer.OrdinalIgnoreCase);
            HashSet<string> currentParameterNames = new HashSet<string>(parameterNamesByControl.Values, StringComparer.OrdinalIgnoreCase);
            string layerPrefix = $"Puddles {GetRunName()} ";
            AnimatorControllerLayer[] layers = fxController.layers;
            int removedLayerCount = 0;

            for (int i = layers.Length - 1; i >= 0; i--)
            {
                AnimatorControllerLayer layer = layers[i];
                if (layer == null
                    || string.IsNullOrWhiteSpace(layer.name)
                    || !layer.name.StartsWith(layerPrefix, StringComparison.OrdinalIgnoreCase)
                    || currentLayerNames.Contains(layer.name))
                {
                    continue;
                }

                string layerParameter = FindFirstBlendParameter(layer);
                if (!string.IsNullOrWhiteSpace(layerParameter) && currentParameterNames.Contains(layerParameter))
                {
                    continue;
                }

                if (!LayerWritesAnyBinding(layer, targetBindingKeys))
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(layerParameter))
                {
                    removedParameters.Add(layerParameter);
                    RemoveAnimatorParameter(layerParameter);
                }

                fxController.RemoveLayer(i);
                removedLayerCount++;
            }

            if (removedLayerCount > 0)
            {
                generationWarnings.Add($"Removed {removedLayerCount} older generated layer(s) from this run because they animated the same material properties as the newly generated controls.");
                EditorUtility.SetDirty(fxController);
            }

            return removedParameters;
        }

        private HashSet<string> BuildGeneratedTargetBindingKeys(IEnumerable<GeneratedControl> generatedControls)
        {
            HashSet<string> bindingKeys = new HashSet<string>(StringComparer.Ordinal);
            Renderer[] renderers = avatarRoot.GetComponentsInChildren<Renderer>(true);

            foreach (GeneratedControl generatedControl in generatedControls)
            {
                foreach (PropertyControl control in generatedControl.targets)
                {
                    foreach (Renderer renderer in renderers)
                    {
                        List<int> materialSlots = FindMaterialSlots(renderer, control);
                        if (materialSlots.Count == 0)
                        {
                            continue;
                        }

                        string relativePath = AnimationUtility.CalculateTransformPath(renderer.transform, avatarRoot.transform);
                        foreach (int materialSlot in materialSlots)
                        {
                            string animatedPropertyName = GetAnimatedMaterialPropertyName(control.propertyName, materialSlot);
                            foreach (Type rendererType in GetRendererBindingTypes(renderer))
                            {
                                EditorCurveBinding binding = EditorCurveBinding.FloatCurve(relativePath, rendererType, animatedPropertyName);
                                bindingKeys.Add(GetBindingKey(binding));
                            }
                        }
                    }
                }
            }

            return bindingKeys;
        }

        private static IEnumerable<Type> GetRendererBindingTypes(Renderer renderer)
        {
            yield return renderer.GetType();
            yield return typeof(Renderer);

            if (renderer is SkinnedMeshRenderer)
            {
                yield return typeof(SkinnedMeshRenderer);
            }
            else if (renderer is MeshRenderer)
            {
                yield return typeof(MeshRenderer);
            }
        }

        private void CreateAnimatorLayers(List<GeneratedControl> generatedControls, Dictionary<GeneratedControl, string> parameterNamesByControl, string generationFolder)
        {
            foreach (GeneratedControl control in generatedControls)
            {
                string parameterName = parameterNamesByControl[control];
                EnsureAnimatorParameter(parameterName);

                string layerName = BuildAnimatorLayerName(control);
                RemoveLayerIfPresent(layerName);

                AnimationClip minClip = CreateClip(control, false, generationFolder);
                AnimationClip maxClip = CreateClip(control, true, generationFolder);

                fxController.AddLayer(layerName);
                AnimatorControllerLayer[] layers = fxController.layers;
                AnimatorControllerLayer layer = layers[layers.Length - 1];
                layer.defaultWeight = 1f;
                layers[layers.Length - 1] = layer;
                fxController.layers = layers;

                AnimatorStateMachine stateMachine = fxController.layers[fxController.layers.Length - 1].stateMachine;
                AnimatorState state = stateMachine.AddState("Blend");
                state.writeDefaultValues = false;
                stateMachine.defaultState = state;

                BlendTree blendTree = new BlendTree
                {
                    name = $"{SanitizeAssetName(control.displayName)} Blend",
                    blendType = BlendTreeType.Simple1D,
                    blendParameter = parameterName,
                    useAutomaticThresholds = false
                };

                AssetDatabase.AddObjectToAsset(blendTree, fxController);
                blendTree.AddChild(minClip, 0f);
                blendTree.AddChild(maxClip, 1f);
                state.motion = blendTree;
                EditorUtility.SetDirty(fxController);
            }
        }

        private AnimationClip CreateClip(GeneratedControl generatedControl, bool useMaxValue, string generationFolder)
        {
            string suffix = useMaxValue ? "Max" : "Min";
            string clipPath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(
                generationFolder,
                $"{SanitizeAssetName(generatedControl.menuPrefix)} {SanitizeAssetName(generatedControl.displayName)} {suffix}.anim").Replace("\\", "/"));

            AnimationClip clip = new AnimationClip
            {
                name = Path.GetFileNameWithoutExtension(clipPath),
                frameRate = 60f
            };

            Renderer[] renderers = avatarRoot.GetComponentsInChildren<Renderer>(true);
            int curveCount = 0;

            foreach (PropertyControl control in generatedControl.targets)
            {
                float value = useMaxValue ? control.maxValue : control.minValue;
                AnimationCurve curve = AnimationCurve.Constant(0f, 1f / 60f, value);

                foreach (Renderer renderer in renderers)
                {
                    List<int> materialSlots = FindMaterialSlots(renderer, control);
                    if (materialSlots.Count == 0)
                    {
                        continue;
                    }

                    string relativePath = AnimationUtility.CalculateTransformPath(renderer.transform, avatarRoot.transform);
                    HashSet<string> writtenBindings = new HashSet<string>(StringComparer.Ordinal);
                    int rendererCurveCount = 0;

                    if (useUnityAnimatableBindings)
                    {
                        foreach (EditorCurveBinding binding in FindUnityMaterialBindings(renderer, avatarRoot, control, relativePath, materialSlots))
                        {
                            AnimationUtility.SetEditorCurve(clip, binding, curve);
                            writtenBindings.Add(GetBindingKey(binding));
                            curveCount++;
                            rendererCurveCount++;
                        }
                    }

                    if (rendererCurveCount == 0)
                    {
                        foreach (int materialSlot in materialSlots)
                        {
                            foreach (EditorCurveBinding binding in CreateFallbackMaterialBindings(renderer, relativePath, control.propertyName, materialSlot))
                            {
                                if (!writtenBindings.Add(GetBindingKey(binding)))
                                {
                                    continue;
                                }

                                AnimationUtility.SetEditorCurve(clip, binding, curve);
                                curveCount++;
                                rendererCurveCount++;
                            }
                        }
                    }
                }
            }

            EditorUtility.SetDirty(clip);

            if (curveCount == 0)
            {
                generationWarnings.Add($"No animation binding found for {generatedControl.menuPrefix} / {generatedControl.displayName}.");
            }
            else if (curveCount > 1)
            {
                Debug.Log($"Poiyomi Lighting Menu Builder: Wrote {curveCount} curves for {generatedControl.menuPrefix} / {generatedControl.displayName}.");
            }

            AssetDatabase.CreateAsset(clip, clipPath);

            if (logGeneratedClipBindings)
            {
                LogClipBindings(clip, generatedControl, suffix);
            }

            return clip;
        }

        private VRCExpressionsMenu CreateExpressionMenus(
            List<GeneratedControl> generatedControls,
            Dictionary<GeneratedControl, string> parameterNamesByControl,
            string generationFolder,
            HashSet<string> removedConflictingParameters)
        {
            string rootPath = Path.Combine(generationFolder, $"{SanitizeAssetName(GetRunName())} Menu.asset").Replace("\\", "/");
            VRCExpressionsMenu generatedRoot = LoadOrCreateRunMenu(rootPath);

            if (removedConflictingParameters != null)
            {
                foreach (string removedParameter in removedConflictingParameters)
                {
                    RemoveMenuControlByParameter(generatedRoot, removedParameter);
                }
            }

            HashSet<string> existingParameters = CollectMenuParameterNames(generatedRoot);
            int addedControls = 0;
            foreach (GeneratedControl control in generatedControls)
            {
                string parameterName = parameterNamesByControl[control];
                if (existingParameters.Contains(parameterName))
                {
                    if (organizeMenusByCategory)
                    {
                        RemoveMenuControlByParameter(generatedRoot, parameterName);
                        existingParameters.Remove(parameterName);
                    }
                    else
                    {
                        UpdateExistingMenuControlName(generatedRoot, parameterName, BuildControlMenuName(control));
                        continue;
                    }
                }

                VRCExpressionsMenu targetMenu = organizeMenusByCategory
                    ? FindOrCreateCategoryMenu(generatedRoot, control.categoryName, generationFolder)
                    : generatedRoot;

                if (targetMenu == null)
                {
                    generationWarnings.Add($"Could not add menu control for '{control.displayName}' because the generated category menu capacity was reached.");
                    continue;
                }

                string pagePrefix = organizeMenusByCategory ? control.categoryName : null;
                if (TryAddRadialControlToMenu(targetMenu, CreateRadialControl(control, parameterName), generationFolder, pagePrefix))
                {
                    existingParameters.Add(parameterName);
                    addedControls++;
                }
                else
                {
                    generationWarnings.Add($"Could not add menu control for '{control.displayName}' because generated menu capacity was reached.");
                }
            }

            if (mergeWithExistingRun && !organizeMenusByCategory && addedControls != generatedControls.Count)
            {
                int skippedControls = generatedControls.Count - addedControls;
                if (skippedControls > 0)
                {
                    generationWarnings.Add($"Skipped {skippedControls} generated menu controls that already existed in this run.");
                }
            }

            EditorUtility.SetDirty(generatedRoot);
            return generatedRoot;
        }

        private List<PuddlesAvatarActionControl> SyncGeneratedControlsToActionProfile(List<GeneratedControl> generatedControls)
        {
            if (generatedControls == null || generatedControls.Count == 0)
            {
                return new List<PuddlesAvatarActionControl>();
            }

            PuddlesAvatarActionProfile profile = EnsureActionProfile();
            if (profile == null)
            {
                generationWarnings.Add("Could not sync to Action Builder because no Action Profile could be created or loaded.");
                return new List<PuddlesAvatarActionControl>();
            }

            if (profile.controls == null)
            {
                profile.controls = new List<PuddlesAvatarActionControl>();
            }

            Renderer[] renderers = avatarRoot != null
                ? avatarRoot.GetComponentsInChildren<Renderer>(true)
                : new Renderer[0];
            VRCExpressionsMenu destinationMenu = profile.lastDestinationMenu != null ? profile.lastDestinationMenu : profile.rootMenu;
            string destinationPath = !string.IsNullOrWhiteSpace(profile.lastDestinationPath) && profile.lastDestinationMenu != null
                ? profile.lastDestinationPath
                : "Root";
            int syncedCount = 0;
            List<PuddlesAvatarActionControl> syncedControls = new List<PuddlesAvatarActionControl>();

            foreach (GeneratedControl generatedControl in generatedControls)
            {
                string controlId = BuildActionControlId(generatedControl);
                PuddlesAvatarActionControl actionControl = profile.controls.FirstOrDefault(control => control.id == controlId);
                if (actionControl == null)
                {
                    actionControl = new PuddlesAvatarActionControl { id = controlId };
                    profile.controls.Add(actionControl);
                }

                actionControl.displayName = BuildControlMenuName(generatedControl);
                actionControl.controlType = PuddlesAvatarControlType.Radial;
                actionControl.radialMode = PuddlesAvatarRadialMode.TimeParameter;
                actionControl.radialDefaultValue = generatedControl.defaultValue;
                actionControl.saved = savedParameters;
                actionControl.synced = syncedParameters;
                actionControl.destinationMenu = destinationMenu;
                actionControl.destinationPath = destinationPath;
                actionControl.actions = BuildActionRowsForGeneratedControl(generatedControl, renderers);
                syncedControls.Add(actionControl);
                syncedCount++;
            }

            EditorUtility.SetDirty(profile);
            generationNotes.Add($"Synced {syncedCount} Poiyomi radial control(s) to Action Builder profile '{profile.name}'.");
            return syncedControls;
        }

        private PuddlesAvatarActionProfile EnsureActionProfile()
        {
            if (actionProfile == null)
            {
                EnsureFolder(DefaultActionProfileFolder);
                string profilePath = Path.Combine(DefaultActionProfileFolder, $"{SanitizeAssetName(GetRunName())} Poiyomi Action Profile.asset").Replace("\\", "/");
                actionProfile = AssetDatabase.LoadAssetAtPath<PuddlesAvatarActionProfile>(profilePath);
                if (actionProfile == null)
                {
                    actionProfile = CreateInstance<PuddlesAvatarActionProfile>();
                    actionProfile.outputFolder = "Assets/PuddlesVrcTools/Generated/AvatarActions";
                    actionProfile.parameterPrefix = DefaultActionParameterPrefix;
                    AssetDatabase.CreateAsset(actionProfile, AssetDatabase.GenerateUniqueAssetPath(profilePath));
                }
            }

            if (actionProfile.avatarRoot == null)
            {
                actionProfile.avatarRoot = avatarRoot;
            }

            if (actionProfile.fxController == null)
            {
                actionProfile.fxController = fxController;
            }

            if (actionProfile.expressionParameters == null)
            {
                actionProfile.expressionParameters = expressionParameters;
            }

            if (actionProfile.rootMenu == null)
            {
                actionProfile.rootMenu = rootMenuToAppendTo;
            }

            if (actionProfile.lastDestinationMenu == null && actionProfile.rootMenu != null)
            {
                actionProfile.lastDestinationMenu = actionProfile.rootMenu;
                actionProfile.lastDestinationPath = "Root";
            }

            if (string.IsNullOrWhiteSpace(actionProfile.parameterPrefix)
                || string.Equals(actionProfile.parameterPrefix.Trim(), DefaultParameterPrefix, StringComparison.OrdinalIgnoreCase))
            {
                actionProfile.parameterPrefix = DefaultActionParameterPrefix;
            }

            EditorUtility.SetDirty(actionProfile);
            return actionProfile;
        }

        private List<PuddlesAvatarActionRow> BuildActionRowsForGeneratedControl(GeneratedControl generatedControl, Renderer[] renderers)
        {
            List<PuddlesAvatarActionRow> rows = new List<PuddlesAvatarActionRow>();
            HashSet<string> rowKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (PropertyControl target in generatedControl.targets)
            {
                foreach (Renderer renderer in renderers)
                {
                    foreach (int materialSlot in FindMaterialSlots(renderer, target))
                    {
                        string rendererPath = AnimationUtility.CalculateTransformPath(renderer.transform, avatarRoot.transform);
                        string rowKey = $"{rendererPath}|{materialSlot}|{target.propertyName}";
                        if (!rowKeys.Add(rowKey))
                        {
                            continue;
                        }

                        rows.Add(new PuddlesAvatarActionRow
                        {
                            kind = PuddlesAvatarActionKind.ShaderFloat,
                            renderer = renderer,
                            rendererPath = rendererPath,
                            materialSlot = materialSlot,
                            shaderPropertyName = target.propertyName,
                            shaderPropertyPaste = materialSlot == 0 ? $"material.{target.propertyName}" : $"material.[{materialSlot}].{target.propertyName}",
                            offFloat = target.minValue,
                            onFloat = target.maxValue
                        });
                    }
                }
            }

            if (rows.Count == 0)
            {
                generationWarnings.Add($"Action Builder sync found no renderer slots for '{BuildControlMenuName(generatedControl)}'.");
            }

            return rows;
        }

        private string BuildActionControlId(GeneratedControl control)
        {
            string source = $"{GetRunName()}|{control.menuPrefix}|{control.displayName}|{string.Join("|", control.targets.Select(BuildActionTargetKey))}";
            uint hash = 2166136261;
            foreach (char character in source)
            {
                unchecked
                {
                    hash ^= character;
                    hash *= 16777619u;
                }
            }

            return $"poi{hash:x9}".Substring(0, 12);
        }

        private static string BuildActionTargetKey(PropertyControl control)
        {
            string materialPath = AssetDatabase.GetAssetPath(control.material);
            return $"{materialPath}|{control.materialName}|{control.propertyName}";
        }

        private static bool UpdateExistingMenuControlName(VRCExpressionsMenu menu, string parameterName, string menuControlName)
        {
            if (menu == null)
            {
                return false;
            }

            return UpdateExistingMenuControlName(menu, parameterName, menuControlName, new HashSet<VRCExpressionsMenu>());
        }

        private static bool UpdateExistingMenuControlName(VRCExpressionsMenu menu, string parameterName, string menuControlName, HashSet<VRCExpressionsMenu> visitedMenus)
        {
            if (menu == null || !visitedMenus.Add(menu))
            {
                return false;
            }

            EnsureMenuControlList(menu);
            for (int i = 0; i < menu.controls.Count; i++)
            {
                VRCExpressionsMenu.Control control = menu.controls[i];
                if (MenuControlUsesParameter(control, parameterName))
                {
                    if (control.name != menuControlName)
                    {
                        control.name = menuControlName;
                        menu.controls[i] = control;
                        EditorUtility.SetDirty(menu);
                    }

                    return true;
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                    && UpdateExistingMenuControlName(control.subMenu, parameterName, menuControlName, visitedMenus))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool MenuControlUsesParameter(VRCExpressionsMenu.Control control, string parameterName)
        {
            if (control.parameter != null && string.Equals(control.parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (control.subParameters == null)
            {
                return false;
            }

            return control.subParameters.Any(parameter =>
                parameter != null && string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private static bool RemoveMenuControlByParameter(VRCExpressionsMenu menu, string parameterName)
        {
            if (menu == null)
            {
                return false;
            }

            return RemoveMenuControlByParameter(menu, parameterName, new HashSet<VRCExpressionsMenu>());
        }

        private static bool RemoveMenuControlByParameter(VRCExpressionsMenu menu, string parameterName, HashSet<VRCExpressionsMenu> visitedMenus)
        {
            if (menu == null || !visitedMenus.Add(menu))
            {
                return false;
            }

            bool removed = false;
            EnsureMenuControlList(menu);
            for (int i = menu.controls.Count - 1; i >= 0; i--)
            {
                VRCExpressionsMenu.Control control = menu.controls[i];
                if (MenuControlUsesParameter(control, parameterName))
                {
                    menu.controls.RemoveAt(i);
                    removed = true;
                    continue;
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                    && RemoveMenuControlByParameter(control.subMenu, parameterName, visitedMenus))
                {
                    removed = true;
                    if (IsEmptyMenu(control.subMenu))
                    {
                        menu.controls.RemoveAt(i);
                    }
                }
            }

            if (removed)
            {
                EditorUtility.SetDirty(menu);
            }

            return removed;
        }

        private static bool IsEmptyMenu(VRCExpressionsMenu menu)
        {
            return menu == null || menu.controls == null || menu.controls.Count == 0;
        }

        private static VRCExpressionsMenu CreateMenuAsset(string path)
        {
            VRCExpressionsMenu menu = CreateInstance<VRCExpressionsMenu>();
            EnsureMenuControlList(menu);
            AssetDatabase.CreateAsset(menu, path);
            return menu;
        }

        private VRCExpressionsMenu FindOrCreateCategoryMenu(VRCExpressionsMenu rootMenu, string categoryName, string generationFolder)
        {
            EnsureMenuControlList(rootMenu);
            string menuName = TruncateMenuName(string.IsNullOrWhiteSpace(categoryName) ? "Other" : categoryName.Trim());
            foreach (VRCExpressionsMenu.Control control in rootMenu.controls)
            {
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu
                    && string.Equals(control.name, menuName, StringComparison.OrdinalIgnoreCase)
                    && control.subMenu != null)
                {
                    EnsureMenuControlList(control.subMenu);
                    return control.subMenu;
                }
            }

            if (rootMenu.controls.Count >= MaxControlsPerMenu)
            {
                return null;
            }

            string categoryPath = Path.Combine(
                generationFolder,
                $"{SanitizeAssetName(GetRunName())} {SanitizeAssetName(menuName)} Menu.asset").Replace("\\", "/");

            VRCExpressionsMenu categoryMenu = mergeWithExistingRun
                ? AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(categoryPath)
                : null;
            if (categoryMenu == null)
            {
                string assetPath = mergeWithExistingRun ? categoryPath : AssetDatabase.GenerateUniqueAssetPath(categoryPath);
                categoryMenu = CreateMenuAsset(assetPath);
            }
            else
            {
                EnsureMenuControlList(categoryMenu);
            }

            rootMenu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = menuName,
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = categoryMenu
            });
            EditorUtility.SetDirty(rootMenu);
            return categoryMenu;
        }

        private VRCExpressionsMenu LoadOrCreateRunMenu(string path)
        {
            if (mergeWithExistingRun)
            {
                VRCExpressionsMenu existingMenu = AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(path);
                if (existingMenu != null)
                {
                    EnsureMenuControlList(existingMenu);
                    return existingMenu;
                }
            }

            string assetPath = mergeWithExistingRun ? path : AssetDatabase.GenerateUniqueAssetPath(path);
            return CreateMenuAsset(assetPath);
        }

        private bool TryAddRadialControlToMenu(VRCExpressionsMenu rootMenu, VRCExpressionsMenu.Control radialControl, string generationFolder, string pagePrefix = null)
        {
            EnsureMenuControlList(rootMenu);

            if (!HasSubMenuControls(rootMenu) && rootMenu.controls.Count < MaxControlsPerMenu)
            {
                rootMenu.controls.Add(radialControl);
                EditorUtility.SetDirty(rootMenu);
                return true;
            }

            if (!EnsurePagedMenu(rootMenu, generationFolder, pagePrefix))
            {
                return false;
            }

            VRCExpressionsMenu pageMenu = FindPageWithRoom(rootMenu);
            if (pageMenu == null)
            {
                if (rootMenu.controls.Count >= MaxControlsPerMenu)
                {
                    return false;
                }

                pageMenu = CreatePageMenu(rootMenu, generationFolder, pagePrefix);
            }

            EnsureMenuControlList(pageMenu);
            pageMenu.controls.Add(radialControl);
            EditorUtility.SetDirty(pageMenu);
            EditorUtility.SetDirty(rootMenu);
            return true;
        }

        private bool EnsurePagedMenu(VRCExpressionsMenu rootMenu, string generationFolder, string pagePrefix)
        {
            List<VRCExpressionsMenu.Control> directControls = rootMenu.controls
                .Where(control => control.type != VRCExpressionsMenu.Control.ControlType.SubMenu)
                .ToList();

            if (directControls.Count == 0)
            {
                return true;
            }

            if (rootMenu.controls.Count - directControls.Count >= MaxControlsPerMenu)
            {
                return false;
            }

            rootMenu.controls.RemoveAll(control => control.type != VRCExpressionsMenu.Control.ControlType.SubMenu);
            foreach (List<VRCExpressionsMenu.Control> chunk in Chunk(directControls, ControlsPerPagedMenu))
            {
                VRCExpressionsMenu pageMenu = CreatePageMenu(rootMenu, generationFolder, pagePrefix);
                pageMenu.controls.AddRange(chunk);
                EditorUtility.SetDirty(pageMenu);
            }

            EditorUtility.SetDirty(rootMenu);
            return true;
        }

        private VRCExpressionsMenu CreatePageMenu(VRCExpressionsMenu rootMenu, string generationFolder, string pagePrefix = null)
        {
            int pageIndex = rootMenu.controls.Count(control => control.type == VRCExpressionsMenu.Control.ControlType.SubMenu) + 1;
            string pageName = $"Page {pageIndex}";
            string assetName = string.IsNullOrWhiteSpace(pagePrefix)
                ? $"{SanitizeAssetName(GetRunName())} {SanitizeAssetName(pageName)}.asset"
                : $"{SanitizeAssetName(GetRunName())} {SanitizeAssetName(pagePrefix)} {SanitizeAssetName(pageName)}.asset";
            string pagePath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(generationFolder, assetName).Replace("\\", "/"));
            VRCExpressionsMenu pageMenu = CreateMenuAsset(pagePath);
            rootMenu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = TruncateMenuName(pageName),
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = pageMenu
            });
            EditorUtility.SetDirty(rootMenu);
            return pageMenu;
        }

        private static bool HasSubMenuControls(VRCExpressionsMenu menu)
        {
            return menu.controls.Any(control => control.type == VRCExpressionsMenu.Control.ControlType.SubMenu);
        }

        private static VRCExpressionsMenu FindPageWithRoom(VRCExpressionsMenu rootMenu)
        {
            foreach (VRCExpressionsMenu.Control control in rootMenu.controls)
            {
                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu || control.subMenu == null)
                {
                    continue;
                }

                EnsureMenuControlList(control.subMenu);
                if (control.subMenu.controls.Count < MaxControlsPerMenu)
                {
                    return control.subMenu;
                }
            }

            return null;
        }

        private static HashSet<string> CollectMenuParameterNames(VRCExpressionsMenu menu)
        {
            HashSet<string> parameterNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            CollectMenuParameterNames(menu, parameterNames, new HashSet<VRCExpressionsMenu>());
            return parameterNames;
        }

        private static void CollectMenuParameterNames(VRCExpressionsMenu menu, HashSet<string> parameterNames, HashSet<VRCExpressionsMenu> visitedMenus)
        {
            if (menu == null || !visitedMenus.Add(menu))
            {
                return;
            }

            EnsureMenuControlList(menu);
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control.parameter != null && !string.IsNullOrWhiteSpace(control.parameter.name))
                {
                    parameterNames.Add(control.parameter.name);
                }

                if (control.subParameters != null)
                {
                    foreach (VRCExpressionsMenu.Control.Parameter parameter in control.subParameters)
                    {
                        if (parameter != null && !string.IsNullOrWhiteSpace(parameter.name))
                        {
                            parameterNames.Add(parameter.name);
                        }
                    }
                }

                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    CollectMenuParameterNames(control.subMenu, parameterNames, visitedMenus);
                }
            }
        }

        private static VRCExpressionsMenu.Control CreateRadialControl(GeneratedControl control, string parameterName)
        {
            return new VRCExpressionsMenu.Control
            {
                name = BuildControlMenuName(control),
                type = VRCExpressionsMenu.Control.ControlType.RadialPuppet,
                subParameters = new[]
                {
                    new VRCExpressionsMenu.Control.Parameter { name = parameterName }
                }
            };
        }

        private string BuildGenerationMessage(int generatedControlCount, string generationFolder)
        {
            string baseMessage;
            switch (generationMode)
            {
                case PoiyomiGenerationMode.AddToActionBuilderOnly:
                    baseMessage = $"Added {generatedControlCount} Poiyomi radial control(s) to Action Builder profile:\n{(actionProfile != null ? actionProfile.name : "(None)")}";
                    break;
                case PoiyomiGenerationMode.AddToActionBuilderAndGenerate:
                    baseMessage = $"Added {generatedControlCount} Poiyomi radial control(s) to Action Builder and generated them with Action Builder naming.";
                    break;
                default:
                    baseMessage = $"Generated {generatedControlCount} legacy Poiyomi radial controls in:\n{generationFolder}";
                    break;
            }

            string notesText = generationNotes.Count == 0
                ? string.Empty
                : $"\n\nNotes:\n{string.Join("\n", generationNotes)}";

            if (generationWarnings.Count == 0)
            {
                return $"{baseMessage}{notesText}";
            }

            foreach (string warning in generationWarnings)
            {
                Debug.LogWarning($"Poiyomi Lighting Menu Builder: {warning}");
            }

            int shownWarnings = Mathf.Min(5, generationWarnings.Count);
            string warningText = string.Join("\n", generationWarnings.Take(shownWarnings));
            if (generationWarnings.Count > shownWarnings)
            {
                warningText += $"\n...and {generationWarnings.Count - shownWarnings} more. See Console.";
            }

            return $"{baseMessage}{notesText}\n\nWarnings:\n{warningText}";
        }

        private void AppendSubMenu(VRCExpressionsMenu rootMenu, VRCExpressionsMenu generatedMenu)
        {
            EnsureMenuControlList(rootMenu);
            string submenuName = TruncateMenuName($"Poi {GetRunName()}");
            rootMenu.controls.RemoveAll(control => control.name == submenuName);

            if (rootMenu.controls.Count >= MaxControlsPerMenu)
            {
                generationWarnings.Add("Root expression menu is full, so the generated Poiyomi Lighting submenu was not appended.");
                EditorUtility.SetDirty(rootMenu);
                return;
            }

            rootMenu.controls.Add(new VRCExpressionsMenu.Control
            {
                name = submenuName,
                type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                subMenu = generatedMenu
            });
            EditorUtility.SetDirty(rootMenu);
        }

        private void EnsureAnimatorParameter(string parameterName)
        {
            if (fxController.parameters.Any(parameter => parameter.name == parameterName))
            {
                return;
            }

            fxController.AddParameter(parameterName, AnimatorControllerParameterType.Float);
        }

        private void RemoveLayerIfPresent(string layerName)
        {
            AnimatorControllerLayer[] layers = fxController.layers;
            for (int i = layers.Length - 1; i >= 0; i--)
            {
                if (layers[i].name == layerName)
                {
                    fxController.RemoveLayer(i);
                }
            }
        }

        private string BuildAnimatorLayerName(GeneratedControl control)
        {
            return $"Puddles {GetRunName()} {control.menuPrefix} {control.displayName}";
        }

        private void RemoveAnimatorParameter(string parameterName)
        {
            if (string.IsNullOrWhiteSpace(parameterName))
            {
                return;
            }

            AnimatorControllerParameter parameter = fxController.parameters
                .FirstOrDefault(existing => string.Equals(existing.name, parameterName, StringComparison.OrdinalIgnoreCase));
            if (parameter != null)
            {
                fxController.RemoveParameter(parameter);
            }
        }

        private static bool LayerWritesAnyBinding(AnimatorControllerLayer layer, HashSet<string> targetBindingKeys)
        {
            foreach (AnimationClip clip in EnumerateLayerClips(layer))
            {
                foreach (EditorCurveBinding binding in AnimationUtility.GetCurveBindings(clip))
                {
                    if (targetBindingKeys.Contains(GetBindingKey(binding)))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static string FindFirstBlendParameter(AnimatorControllerLayer layer)
        {
            foreach (BlendTree blendTree in EnumerateLayerBlendTrees(layer))
            {
                if (!string.IsNullOrWhiteSpace(blendTree.blendParameter))
                {
                    return blendTree.blendParameter;
                }
            }

            return string.Empty;
        }

        private static IEnumerable<AnimationClip> EnumerateLayerClips(AnimatorControllerLayer layer)
        {
            foreach (Motion motion in EnumerateLayerMotions(layer))
            {
                foreach (AnimationClip clip in EnumerateMotionClips(motion))
                {
                    yield return clip;
                }
            }
        }

        private static IEnumerable<BlendTree> EnumerateLayerBlendTrees(AnimatorControllerLayer layer)
        {
            foreach (Motion motion in EnumerateLayerMotions(layer))
            {
                foreach (BlendTree blendTree in EnumerateMotionBlendTrees(motion))
                {
                    yield return blendTree;
                }
            }
        }

        private static IEnumerable<Motion> EnumerateLayerMotions(AnimatorControllerLayer layer)
        {
            if (layer == null || layer.stateMachine == null)
            {
                yield break;
            }

            foreach (Motion motion in EnumerateStateMachineMotions(layer.stateMachine, new HashSet<AnimatorStateMachine>()))
            {
                yield return motion;
            }
        }

        private static IEnumerable<Motion> EnumerateStateMachineMotions(AnimatorStateMachine stateMachine, HashSet<AnimatorStateMachine> visitedStateMachines)
        {
            if (stateMachine == null || !visitedStateMachines.Add(stateMachine))
            {
                yield break;
            }

            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                if (childState.state != null && childState.state.motion != null)
                {
                    yield return childState.state.motion;
                }
            }

            foreach (ChildAnimatorStateMachine childStateMachine in stateMachine.stateMachines)
            {
                if (childStateMachine.stateMachine == null)
                {
                    continue;
                }

                foreach (Motion motion in EnumerateStateMachineMotions(childStateMachine.stateMachine, visitedStateMachines))
                {
                    yield return motion;
                }
            }
        }

        private static IEnumerable<AnimationClip> EnumerateMotionClips(Motion motion)
        {
            if (motion is AnimationClip clip)
            {
                yield return clip;
                yield break;
            }

            if (motion is BlendTree blendTree)
            {
                foreach (ChildMotion childMotion in blendTree.children)
                {
                    foreach (AnimationClip childClip in EnumerateMotionClips(childMotion.motion))
                    {
                        yield return childClip;
                    }
                }
            }
        }

        private static IEnumerable<BlendTree> EnumerateMotionBlendTrees(Motion motion)
        {
            if (!(motion is BlendTree blendTree))
            {
                yield break;
            }

            yield return blendTree;
            foreach (ChildMotion childMotion in blendTree.children)
            {
                foreach (BlendTree childBlendTree in EnumerateMotionBlendTrees(childMotion.motion))
                {
                    yield return childBlendTree;
                }
            }
        }

        private static List<int> FindMaterialSlots(Renderer renderer, PropertyControl control)
        {
            return FindMaterialSlots(renderer, control.material, control.propertyName);
        }

        private static List<int> FindMaterialSlots(Renderer renderer, Material targetMaterial, string propertyName)
        {
            List<int> slots = new List<int>();
            Material[] materials = renderer.sharedMaterials;
            for (int i = 0; i < materials.Length; i++)
            {
                Material material = materials[i];
                if (material == targetMaterial
                    && material != null
                    && material.shader != null
                    && LooksLikePoiyomi(material.shader)
                    && material.HasProperty(propertyName))
                {
                    slots.Add(i);
                }
            }

            return slots;
        }

        private static bool TryGetPoiyomiMajorCategory(string propertyName, string description, out string categoryName)
        {
            categoryName = string.Empty;
            if (string.IsNullOrWhiteSpace(propertyName))
            {
                return false;
            }

            string normalized = propertyName.ToLowerInvariant();
            if (!normalized.StartsWith("m_", StringComparison.Ordinal)
                || !normalized.EndsWith("category", StringComparison.Ordinal)
                || normalized.Contains("_start_")
                || normalized.Contains("_end_"))
            {
                return false;
            }

            categoryName = NormalizeMenuCategory(NicifyControlName(description, propertyName));
            return true;
        }

        private static bool TryGetPoiyomiSectionStart(string propertyName, string description, out string sectionName)
        {
            sectionName = string.Empty;
            if (string.IsNullOrWhiteSpace(propertyName)
                || !propertyName.StartsWith("m_start_", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            sectionName = NormalizeMenuCategory(NicifyControlName(description, propertyName));
            return !string.IsNullOrWhiteSpace(sectionName);
        }

        private static bool IsPoiyomiSectionEnd(string propertyName)
        {
            return !string.IsNullOrWhiteSpace(propertyName)
                && propertyName.StartsWith("m_end_", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsPoiyomiUiMarkerProperty(string propertyName)
        {
            return !string.IsNullOrWhiteSpace(propertyName)
                && (propertyName.StartsWith("m_", StringComparison.OrdinalIgnoreCase)
                    || propertyName.StartsWith("s_start_", StringComparison.OrdinalIgnoreCase)
                    || propertyName.StartsWith("s_end_", StringComparison.OrdinalIgnoreCase));
        }

        private static string ResolveMenuCategory(string propertyName, string description, string currentCategory, IReadOnlyList<string> sectionStack)
        {
            string sectionText = string.Join(" ", sectionStack);
            if (TryResolveSpecificCategory(sectionText, out string sectionSpecificCategory))
            {
                return sectionSpecificCategory;
            }

            for (int i = 0; i < sectionStack.Count; i++)
            {
                string sectionCategory = NormalizeMenuCategory(sectionStack[i]);
                if (!string.IsNullOrWhiteSpace(sectionCategory))
                {
                    return sectionCategory;
                }
            }

            string normalizedPropertyName = propertyName.ToLowerInvariant();
            if (normalizedPropertyName.StartsWith("_emission", StringComparison.Ordinal)
                || normalizedPropertyName.StartsWith("_gitde", StringComparison.Ordinal)
                || normalizedPropertyName.StartsWith("_scrollingemission", StringComparison.Ordinal)
                || normalizedPropertyName.StartsWith("_audiolinkemission", StringComparison.Ordinal))
            {
                return "Emission";
            }

            if (propertyName.StartsWith("_Lighting", StringComparison.OrdinalIgnoreCase))
            {
                return "Lighting";
            }

            if (TryResolveSpecificCategory($"{propertyName} {description} {currentCategory}", out string specificCategory))
            {
                return specificCategory;
            }

            return NormalizeMenuCategory(currentCategory);
        }

        private static bool TryResolveSpecificCategory(string value, out string categoryName)
        {
            string haystack = (value ?? string.Empty).ToLowerInvariant();
            if (haystack.Contains("emission"))
            {
                categoryName = "Emission";
                return true;
            }

            if (haystack.Contains("matcap"))
            {
                categoryName = "Matcap";
                return true;
            }

            if (haystack.Contains("lighting") || haystack.Contains("light data") || haystack.Contains("shading"))
            {
                categoryName = "Lighting";
                return true;
            }

            if (haystack.Contains("outline"))
            {
                categoryName = "Outlines";
                return true;
            }

            if (haystack.Contains("audio link") || haystack.Contains("audiolink"))
            {
                categoryName = "Audio Link";
                return true;
            }

            categoryName = string.Empty;
            return false;
        }

        private static string ResolveGroupedCategory(List<PropertyControl> targets)
        {
            List<string> categories = targets
                .Select(target => NormalizeMenuCategory(target.categoryName))
                .Where(category => !string.IsNullOrWhiteSpace(category))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            return categories.Count == 1 ? categories[0] : "Grouped";
        }

        private static string NormalizeMenuCategory(string categoryName)
        {
            if (string.IsNullOrWhiteSpace(categoryName))
            {
                return "Other";
            }

            string cleaned = StripRichText(categoryName);
            int conditionIndex = cleaned.IndexOf("--{", StringComparison.Ordinal);
            if (conditionIndex >= 0)
            {
                cleaned = cleaned.Substring(0, conditionIndex);
            }

            cleaned = Regex.Replace(cleaned, @"\s+", " ").Trim();
            cleaned = Regex.Replace(cleaned, @"\s+\d+$", string.Empty).Trim();
            if (cleaned.Equals("Shading", StringComparison.OrdinalIgnoreCase))
            {
                return "Lighting";
            }

            if (cleaned.Equals("Color & Normals", StringComparison.OrdinalIgnoreCase))
            {
                return "Color";
            }

            if (cleaned.Equals("Global Data and Masks", StringComparison.OrdinalIgnoreCase))
            {
                return "Global";
            }

            if (cleaned.Equals("Global Modifiers & Data", StringComparison.OrdinalIgnoreCase))
            {
                return "Modifiers";
            }

            if (cleaned.StartsWith("Emission", StringComparison.OrdinalIgnoreCase))
            {
                return "Emission";
            }

            return string.IsNullOrWhiteSpace(cleaned) ? "Other" : cleaned;
        }

        private static string StripRichText(string value)
        {
            string cleaned = Regex.Replace(value ?? string.Empty, "<.*?>", string.Empty);
            return Regex.Replace(cleaned, @"[^\u0000-\u007F]+", string.Empty);
        }

        private static string GetAnimatedMaterialPropertyName(string propertyName, int materialSlot)
        {
            return materialSlot == 0
                ? $"material.{propertyName}"
                : $"material.[{materialSlot}].{propertyName}";
        }

        private static IEnumerable<EditorCurveBinding> CreateFallbackMaterialBindings(
            Renderer renderer,
            string relativePath,
            string propertyName,
            int materialSlot)
        {
            Type rendererType = renderer.GetType();
            yield return EditorCurveBinding.FloatCurve(relativePath, rendererType, GetAnimatedMaterialPropertyName(propertyName, materialSlot));
        }

        private static IEnumerable<EditorCurveBinding> FindUnityMaterialBindings(
            Renderer renderer,
            GameObject animationRoot,
            PropertyControl control,
            string relativePath,
            List<int> materialSlots)
        {
            EditorCurveBinding[] bindings = AnimationUtility.GetAnimatableBindings(renderer.gameObject, animationRoot);
            HashSet<string> candidateNames = new HashSet<string>(StringComparer.Ordinal);
            foreach (int materialSlot in materialSlots)
            {
                candidateNames.Add(GetAnimatedMaterialPropertyName(control.propertyName, materialSlot));
            }

            HashSet<string> yieldedNames = new HashSet<string>(StringComparer.Ordinal);
            foreach (EditorCurveBinding binding in bindings)
            {
                if (binding.path != relativePath)
                {
                    continue;
                }

                if (!IsRendererBinding(binding.type))
                {
                    continue;
                }

                if (candidateNames.Contains(binding.propertyName)
                    || IsMaterialPropertyBinding(binding.propertyName, control.propertyName))
                {
                    string key = $"{binding.path}:{binding.type.FullName}:{binding.propertyName}";
                    if (yieldedNames.Add(key))
                    {
                        yield return binding;
                    }
                }
            }
        }

        private static bool IsRendererBinding(Type type)
        {
            return type == typeof(Renderer)
                || type == typeof(MeshRenderer)
                || type == typeof(SkinnedMeshRenderer)
                || typeof(Renderer).IsAssignableFrom(type);
        }

        private static bool IsMaterialPropertyBinding(string bindingPropertyName, string shaderPropertyName)
        {
            return bindingPropertyName == $"material.{shaderPropertyName}"
                || bindingPropertyName.EndsWith($".{shaderPropertyName}", StringComparison.Ordinal)
                || bindingPropertyName.Contains($".{shaderPropertyName}.")
                || bindingPropertyName.EndsWith($".{shaderPropertyName}.x", StringComparison.Ordinal)
                || bindingPropertyName.EndsWith($".{shaderPropertyName}.y", StringComparison.Ordinal)
                || bindingPropertyName.EndsWith($".{shaderPropertyName}.z", StringComparison.Ordinal)
                || bindingPropertyName.EndsWith($".{shaderPropertyName}.w", StringComparison.Ordinal);
        }

        private static string GetBindingKey(EditorCurveBinding binding)
        {
            return $"{binding.path}:{binding.type.FullName}:{binding.propertyName}";
        }

        private static bool LooksLikePoiyomi(Shader shader)
        {
            return shader.name.IndexOf("poiyomi", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool LooksLightingRelated(string propertyName, string description)
        {
            string haystack = $"{propertyName} {description}".ToLowerInvariant();
            return LightingNameHints.Any(haystack.Contains);
        }

        private static bool IsPoiyomiAnimatedField(Material material, string propertyName)
        {
            string animatedTagName = $"{propertyName}Animated";
            string animatedTagValue = material.GetTag(animatedTagName, false, string.Empty);
            if (!string.IsNullOrWhiteSpace(animatedTagValue))
            {
                return animatedTagValue == "1"
                    || animatedTagValue.Equals("true", StringComparison.OrdinalIgnoreCase);
            }

            if (material.HasProperty(animatedTagName))
            {
                return Mathf.Abs(TryGetMaterialFloat(material, animatedTagName, 0f)) > 0.0001f;
            }

            return false;
        }

        private static bool IsShaderFieldActive(Material material, string propertyName, string description)
        {
            string conditionText = ExtractConditionText(description);
            if (string.IsNullOrWhiteSpace(conditionText))
            {
                return true;
            }

            List<string> dependencyNames = Regex.Matches(conditionText, @"_[A-Za-z0-9_]+")
                .Cast<Match>()
                .Select(match => match.Value)
                .Where(name => name != propertyName && material.HasProperty(name))
                .Distinct()
                .ToList();

            if (dependencyNames.Count == 0)
            {
                return true;
            }

            foreach (string dependencyName in dependencyNames)
            {
                float dependencyValue = TryGetMaterialFloat(material, dependencyName, 0f);
                bool dependencyEnabled = Mathf.Abs(dependencyValue) > 0.0001f;
                bool negated = IsNegatedCondition(conditionText, dependencyName);

                if (!negated && !dependencyEnabled)
                {
                    return false;
                }

                if (negated && dependencyEnabled)
                {
                    return false;
                }
            }

            return true;
        }

        private static float TryGetMaterialFloat(Material material, string propertyName, float fallback)
        {
            try
            {
                return material.GetFloat(propertyName);
            }
            catch
            {
                return fallback;
            }
        }

        private static string ExtractConditionText(string description)
        {
            if (string.IsNullOrWhiteSpace(description))
            {
                return string.Empty;
            }

            int conditionIndex = description.IndexOf("--{", StringComparison.Ordinal);
            if (conditionIndex < 0)
            {
                return string.Empty;
            }

            return description.Substring(conditionIndex + 2);
        }

        private static bool IsNegatedCondition(string conditionText, string dependencyName)
        {
            int index = conditionText.IndexOf(dependencyName, StringComparison.Ordinal);
            if (index <= 0)
            {
                return false;
            }

            int start = Mathf.Max(0, index - 12);
            string prefix = conditionText.Substring(start, index - start).ToLowerInvariant();
            return prefix.Contains("!")
                || prefix.Contains("not")
                || prefix.Contains("false")
                || prefix.Contains("==0")
                || prefix.Contains("=0");
        }

        private static bool ContainsIgnoreCase(string value, string search)
        {
            return !string.IsNullOrEmpty(value)
                && value.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void RefreshDefaultValueFromMaterial(PropertyControl control)
        {
            if (control.material != null && control.material.HasProperty(control.propertyName))
            {
                control.originalValue = control.material.GetFloat(control.propertyName);
            }

            control.defaultValue = Normalize01(control.originalValue, control.minValue, control.maxValue);
        }

        private static string NicifyControlName(string description, string propertyName)
        {
            string source = string.IsNullOrWhiteSpace(description) ? propertyName : description;
            int conditionIndex = source.IndexOf("--{", StringComparison.Ordinal);
            if (conditionIndex >= 0)
            {
                source = source.Substring(0, conditionIndex);
            }

            source = source.Replace("_", " ").Replace("  ", " ").Trim();
            if (source.StartsWith("Lighting ", StringComparison.OrdinalIgnoreCase))
            {
                source = source.Substring("Lighting ".Length);
            }

            return ObjectNames.NicifyVariableName(source).Trim();
        }

        private static string NicifyPropertyName(string propertyName)
        {
            if (string.IsNullOrWhiteSpace(propertyName))
            {
                return string.Empty;
            }

            string source = propertyName.Trim().TrimStart('_');
            source = Regex.Replace(source, "_+", " ");
            source = Regex.Replace(source, "([a-z])([A-Z])", "$1 $2");
            source = Regex.Replace(source, "([A-Za-z])([0-9]+)", "$1 $2");
            source = Regex.Replace(source, "([0-9])([A-Za-z])", "$1 $2");
            return ObjectNames.NicifyVariableName(source).Trim();
        }

        private static string SanitizeParameterName(string value)
        {
            char[] invalid = { ' ', '.', ',', ':', ';', '\\', '[', ']', '(', ')' };
            string cleaned = invalid.Aggregate(value.Trim(), (current, c) => current.Replace(c, '_'));
            return string.Join("_", cleaned.Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries));
        }

        private static string SanitizeAssetName(string value)
        {
            string cleaned = string.Join("_", value.Split(Path.GetInvalidFileNameChars()));
            return string.IsNullOrWhiteSpace(cleaned) ? "LightingControl" : cleaned;
        }

        private static string TruncateMenuName(string value)
        {
            return value.Length <= 32 ? value : value.Substring(0, 32);
        }

        private static string BuildControlMenuName(GeneratedControl control)
        {
            string prefix = control.targets.Count > 1 ? "All" : control.menuPrefix;
            string displayName = BuildMenuSettingName(control);
            string fullName = $"{prefix}: {displayName}";
            if (fullName.Length <= 32)
            {
                return fullName;
            }

            string settingFirst = $"{displayName}: {prefix}";
            if (settingFirst.Length <= 32)
            {
                return settingFirst;
            }

            string shortPrefix = prefix.Length <= 10 ? prefix : prefix.Substring(0, 10);
            string compactName = $"{displayName}: {shortPrefix}";
            return TruncateMenuName(compactName);
        }

        private static string BuildMenuSettingName(GeneratedControl control)
        {
            if (control.targets.Count != 1)
            {
                return control.displayName;
            }

            string propertyLabel = NicifyPropertyName(control.targets[0].propertyName);
            if (ShouldUsePropertyLabel(control.displayName, propertyLabel))
            {
                return propertyLabel;
            }

            return control.displayName;
        }

        private static bool ShouldUsePropertyLabel(string displayName, string propertyLabel)
        {
            if (string.IsNullOrWhiteSpace(propertyLabel))
            {
                return false;
            }

            string normalizedDisplay = NormalizeLabel(displayName);
            string normalizedProperty = NormalizeLabel(propertyLabel);
            return normalizedProperty.Length > normalizedDisplay.Length
                && normalizedProperty.Contains(normalizedDisplay);
        }

        private static string NormalizeLabel(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            return Regex.Replace(value.ToLowerInvariant(), @"[^a-z0-9]+", string.Empty);
        }

        private string GetRunName()
        {
            return string.IsNullOrWhiteSpace(runName) ? "Lighting" : runName.Trim();
        }

        private string GetGenerationFolder()
        {
            return Path.Combine(outputFolder, SanitizeAssetName(GetRunName())).Replace("\\", "/");
        }

        private static string BuildPageName(List<GeneratedControl> pageControls, int pageIndex)
        {
            List<string> prefixes = pageControls
                .Select(control => control.menuPrefix)
                .Distinct()
                .Where(prefix => !string.IsNullOrWhiteSpace(prefix))
                .ToList();

            if (prefixes.Count == 1)
            {
                return prefixes[0];
            }

            return $"Page {pageIndex}";
        }

        private void WarnIfGroupedRangesDiffer(string displayName, List<PropertyControl> targets)
        {
            if (targets.Count <= 1)
            {
                return;
            }

            PropertyControl first = targets[0];
            bool differs = targets.Any(target =>
                !Mathf.Approximately(target.minValue, first.minValue)
                || !Mathf.Approximately(target.maxValue, first.maxValue)
                || !Mathf.Approximately(target.defaultValue, first.defaultValue));

            if (differs)
            {
                generationWarnings.Add($"Grouped setting '{displayName}' has mixed ranges/defaults. The grouped dial uses one shared parameter, so verify the generated behavior.");
            }
        }

        private static float Normalize01(float value, float minValue, float maxValue)
        {
            if (Mathf.Approximately(minValue, maxValue))
            {
                return 0f;
            }

            return Mathf.Clamp01((value - minValue) / (maxValue - minValue));
        }

        private static void EnsureMenuControlList(VRCExpressionsMenu menu)
        {
            if (menu.controls == null)
            {
                menu.controls = new List<VRCExpressionsMenu.Control>();
            }
        }

        private static float TryGetRangeLimit(Shader shader, int propertyIndex, int limitIndex, float fallback)
        {
            try
            {
                return ShaderUtil.GetRangeLimits(shader, propertyIndex, limitIndex);
            }
            catch
            {
                return fallback;
            }
        }

        private static void EnsureFolder(string folder)
        {
            string normalized = folder.Replace("\\", "/").Trim('/');
            if (AssetDatabase.IsValidFolder(normalized))
            {
                return;
            }

            string[] parts = normalized.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = $"{current}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                current = next;
            }
        }

        private static bool IsProjectAssetFolder(string folder)
        {
            string normalized = folder.Replace("\\", "/").Trim('/');
            return normalized == "Assets" || normalized.StartsWith("Assets/", StringComparison.Ordinal);
        }

        private static IEnumerable<List<T>> Chunk<T>(IReadOnlyList<T> items, int size)
        {
            for (int i = 0; i < items.Count; i += size)
            {
                List<T> chunk = new List<T>();
                for (int j = i; j < Math.Min(i + size, items.Count); j++)
                {
                    chunk.Add(items[j]);
                }

                yield return chunk;
            }
        }

        private enum PoiyomiGenerationMode
        {
            AddToActionBuilderAndGenerate,
            AddToActionBuilderOnly,
            LegacyPoiyomiAssetsOnly
        }

        [Serializable]
        private sealed class PropertyControl
        {
            public bool include;
            public Material material;
            public string materialName;
            public string shaderName;
            public string propertyName;
            public string displayName;
            public string categoryName;
            public float originalValue;
            public float minValue;
            public float maxValue;
            public float defaultValue;
            public bool defaultFromOriginal;
        }

        private sealed class GeneratedControl
        {
            public readonly string displayName;
            public readonly string menuPrefix;
            public readonly string categoryName;
            public readonly List<PropertyControl> targets;
            public readonly float defaultValue;

            public GeneratedControl(string displayName, string menuPrefix, string categoryName, List<PropertyControl> targets)
            {
                this.displayName = displayName;
                this.menuPrefix = menuPrefix;
                this.categoryName = categoryName;
                this.targets = targets;
                defaultValue = targets.Count == 0 ? 0f : Mathf.Clamp01(targets.Average(target => target.defaultValue));
            }
        }
    }
}
#endif
