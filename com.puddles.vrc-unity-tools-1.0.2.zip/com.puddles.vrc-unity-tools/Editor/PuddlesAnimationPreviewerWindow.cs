#if UNITY_EDITOR && PUDDLES_EXPERIMENTAL_TOOLS
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace PuddlesVrcTools.Editor
{
    public sealed class PuddlesAnimationPreviewerWindow : EditorWindow
    {
        private GameObject avatarRoot;
        private AnimationClip animationClip;
        private Vector2 bindingScroll;
        private Vector2 detailScroll;
        private readonly List<BindingRow> bindingRows = new List<BindingRow>();
        private string bindingSearch = string.Empty;
        private int selectedBindingIndex = -1;
        private float previewTime;
        private bool isPreviewing;
        private bool isPlaying;
        private double lastUpdateTime;
        private float testValueA;
        private float testValueB = 1f;
        private string statusMessage = string.Empty;

        [MenuItem("Tools/Puddles/Animation Previewer")]
        public static void Open()
        {
            GetWindow<PuddlesAnimationPreviewerWindow>("Animation Previewer");
        }

        private void OnEnable()
        {
            EditorApplication.update += OnEditorUpdate;
            AssemblyReloadEvents.beforeAssemblyReload += StopPreview;
            RefreshBindings();
        }

        private void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
            AssemblyReloadEvents.beforeAssemblyReload -= StopPreview;
            StopPreview();
        }

        private void OnGUI()
        {
            DrawHeader();
            EditorGUILayout.Space(4f);
            DrawPreviewControls();
            EditorGUILayout.Space(4f);
            DrawBindingList();
            EditorGUILayout.Space(4f);
            DrawSelectedBindingDetails();
        }

        private void DrawHeader()
        {
            EditorGUILayout.LabelField("Puddles Animation Previewer", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "Samples an animation clip onto the real scene avatar using Unity preview mode, then shows which bindings resolve.",
                EditorStyles.wordWrappedMiniLabel);

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.BeginChangeCheck();
                GameObject newAvatarRoot = (GameObject)EditorGUILayout.ObjectField("Avatar Root", avatarRoot, typeof(GameObject), true);
                AnimationClip newClip = (AnimationClip)EditorGUILayout.ObjectField("Animation Clip", animationClip, typeof(AnimationClip), false);
                if (EditorGUI.EndChangeCheck())
                {
                    StopPreview();
                    avatarRoot = newAvatarRoot;
                    animationClip = newClip;
                    previewTime = 0f;
                    RefreshBindings();
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Use Selected Avatar"))
                    {
                        StopPreview();
                        avatarRoot = FindSelectedAvatarRoot();
                        RefreshBindings();
                    }

                    if (GUILayout.Button("Refresh Bindings"))
                    {
                        RefreshBindings();
                    }
                }
            }

            if (isPreviewing)
            {
                EditorGUILayout.HelpBox("Preview Active: sampled values are temporary until Revert Preview or this window closes.", MessageType.Info);
            }
            else if (AnimationMode.InAnimationMode())
            {
                EditorGUILayout.HelpBox("Unity is already in animation preview mode. Stop the other preview before starting this one.", MessageType.Warning);
            }

            if (!string.IsNullOrWhiteSpace(statusMessage))
            {
                EditorGUILayout.HelpBox(statusMessage, MessageType.None);
            }
        }

        private void DrawPreviewControls()
        {
            bool canPreview = avatarRoot != null && animationClip != null;
            float clipLength = animationClip != null ? Mathf.Max(animationClip.length, 0f) : 0f;

            using (new EditorGUI.DisabledScope(!canPreview))
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.BeginChangeCheck();
                previewTime = EditorGUILayout.Slider("Time", previewTime, 0f, Mathf.Max(clipLength, 0.0001f));
                if (EditorGUI.EndChangeCheck() && isPreviewing)
                {
                    isPlaying = false;
                    SampleCurrentClip();
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(isPreviewing ? "Sample" : "Preview"))
                    {
                        if (EnsurePreviewMode())
                        {
                            isPlaying = false;
                            SampleCurrentClip();
                        }
                    }

                    if (GUILayout.Button("Play"))
                    {
                        if (EnsurePreviewMode())
                        {
                            isPlaying = true;
                            lastUpdateTime = EditorApplication.timeSinceStartup;
                            SampleCurrentClip();
                        }
                    }

                    using (new EditorGUI.DisabledScope(!isPreviewing))
                    {
                        if (GUILayout.Button("Stop"))
                        {
                            isPlaying = false;
                        }

                        if (GUILayout.Button("Revert Preview"))
                        {
                            StopPreview();
                        }
                    }
                }
            }
        }

        private void DrawBindingList()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Clip Bindings", EditorStyles.boldLabel);
                bindingSearch = EditorGUILayout.TextField("Search", bindingSearch);

                using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
                {
                    GUILayout.Label("Status", GUILayout.Width(145f));
                    GUILayout.Label("Path", GUILayout.Width(180f));
                    GUILayout.Label("Component", GUILayout.Width(135f));
                    GUILayout.Label("Property", GUILayout.MinWidth(220f));
                    GUILayout.Label("Value", GUILayout.Width(90f));
                }

                bindingScroll = EditorGUILayout.BeginScrollView(bindingScroll, GUILayout.MinHeight(180f));
                List<int> visibleIndices = GetVisibleBindingIndices();
                if (visibleIndices.Count == 0)
                {
                    EditorGUILayout.LabelField("No bindings found for this clip/search.", EditorStyles.wordWrappedMiniLabel);
                }

                foreach (int rowIndex in visibleIndices)
                {
                    BindingRow row = bindingRows[rowIndex];
                    row.CurrentValue = GetValueAtTime(row, previewTime);
                    GUIStyle rowStyle = rowIndex == selectedBindingIndex ? EditorStyles.helpBox : EditorStyles.miniButton;

                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button(row.Resolution, rowStyle, GUILayout.Width(145f)))
                        {
                            selectedBindingIndex = rowIndex;
                        }

                        if (GUILayout.Button(Shorten(row.Path, 34), rowStyle, GUILayout.Width(180f)))
                        {
                            selectedBindingIndex = rowIndex;
                        }

                        if (GUILayout.Button(Shorten(row.TypeName, 26), rowStyle, GUILayout.Width(135f)))
                        {
                            selectedBindingIndex = rowIndex;
                        }

                        if (GUILayout.Button(Shorten(row.PropertyName, 52), rowStyle, GUILayout.MinWidth(220f)))
                        {
                            selectedBindingIndex = rowIndex;
                        }

                        if (GUILayout.Button(Shorten(row.CurrentValue, 20), rowStyle, GUILayout.Width(90f)))
                        {
                            selectedBindingIndex = rowIndex;
                        }
                    }
                }

                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawSelectedBindingDetails()
        {
            BindingRow row = GetSelectedBinding();
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Selected Binding", EditorStyles.boldLabel);
                if (row == null)
                {
                    EditorGUILayout.LabelField("Select a binding row to inspect or test it.", EditorStyles.wordWrappedMiniLabel);
                    return;
                }

                detailScroll = EditorGUILayout.BeginScrollView(detailScroll, GUILayout.MinHeight(180f));
                EditorGUILayout.LabelField("Resolution", row.Resolution);
                EditorGUILayout.LabelField("Path", string.IsNullOrEmpty(row.Path) ? "(Avatar Root)" : row.Path);
                EditorGUILayout.LabelField("Component", row.TypeName);
                EditorGUILayout.LabelField("Property", row.PropertyName);
                EditorGUILayout.LabelField("Kind", row.IsObjectReference ? "Object Reference" : "Float Curve");
                EditorGUILayout.LabelField("Value At Time", GetValueAtTime(row, previewTime));

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Copy Property Path"))
                    {
                        EditorGUIUtility.systemCopyBuffer = row.PropertyName;
                        statusMessage = "Copied property path.";
                    }

                    if (GUILayout.Button("Copy Binding Summary"))
                    {
                        EditorGUIUtility.systemCopyBuffer = BuildBindingSummary(row);
                        statusMessage = "Copied binding summary.";
                    }
                }

                if (!row.IsObjectReference)
                {
                    DrawFloatBindingTester(row);
                }

                if (row.SimilarBindings.Count > 0)
                {
                    EditorGUILayout.Space(4f);
                    EditorGUILayout.LabelField("Nearby Material Bindings", EditorStyles.boldLabel);
                    foreach (EditorCurveBinding similar in row.SimilarBindings)
                    {
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            EditorGUILayout.SelectableLabel(FormatBinding(similar), EditorStyles.textField, GUILayout.Height(EditorGUIUtility.singleLineHeight));
                            if (GUILayout.Button("Copy", GUILayout.Width(52f)))
                            {
                                EditorGUIUtility.systemCopyBuffer = similar.propertyName;
                                statusMessage = "Copied nearby binding property.";
                            }

                            using (new EditorGUI.DisabledScope(row.IsObjectReference))
                            {
                                if (GUILayout.Button("A", GUILayout.Width(28f)))
                                {
                                    SampleTemporaryFloatBinding(similar, testValueA);
                                }

                                if (GUILayout.Button("B", GUILayout.Width(28f)))
                                {
                                    SampleTemporaryFloatBinding(similar, testValueB);
                                }
                            }
                        }
                    }
                }

                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawFloatBindingTester(BindingRow row)
        {
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("Float Binding Tester", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "Samples a temporary in-memory clip onto this avatar. Revert Preview restores the scene.",
                EditorStyles.wordWrappedMiniLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                testValueA = EditorGUILayout.FloatField("A", testValueA);
                testValueB = EditorGUILayout.FloatField("B", testValueB);
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(avatarRoot == null))
                {
                    if (GUILayout.Button("Sample Exact A"))
                    {
                        SampleTemporaryFloatBinding(row.Binding, testValueA);
                    }

                    if (GUILayout.Button("Sample Exact B"))
                    {
                        SampleTemporaryFloatBinding(row.Binding, testValueB);
                    }
                }
            }
        }

        private void OnEditorUpdate()
        {
            if (!isPreviewing || !isPlaying || avatarRoot == null || animationClip == null)
            {
                return;
            }

            double now = EditorApplication.timeSinceStartup;
            float delta = Mathf.Max(0f, (float)(now - lastUpdateTime));
            lastUpdateTime = now;

            float length = Mathf.Max(animationClip.length, 0f);
            previewTime = length > 0f ? Mathf.Repeat(previewTime + delta, length) : 0f;
            SampleCurrentClip();
            Repaint();
        }

        private bool EnsurePreviewMode()
        {
            if (avatarRoot == null || animationClip == null)
            {
                statusMessage = "Assign an avatar root and animation clip first.";
                return false;
            }

            if (!isPreviewing && AnimationMode.InAnimationMode())
            {
                statusMessage = "Unity is already in animation preview mode. Stop the other preview first.";
                return false;
            }

            if (!isPreviewing)
            {
                AnimationMode.StartAnimationMode();
                isPreviewing = true;
            }

            statusMessage = string.Empty;
            return true;
        }

        private void SampleCurrentClip()
        {
            if (!isPreviewing || avatarRoot == null || animationClip == null)
            {
                return;
            }

            previewTime = Mathf.Clamp(previewTime, 0f, Mathf.Max(animationClip.length, 0f));
            AnimationMode.SampleAnimationClip(avatarRoot, animationClip, previewTime);
            SceneView.RepaintAll();
        }

        private void SampleTemporaryFloatBinding(EditorCurveBinding binding, float value)
        {
            if (avatarRoot == null)
            {
                statusMessage = "Assign an avatar root first.";
                return;
            }

            if (!isPreviewing && AnimationMode.InAnimationMode())
            {
                statusMessage = "Unity is already in animation preview mode. Stop the other preview first.";
                return;
            }

            if (!isPreviewing)
            {
                AnimationMode.StartAnimationMode();
                isPreviewing = true;
            }

            isPlaying = false;

            AnimationClip tempClip = new AnimationClip { frameRate = 60f };
            AnimationCurve curve = AnimationCurve.Constant(0f, 1f / 60f, value);
            AnimationUtility.SetEditorCurve(tempClip, binding, curve);
            AnimationMode.SampleAnimationClip(avatarRoot, tempClip, 0f);
            statusMessage = $"Sampled {value:0.###} on {binding.propertyName}.";
            SceneView.RepaintAll();
            Repaint();
        }

        private void StopPreview()
        {
            isPlaying = false;
            if (isPreviewing && AnimationMode.InAnimationMode())
            {
                AnimationMode.StopAnimationMode();
            }

            isPreviewing = false;
            SceneView.RepaintAll();
        }

        private void RefreshBindings()
        {
            bindingRows.Clear();
            selectedBindingIndex = -1;

            if (animationClip == null)
            {
                return;
            }

            foreach (EditorCurveBinding binding in AnimationUtility.GetCurveBindings(animationClip))
            {
                bindingRows.Add(BuildBindingRow(binding, false));
            }

            foreach (EditorCurveBinding binding in AnimationUtility.GetObjectReferenceCurveBindings(animationClip))
            {
                bindingRows.Add(BuildBindingRow(binding, true));
            }

            bindingRows.Sort((left, right) => string.Compare(left.SortKey, right.SortKey, StringComparison.OrdinalIgnoreCase));
            if (bindingRows.Count > 0)
            {
                selectedBindingIndex = 0;
            }
        }

        private BindingRow BuildBindingRow(EditorCurveBinding binding, bool isObjectReference)
        {
            BindingRow row = new BindingRow
            {
                Binding = binding,
                IsObjectReference = isObjectReference,
                Path = binding.path ?? string.Empty,
                TypeName = binding.type != null ? binding.type.Name : "(Unknown)",
                PropertyName = binding.propertyName ?? string.Empty
            };

            ResolveBinding(row);
            row.CurrentValue = GetValueAtTime(row, previewTime);
            row.SortKey = $"{row.Path}|{row.TypeName}|{row.PropertyName}";
            return row;
        }

        private void ResolveBinding(BindingRow row)
        {
            if (avatarRoot == null)
            {
                row.Resolution = "No Avatar Root";
                return;
            }

            GameObject target = ResolvePath(row.Path);
            if (target == null)
            {
                row.Resolution = "Missing Path";
                return;
            }

            UnityEngine.Object targetObject = ResolveBindingTarget(target, row.Binding.type);
            if (targetObject == null)
            {
                row.Resolution = "Missing Component";
                return;
            }

            EditorCurveBinding[] animatableBindings = GetAnimatableBindings(target);
            bool exact = animatableBindings.Any(binding => BindingsEqual(binding, row.Binding));
            row.SimilarBindings = FindSimilarMaterialBindings(row.Binding, animatableBindings)
                .Where(binding => !BindingsEqual(binding, row.Binding))
                .Distinct(new BindingComparer())
                .OrderBy(binding => binding.propertyName, StringComparer.Ordinal)
                .ToList();

            if (exact)
            {
                row.Resolution = "Exact Animatable";
            }
            else if (row.SimilarBindings.Count > 0)
            {
                row.Resolution = "Similar Material";
            }
            else
            {
                row.Resolution = "Resolved";
            }
        }

        private GameObject ResolvePath(string path)
        {
            if (avatarRoot == null)
            {
                return null;
            }

            if (string.IsNullOrEmpty(path))
            {
                return avatarRoot;
            }

            Transform found = avatarRoot.transform.Find(path);
            return found != null ? found.gameObject : null;
        }

        private static UnityEngine.Object ResolveBindingTarget(GameObject target, Type type)
        {
            if (target == null)
            {
                return null;
            }

            if (type == null || type == typeof(GameObject))
            {
                return target;
            }

            return target.GetComponent(type);
        }

        private EditorCurveBinding[] GetAnimatableBindings(GameObject target)
        {
            if (target == null || avatarRoot == null)
            {
                return Array.Empty<EditorCurveBinding>();
            }

            try
            {
                return AnimationUtility.GetAnimatableBindings(target, avatarRoot);
            }
            catch (Exception ex)
            {
                statusMessage = $"Could not read animatable bindings for {target.name}: {ex.Message}";
                return Array.Empty<EditorCurveBinding>();
            }
        }

        private List<EditorCurveBinding> FindSimilarMaterialBindings(EditorCurveBinding source, EditorCurveBinding[] candidates)
        {
            List<EditorCurveBinding> similar = new List<EditorCurveBinding>();
            if (!TryGetShaderPropertyName(source.propertyName, out string shaderPropertyName))
            {
                return similar;
            }

            foreach (EditorCurveBinding candidate in candidates)
            {
                if (candidate.path != source.path || !IsRendererType(candidate.type))
                {
                    continue;
                }

                if (TryGetShaderPropertyName(candidate.propertyName, out string candidateShaderProperty)
                    && string.Equals(candidateShaderProperty, shaderPropertyName, StringComparison.Ordinal))
                {
                    similar.Add(candidate);
                }
            }

            return similar;
        }

        private List<int> GetVisibleBindingIndices()
        {
            List<int> indices = new List<int>();
            string search = bindingSearch ?? string.Empty;
            for (int i = 0; i < bindingRows.Count; i++)
            {
                BindingRow row = bindingRows[i];
                if (string.IsNullOrWhiteSpace(search)
                    || row.Path.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0
                    || row.TypeName.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0
                    || row.PropertyName.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0
                    || row.Resolution.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    indices.Add(i);
                }
            }

            return indices;
        }

        private BindingRow GetSelectedBinding()
        {
            if (selectedBindingIndex < 0 || selectedBindingIndex >= bindingRows.Count)
            {
                return null;
            }

            return bindingRows[selectedBindingIndex];
        }

        private string GetValueAtTime(BindingRow row, float time)
        {
            if (animationClip == null || row == null)
            {
                return string.Empty;
            }

            if (row.IsObjectReference)
            {
                ObjectReferenceKeyframe[] keyframes = AnimationUtility.GetObjectReferenceCurve(animationClip, row.Binding);
                UnityEngine.Object value = EvaluateObjectReference(keyframes, time);
                return value != null ? value.name : "None";
            }

            AnimationCurve curve = AnimationUtility.GetEditorCurve(animationClip, row.Binding);
            if (curve == null)
            {
                return "(No Curve)";
            }

            return curve.Evaluate(time).ToString("0.###");
        }

        private static UnityEngine.Object EvaluateObjectReference(ObjectReferenceKeyframe[] keyframes, float time)
        {
            if (keyframes == null || keyframes.Length == 0)
            {
                return null;
            }

            UnityEngine.Object value = keyframes[0].value;
            foreach (ObjectReferenceKeyframe keyframe in keyframes)
            {
                if (keyframe.time <= time)
                {
                    value = keyframe.value;
                }
                else
                {
                    break;
                }
            }

            return value;
        }

        private static GameObject FindSelectedAvatarRoot()
        {
            GameObject selected = Selection.activeGameObject;
            if (selected == null)
            {
                return null;
            }

            VRCAvatarDescriptor descriptor = selected.GetComponent<VRCAvatarDescriptor>();
            if (descriptor != null)
            {
                return descriptor.gameObject;
            }

            descriptor = selected.GetComponentInParent<VRCAvatarDescriptor>(true);
            return descriptor != null ? descriptor.gameObject : selected;
        }

        private static bool BindingsEqual(EditorCurveBinding left, EditorCurveBinding right)
        {
            return left.path == right.path
                && left.type == right.type
                && left.propertyName == right.propertyName
                && left.isPPtrCurve == right.isPPtrCurve;
        }

        private static bool IsRendererType(Type type)
        {
            return type == typeof(Renderer)
                || type == typeof(MeshRenderer)
                || type == typeof(SkinnedMeshRenderer)
                || (type != null && typeof(Renderer).IsAssignableFrom(type));
        }

        private static bool TryGetShaderPropertyName(string animatedPropertyName, out string shaderPropertyName)
        {
            shaderPropertyName = null;
            if (string.IsNullOrWhiteSpace(animatedPropertyName) || !animatedPropertyName.StartsWith("material.", StringComparison.Ordinal))
            {
                return false;
            }

            string candidate = animatedPropertyName.Substring("material.".Length);
            if (candidate.StartsWith("[", StringComparison.Ordinal))
            {
                int closeBracket = candidate.IndexOf("].", StringComparison.Ordinal);
                if (closeBracket >= 0)
                {
                    candidate = candidate.Substring(closeBracket + 2);
                }
            }

            string[] parts = candidate.Split('.');
            if (parts.Length > 1 && IsSingleChannel(parts[parts.Length - 1]))
            {
                candidate = string.Join(".", parts.Take(parts.Length - 1));
            }

            if (!candidate.StartsWith("_", StringComparison.Ordinal))
            {
                return false;
            }

            shaderPropertyName = candidate;
            return true;
        }

        private static bool IsSingleChannel(string value)
        {
            return value == "x" || value == "y" || value == "z" || value == "w"
                || value == "r" || value == "g" || value == "b" || value == "a";
        }

        private static string FormatBinding(EditorCurveBinding binding)
        {
            string path = string.IsNullOrEmpty(binding.path) ? "(Avatar Root)" : binding.path;
            string typeName = binding.type != null ? binding.type.Name : "(Unknown)";
            return $"{path} : {typeName}.{binding.propertyName}";
        }

        private static string Shorten(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= maxLength)
            {
                return string.IsNullOrEmpty(value) ? "(Avatar Root)" : value;
            }

            return value.Substring(0, Math.Max(0, maxLength - 3)) + "...";
        }

        private string BuildBindingSummary(BindingRow row)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Path: {(string.IsNullOrEmpty(row.Path) ? "(Avatar Root)" : row.Path)}");
            builder.AppendLine($"Component: {row.TypeName}");
            builder.AppendLine($"Property: {row.PropertyName}");
            builder.AppendLine($"Kind: {(row.IsObjectReference ? "Object Reference" : "Float Curve")}");
            builder.AppendLine($"Resolution: {row.Resolution}");
            builder.AppendLine($"Value At {previewTime:0.###}: {GetValueAtTime(row, previewTime)}");

            if (row.SimilarBindings.Count > 0)
            {
                builder.AppendLine("Nearby Material Bindings:");
                foreach (EditorCurveBinding similar in row.SimilarBindings)
                {
                    builder.AppendLine($"- {FormatBinding(similar)}");
                }
            }

            return builder.ToString();
        }

        private sealed class BindingRow
        {
            public EditorCurveBinding Binding;
            public bool IsObjectReference;
            public string Path;
            public string TypeName;
            public string PropertyName;
            public string Resolution;
            public string CurrentValue;
            public string SortKey;
            public List<EditorCurveBinding> SimilarBindings = new List<EditorCurveBinding>();
        }

        private sealed class BindingComparer : IEqualityComparer<EditorCurveBinding>
        {
            public bool Equals(EditorCurveBinding x, EditorCurveBinding y)
            {
                return BindingsEqual(x, y);
            }

            public int GetHashCode(EditorCurveBinding obj)
            {
                unchecked
                {
                    int hash = 17;
                    hash = hash * 31 + (obj.path != null ? obj.path.GetHashCode() : 0);
                    hash = hash * 31 + (obj.type != null ? obj.type.GetHashCode() : 0);
                    hash = hash * 31 + (obj.propertyName != null ? obj.propertyName.GetHashCode() : 0);
                    hash = hash * 31 + obj.isPPtrCurve.GetHashCode();
                    return hash;
                }
            }
        }
    }
}
#endif
