# Puddles VRC Unity Tools

Unity editor tools for building VRChat avatar expressions without hand-authoring every menu item, animation clip, parameter, and FX layer.

## Included Tools

- `Tools > Puddles > Avatar Action Builder`
- `Tools > Puddles > Poiyomi Lighting Menu Builder`

The normal release menu intentionally contains only these two tools. Avatar Action Builder is for creating and editing new avatar controls. Poiyomi Lighting Menu Builder is for scanning Poiyomi shader sliders and sending them into Action Builder as editable radial controls.

## Requirements

- Unity 2022.3
- VRChat SDK Avatars package
- Poiyomi shader installed in the avatar project when using the Poiyomi builder

Install this package into a VRChat avatar project that already has the SDK loaded. The editor assembly references `VRC.SDK3A` and `VRC.SDKBase`.

## License

This package is licensed under `PolyForm-Noncommercial-1.0.0`.

You may use, copy, modify, and share it for noncommercial purposes. You may not sell it, include it in a paid product, or otherwise use it commercially without separate permission from Puddles.

## Install From Disk

### Drag And Drop Unity Package

Use this option if you do not want to install through Unity Package Manager.

1. Download `PuddlesVrcUnityTools-1.0.2.unitypackage`.
2. Drag the `.unitypackage` file into your Unity project window.
3. Import all files.
4. Open the tools from `Tools > Puddles`.

The drag-and-drop version imports into `Assets/PuddlesVrcTools`.

### VRChat Creator Companion

Creator Companion uses VPM repositories. To publish this package for VCC, host a VPM package zip plus an `index.json` repository listing, then give users the listing URL.

Release maintainer guide: [VCC / VPM Release Guide](Documentation~/vcc-vpm-release.md)

### Unity Package Manager

1. Open Unity Package Manager.
2. Click `+`.
3. Choose `Add package from disk...`.
4. Select `Packages/com.puddles.vrc-unity-tools/package.json`.

For an embedded package, copy the whole `com.puddles.vrc-unity-tools` folder into the Unity project's `Packages` folder.

## First-Time Safe Setup

Before generating anything, duplicate or back up these avatar assets:

- FX controller
- root expression menu
- expression parameters
- avatar prefab or scene object, if you are actively experimenting

Generated assets are written into your project under:

- `Assets/PuddlesVrcTools/Profiles`
- `Assets/PuddlesVrcTools/Generated`

The package folder itself stays editor code only.

## Avatar Action Builder

Open `Tools > Puddles > Avatar Action Builder`.

Avatar Action Builder creates an editable profile asset. The profile stores your controls and action rows, then generates the matching VRC menu entries, expression parameters, animation clips, and FX animator layers.

Supported control types:

- `Toggle`: on/off controls for outfits, accessories, blendshapes, shader values, and exclusivity helpers.
- `Radial`: 0-to-1 float controls for blendshapes and shader float sliders.
- `Selector`: labeled submenu choices for outfits, material sets, or other discrete states.

Supported action rows:

- object active state
- component enabled state
- blendshape value
- renderer material slot swap
- material shader float
- set another Action Builder toggle or selector

Use `No Change` when a control should only affect one side of a toggle or one selector option. This helps avoid controls fighting each other over the same object, blendshape, or material value.

More detail: [Avatar Action Builder Guide](Documentation~/avatar-action-builder.md)

## Poiyomi Lighting Menu Builder

Open `Tools > Puddles > Poiyomi Lighting Menu Builder`.

The Poiyomi builder scans Poiyomi materials on your avatar, lets you choose shader float/range properties, and creates Action Builder radial controls for them.

Release output modes:

- `Add To Action Builder`: creates or updates editable radial controls in the selected Action Builder profile.
- `Add To Action Builder And Generate`: creates or updates the controls, then immediately generates the VRC menu, parameters, clips, and FX layers through Action Builder.

The Poiyomi builder uses Action Builder naming for generated parameters, clips, menus, and FX layers so repeated runs update the same controls cleanly.

More detail: [Poiyomi Lighting Builder Guide](Documentation~/poiyomi-lighting-builder.md)

## Common Workflow

1. Back up the avatar assets listed above.
2. Open Avatar Action Builder and create a profile.
3. Assign the avatar root.
4. Click `Use Assets From Avatar Descriptor`.
5. Create controls directly, or use the Poiyomi builder to add shader radials to the profile.
6. Use Live Preview before generating.
7. Generate one selected control first while testing.
8. Generate all controls once the setup looks right.
9. Test in Unity play mode or a VRChat test build before uploading your main avatar.

## Notes

- Action Builder profiles are meant to be the source of truth for controls created with this package.
- Editing a generated control in the profile and regenerating it is safer than manually editing the generated clips and FX layers.
- If a destination expression menu is full, Action Builder creates managed page submenus where needed.
- Every synced toggle, radial, or selector parameter uses VRChat expression parameter budget. Keep an eye on your avatar's parameter memory.
