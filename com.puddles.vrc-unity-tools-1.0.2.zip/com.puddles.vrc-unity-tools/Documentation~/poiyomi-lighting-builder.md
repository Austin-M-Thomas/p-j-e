# Poiyomi Lighting Menu Builder Guide

Poiyomi Lighting Menu Builder scans Poiyomi materials on an avatar and creates Action Builder radial controls for selected shader float/range properties.

Open it from `Tools > Puddles > Poiyomi Lighting Menu Builder`.

## What It Is For

Use this tool when you want in-game radial dials for Poiyomi shader settings, especially lighting-related settings that help an avatar look better across different VRChat worlds.

Good examples:

- max brightness
- min brightness
- grayscale lighting
- emission strength
- hue shift
- other numeric Poiyomi shader sliders

The release workflow sends controls into Avatar Action Builder. This keeps generated parameter names, menu names, clips, and FX layers consistent with the rest of your avatar controls.

## Setup

1. Open `Tools > Puddles > Poiyomi Lighting Menu Builder`.
2. Assign `Avatar Root`.
3. Click `Use Assets From Avatar Descriptor`.
4. Confirm these fields are filled:
   - `FX Controller`
   - `Expression Parameters`
   - `Root Menu`
5. Assign an `Action Profile`, or leave it blank and let the tool create one.
6. Choose a `Run Name`, such as `Lighting`, `World Fix`, `Face`, or `Body`.

If `Action Profile` is blank, the tool creates one under `Assets/PuddlesVrcTools/Profiles`.

## Output Modes

### Add To Action Builder

Creates or updates editable radial controls in the Action Builder profile.

Use this when you want to review or edit the controls in Action Builder before generating.

### Add To Action Builder And Generate

Creates or updates the Action Builder radial controls, then immediately generates the matching VRC menu entries, parameters, clips, and FX layers.

Use this when you already trust the selected scan results and want the dials created right away.

## Scan Options

### Saved Parameters

Keeps the radial value remembered across worlds and avatar reloads.

### Synced Parameters

Shows the radial result to other users. Turning this off makes the effect local-only.

### Scan Only Active Fields

Only shows shader settings whose Poiyomi parent feature appears enabled.

This helps hide settings from inactive shader sections.

### Scan Only Animated Fields

Only shows Poiyomi fields marked animatable on the material.

This uses the material's Poiyomi animation metadata, such as fields with the `A` marker enabled.

### Scan All Float/Range Properties

Shows all numeric shader sliders instead of only lighting-looking settings.

Use this for emission, hue shift, masks, color adjust values, and other non-lighting Poiyomi sliders.

### Use Unity Animatable Bindings

Uses Unity's reported animation binding paths when possible.

Leave this on unless you are troubleshooting a property that refuses to animate.

### Group Selected By Setting

Combines matching selected settings into one radial.

Example: selecting several material `Max Brightness` properties can become one `All: Max Brightness` radial.

## Scanning And Choosing Controls

1. Click `Scan Avatar Materials`.
2. Use search and quick filters to narrow the list.
3. Use the material dropdown to focus one material.
4. Include only the controls you want.
5. Set `Radial 0`, `Radial 1`, and `Default`.
6. Use `Preview 0`, `Preview 1`, and `Restore Original` to test visible changes.
7. Choose an output mode and generate.

New scans start with controls excluded so you opt in deliberately.

## Radial Values

Each selected shader setting becomes a 0-to-1 VRChat radial puppet.

- `Radial 0` is the value at the left/low end of the dial.
- `Radial 1` is the value at the right/high end of the dial.
- `Default From Original` uses the material's current value as the radial default.

If the shader property range is 0 to 10, using `Radial 0 = 0` and `Radial 1 = 10` gives the full shader range. If you prefer a narrower in-game range, use smaller values.

## Action Builder Sync

Generated Poiyomi dials become Action Builder radial controls.

This means you can:

- rename controls in Action Builder
- move them to another destination menu
- edit radial values later
- use Action Builder generation and managed menu behavior
- keep naming consistent with other Action Builder controls

Repeating the same Poiyomi run updates matching synced controls instead of creating duplicate controls with unrelated naming.

## Troubleshooting

If a scanned shader setting does not appear:

- disable `Scan Only Active Fields`
- disable `Scan Only Animated Fields`
- enable `Scan All Float/Range Properties`
- confirm the material is using a Poiyomi shader
- confirm the setting is a numeric float/range property

If a generated radial appears but does not change the avatar:

- test `Preview 0` and `Preview 1` first
- make sure the Poiyomi field is marked animatable when required
- try leaving `Use Unity Animatable Bindings` enabled
- enable `Log Clip Bindings` and compare the generated binding paths in the Console

If the avatar looks wrong in a world:

- check whether another toggle or selector is also driving the same shader property
- try smaller radial ranges
- use Action Builder Live Preview to test the generated radial control on the real scene avatar

## Safety Tips

- Back up the avatar FX controller, root menu, and expression parameters before large generations.
- Start with one or two included controls before generating a large menu.
- Keep an eye on synced parameter memory.
- Test in a VRChat test build before uploading your main avatar.
