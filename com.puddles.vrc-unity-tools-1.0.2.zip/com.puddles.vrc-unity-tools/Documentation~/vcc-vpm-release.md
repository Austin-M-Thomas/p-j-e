# VCC / VPM Release Guide

Creator Companion installs community packages through VPM repositories.

To make this package installable from VCC, you need two public files:

- a package zip, such as `com.puddles.vrc-unity-tools-1.0.2.zip`
- a repository listing JSON, usually named `index.json`

Users add the `index.json` URL to Creator Companion. After that, the package appears in the project's package list.

## Build The VPM Files

Run the VPM release script from the repo root:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\scripts\Build-VpmRelease.ps1 `
  -PackageUrl "https://example.com/com.puddles.vrc-unity-tools-1.0.2.zip" `
  -RepositoryUrl "https://example.com/index.json" `
  -AuthorEmail "you@example.com"
```

The script writes:

- `Dist/vpm/com.puddles.vrc-unity-tools-1.0.2.zip`
- `Dist/vpm/index.json`

Replace the example URLs with the final public URLs where those files will be hosted.

## Host The Files

Host both files somewhere public, such as:

- GitHub Releases for the zip
- GitHub Pages for `index.json`
- any static file host that serves direct file URLs

The URL inside `index.json` must point to the downloadable package zip.

## Add To Creator Companion

For users:

1. Open VRChat Creator Companion.
2. Open `Settings`.
3. Go to the `Packages` or repository settings area.
4. Add the repository listing URL.
5. Open or create an avatar project.
6. Add `Puddles VRC Unity Tools` from the package list.

## Local Testing

Before publishing publicly, you can test the generated local listing:

1. Run `Build-VpmRelease.ps1`.
2. In Creator Companion, add the generated `Dist/vpm/index.json` file as a local/user repository if your VCC version allows local paths.
3. Create a fresh avatar project.
4. Add the package.
5. Confirm `Tools > Puddles > Avatar Action Builder` and `Tools > Puddles > Poiyomi Lighting Menu Builder` appear.

## Notes

- The VPM package installs under `Packages/com.puddles.vrc-unity-tools`.
- The drag-and-drop `.unitypackage` imports under `Assets/PuddlesVrcTools`.
- The VPM package declares a dependency on `com.vrchat.avatars`, so it is meant for avatar projects.
- Keep old hosted package zip files available after release. Existing projects can break if published versions disappear.
