# Avatar Action Builder Guide

Avatar Action Builder creates editable VRChat avatar controls from a saved profile. Instead of hand-building menu items, expression parameters, animation clips, and FX layers, you define controls in one place and generate the avatar pieces from that profile.

Open it from `Tools > Puddles > Avatar Action Builder`.

## Core Idea

The Action Builder profile is the source of truth.

You can:

- create a control
- choose where it appears in the expression menu
- add action rows
- preview the result on the scene avatar
- generate only the selected control, or generate all controls
- come back later, edit the profile, and regenerate

Generated assets are written under `Assets/PuddlesVrcTools/Generated/AvatarActions`.

## Setup

1. Open `Tools > Puddles > Avatar Action Builder`.
2. Create or assign a profile.
3. Assign `Avatar Root`.
4. Click `Use Assets From Avatar Descriptor`.
5. Confirm these fields are filled:
   - `FX Controller`
   - `Expression Parameters`
   - `Root Menu`
6. Choose or create a destination menu for controls.

Use `Profile Name` to rename the profile asset. Use `Show In Project` to focus the profile in Unity's Project window.

## Control Types

### Toggle

Use toggles for on/off behavior.

Good examples:

- hoodie on/off
- accessory on/off
- blendshape correction on/off
- shader value on/off
- turning another Action Builder control off when this one turns on

Each toggle has a bool parameter. Toggle action rows can write values for `Toggle Off`, `Toggle On`, or use `No Change`.

New toggle action rows start with `Toggle Off = No Change` and `Toggle On = Set`. This makes a new toggle behave like an override by default instead of forcing an off-state value that may fight another control.

### Radial

Use radials for smooth 0-to-1 sliders.

Good examples:

- blendshape amount
- shader brightness
- emission strength
- grayscale lighting amount

Radials support blendshape and shader float rows. New radials use time-parameter style generation by default because it is easy to inspect and works well for common VRChat avatar sliders.

### Selector

Use selectors for labeled discrete choices.

Good examples:

- outfit sets
- color variants
- material sets
- accessory groups

A selector creates a submenu wheel with one option per choice. Each option can set object states, blendshapes, materials, and shader values.

## Action Rows

### Object State

Changes a GameObject active state.

Use `No Change` when this control should not force a value for that state. This is useful when multiple controls may touch the same object.

### Component Enabled

Enables or disables a Behaviour component, such as a PhysBone component.

### Blendshape

Sets a blendshape value on a `SkinnedMeshRenderer`.

For toggles, `Toggle Off` means the value while the toggle is off, and `Toggle On` means the value while the toggle is on.

### Material Swap

Sets a renderer material slot to a selected material.

For selectors, each option can choose a different material for the same slot.

### Shader Float

Sets a float/range shader property on a material slot.

This is useful for shader sliders such as brightness, emission strength, hue shift, grayscale, or other numeric shader controls.

### Set Control

Sets another Action Builder toggle or selector.

Use this for simple exclusivity rules, such as turning one outfit piece off when another outfit turns on. Live Preview does not simulate the driven control yet, but the generated avatar uses a VRC avatar parameter driver on the generated toggle state.

## Destination Menus

Each control has a destination expression menu.

Use `Destination > Select...` to choose a menu. The selector window starts collapsed so large menu trees stay readable.

You can create managed submenus from the destination selector or from the full Menu Manager. Managed submenus are menus created by Action Builder.

Use `Menu Manager (add or remove submenus)` for:

- creating managed submenus
- renaming managed submenus
- deleting managed submenus and their Action Builder controls
- browsing the root expression menu tree
- viewing the direct controls inside the selected submenu

Only Action Builder-managed submenus can be renamed or deleted by Action Builder.

## Live Preview

Live Preview samples temporary in-memory animation clips onto the scene avatar using Unity animation preview mode. It does not generate or save assets.

Preview modes:

- Toggle: preview off or on.
- Radial: drag the 0-to-1 preview slider.
- Selector: choose an option and preview it.

Use `Revert Preview` when you are done. Preview also reverts when the window closes, the avatar changes, or the selected control changes.

The focus tools can automatically refocus Scene View on the avatar after previewing.

## Master Record

Master Record is available for toggle controls.

Use it when you would rather change something directly in Unity and let Action Builder create the matching action row.

Workflow:

1. Select a toggle.
2. Open `Master Record`.
3. Click `Start Recording`.
4. Change a supported value in Unity.
5. Action Builder detects the change and adds or updates a `Toggle On` row.
6. Click `Stop Recording` to restore the avatar to the state it had before recording.

Recorder-supported changes:

- object active state
- component enabled state
- blendshape value
- material slot swap
- shader float/range value

Object and component changes act like a flip: changing the value back removes the recorder-created row. Blendshape and shader float changes update the existing row. Material swaps update the existing row, and switching back to the start material removes the row.

## Generation

Use `Generate Selected` while testing one control.

Use `Generate All` once the profile is ready.

Generation creates or updates:

- VRC expression menu controls
- VRC expression parameters
- FX animator parameters
- FX animator layers
- animation clips
- selector option menus and page menus when needed

Parameter names include the readable control name and a stable ID. Renaming a control changes the readable label but keeps generated logic traceable.

## Safety Tips

- Back up the avatar FX controller, root menu, and expression parameters before large changes.
- Prefer `Generate Selected` while building a new control.
- Use `No Change` when another control should be allowed to own a value.
- Avoid having several controls permanently force the same object or blendshape unless that is intentional.
- Test a VRChat build before uploading your main avatar.
